import { loadGameData, getSusunKataMaxHint, trackSessionMsg, GAME_TIMEOUT } from '../../src/lib/games.js';

export default {
	command: ['susunkata', 'ssk'],
	group: true,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	async run(m, { Shoyu, reply, usedPrefix, fgif }) {
		if (global.gameSession[m.chat]) {
			return reply(`ᴍᴀsɪʜ ᴀᴅᴀ ɢᴀᴍᴇ ʏᴀɴɢ sᴇᴅᴀɴɢ ʙᴇʀʟᴀɴɢsᴜɴɢ ᴅɪ ᴄʜᴀᴛ ɪɴɪ!\nᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴜɴᴛᴜᴋ ᴍᴇɴʏᴇʀᴀʜ ᴅᴜʟᴜ.`);
		}

		const soalList = loadGameData('susunkata');
		const soal = soalList[Math.floor(Math.random() * soalList.length)];
		const maxHint = getSusunKataMaxHint(soal.jawaban);
		const waktu = GAME_TIMEOUT.susunkata;

		const session = {
			type: 'susunkata',
			jawaban: soal.jawaban,
			tipe: soal.tipe,
			revealed: new Array(soal.jawaban.length).fill(false),
			hintsUsed: 0,
			maxHint,
		};

		session.timer = setTimeout(async () => {
			if (global.gameSession[m.chat] === session) {
				delete global.gameSession[m.chat];
				await Shoyu.sendMessage(
					m.chat,
					{ text: `⏰ *𝗪𝗔𝗞𝗧𝗨 𝗛𝗔𝗕𝗜𝗦!*\nJawabannya adalah *${soal.jawaban}*` },
					{ quoted: fgif }
				);
			}
		}, waktu * 1000);

		global.gameSession[m.chat] = session;

		const sent = await Shoyu.sendMessage(
			m.chat,
			{
				text: `🔤 *𝗦𝗨𝗦𝗨𝗡 𝗞𝗔𝗧𝗔*\n\nsᴏᴀʟ: *${soal.soal}*\nᴛɪᴘᴇ: _${soal.tipe}_\n\n*ʙᴀʟᴀs/ʀᴇᴘʟʏ ᴘᴇsᴀɴ ɢᴀᴍᴇ* ᴅᴇɴɢᴀɴ ᴊᴀᴡᴀʙᴀɴᴍᴜ!\n⏱️ Waktu: ${waktu} ᴅᴇᴛɪᴋ\n> ᴋᴇᴛɪᴋ *${usedPrefix}ʜɪɴᴛ* ʙᴜᴀᴛ ʙᴀɴᴛᴜᴀɴ (ᴍᴀx ${maxHint}x), *${usedPrefix}ɴʏᴇʀᴀʜ* ʙᴜᴀᴛ ᴍᴇɴʏᴇʀᴀʜ.`,
			},
			{ quoted: fgif }
		);
		
		trackSessionMsg(session, sent?.key);
	},
};
