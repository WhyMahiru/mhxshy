import { loadGameData, trackSessionMsg, GAME_TIMEOUT } from '../../src/lib/games.js';

export default {
	command: ['caklontong', 'cl', 'guesscaklontong'],
	group: true,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	async run(m, { Shoyu, reply, usedPrefix, fgif }) {
		if (global.gameSession[m.chat]) {
			return reply(`ᴍᴀsɪʜ ᴀᴅᴀ ɢᴀᴍᴇ ʏᴀɴɢ sᴇᴅᴀɴɢ ʙᴇʀʟᴀɴɢsᴜɴɢ ᴅɪ ᴄʜᴀᴛ ɪɴɪ!\nᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴜɴᴛᴜᴋ ᴍᴇɴʏᴇʀᴀʜ ᴅᴜʟᴜ.`);
		}

		const soalList = loadGameData('caklontong');
		const soal = soalList[Math.floor(Math.random() * soalList.length)];

		const session = {
			type: 'caklontong',
			jawaban: soal.jawaban,
			deskripsi: soal.deskripsi,
		};

		const waktu = GAME_TIMEOUT.caklontong;

		session.timer = setTimeout(async () => {
			if (global.gameSession[m.chat] === session) {
				delete global.gameSession[m.chat];
				await Shoyu.sendMessage(
					m.chat,
					{ text: `⏰ *𝗪𝗔𝗞𝗧𝗨 𝗛𝗔𝗕𝗜𝗦!*\nJawabannya adalah *${soal.jawaban}*\n_${soal.deskripsi}_` },
					{ quoted: fgif }
				);
			}
		}, waktu * 1000);

		global.gameSession[m.chat] = session;

		const sent = await Shoyu.sendMessage(
			m.chat,
			{
				text: `🧠 *𝗖𝗔𝗞 𝗟𝗢𝗡𝗧𝗢𝗡𝗚*\n\nsᴏᴀʟ: *${soal.soal}*\n\n*ʙᴀʟᴀs/ʀᴇᴘʟʏ ᴘᴇsᴀɴ ɢᴀᴍᴇ* ᴅᴇɴɢᴀɴ ᴊᴀᴡᴀʙᴀɴᴍᴜ!\n⏱️ Waktu: ${waktu} ᴅᴇᴛɪᴋ\n> ᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴋᴀʟᴏ ᴍᴀᴜ ᴍᴇɴʏᴇʀᴀʜ.`,
			},
			{ quoted: fgif }
		);

		trackSessionMsg(session, sent?.key);
	},
};
