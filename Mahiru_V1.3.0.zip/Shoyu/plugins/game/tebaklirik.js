import { loadGameData, trackSessionMsg, GAME_TIMEOUT } from '../../src/lib/games.js';

export default {
	command: ['tebaklirik', 'tlirik', 'guesslyrics'],
	group: true,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	async run(m, { Shoyu, reply, usedPrefix, fgif }) {
		if (global.gameSession[m.chat]) {
			return reply(`ᴍᴀsɪʜ ᴀᴅᴀ ɢᴀᴍᴇ ʏᴀɴɢ sᴇᴅᴀɴɢ ʙᴇʀʟᴀɴɢsᴜɴɢ ᴅɪ ᴄʜᴀᴛ ɪɴɪ!\nᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴜɴᴛᴜᴋ ᴍᴇɴʏᴇʀᴀʜ ᴅᴜʟᴜ.`);
		}

		const soalList = loadGameData('tebaklirik');
		const soal = soalList[Math.floor(Math.random() * soalList.length)];

		const session = {
			type: 'tebaklirik',
			jawaban: soal.jawaban,
		};

		const waktu = GAME_TIMEOUT.tebaklirik;

		session.timer = setTimeout(async () => {
			if (global.gameSession[m.chat] === session) {
				delete global.gameSession[m.chat];
				await Shoyu.sendMessage(
					m.chat,
					{ text: `⏰ *𝗪𝗔𝗞𝗧𝗨 𝗛𝗔𝗕𝗜𝗦!*\nJawabannya adalah *${soal.jawaban}*` },
					{ quoted: fgif }
				);
			}
		}, waktu * 1000);

		global.gameSession[m.chat] = session;

		const sent = await Shoyu.sendMessage(
			m.chat,
			{
				text: `🎤 *𝗧𝗘𝗕𝗔𝗞 𝗟𝗜𝗥𝗜𝗞*\n\nsᴏᴀʟ: *${soal.soal}*\n\n*ʙᴀʟᴀs/ʀᴇᴘʟʏ ᴘᴇsᴀɴ ɢᴀᴍᴇ* ᴅᴇɴɢᴀɴ ᴊᴀᴡᴀʙᴀɴᴍᴜ!\n⏱️ Waktu: ${waktu} ᴅᴇᴛɪᴋ\n> ᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴋᴀʟᴏ ᴍᴀᴜ ᴍᴇɴʏᴇʀᴀʜ.`,
			},
			{ quoted: fgif }
		);

		trackSessionMsg(session, sent?.key);
	},
};
