import { renderFamilyBoard, giveSusunKataHint, giveFamilyHint, giveSiapakahakuHint, trackSessionMsg } from '../../src/lib/games.js';

export default {
	command: ['nyerah', 'stop', 'hint'],
	group: true,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,

	async run(m, { Shoyu, command, reply, fgif }) {
		const session = global.gameSession[m.chat];
		if (!session) return reply('ᴛɪᴅᴀᴋ ᴀᴅᴀ ɢᴀᴍᴇ ʏᴀɴɢ sᴇᴅᴀɴɢ ʙᴇʀʟᴀɴɢsᴜɴɢ ᴅɪ ᴄʜᴀᴛ ɪɴɪ.');

		switch (command) {
			// @game--nyerah
			case 'nyerah':
			case 'stop': {
				clearTimeout(session.timer);
				delete global.gameSession[m.chat];

				if (session.type === 'susunkata') {
					return reply(`Oke, menyerah!\nJawabannya adalah *${session.jawaban}*`);
				}

				if (session.type === 'family100') {
					return reply(`Oke, menyerah!\n\n${renderFamilyBoard(session, true)}`);
				}

				if (session.type === 'siapakahaku') {
					return reply(`Oke, menyerah!\nJawabannya adalah *${session.jawaban}*`);
				}

				if (session.type === 'tebakbendera') {
					return reply(`Oke, menyerah!\nJawabannya adalah *${session.jawaban}*`);
				}

				if (session.type === 'tebaklirik') {
					return reply(`Oke, menyerah!\nJawabannya adalah *${session.jawaban}*`);
				}

				if (session.type === 'caklontong') {
					return reply(`Oke, menyerah!\nJawabannya adalah *${session.jawaban}*\n_${session.deskripsi}_`);
				}

				if (session.type === 'tekateki') {
					return reply(`Oke, menyerah!\nJawabannya adalah *${session.jawaban}*`);
				}
				return;
			}

			// @game--hint
			case 'hint': {
				if (session.type === 'susunkata') {
					const hasil = giveSusunKataHint(session);
					if (!hasil) return reply(`❌ ʜɪɴᴛ sᴜᴅᴀʜ ʜᴀʙɪs! (ᴍᴀx ${session.maxHint}x)`);

					const sentKey = await reply(`💡 *HINT* (${session.hintsUsed}/${session.maxHint})\n\n${hasil}`);
					trackSessionMsg(session, sentKey);
					return;
				}

				if (session.type === 'family100') {
					const hasil = giveFamilyHint(session);
					if (!hasil) return reply(`❌ ʜɪɴᴛ sᴜᴅᴀʜ ʜᴀʙɪs ᴀᴛᴀᴜ sᴇᴍᴜᴀ ᴊᴀᴡᴀʙᴀɴ sᴜᴅᴀʜ ᴋᴇᴛᴇᴍᴜ! (ᴍᴀx ${session.maxHint}x)`);

					const sentKey = await reply(
						`💡 *HINT* (${session.hintsUsed}/${session.maxHint})\nJawaban nomor ${hasil.index + 1}: *${hasil.jawaban.toUpperCase()}*\n\n${renderFamilyBoard(session)}`
					);
					trackSessionMsg(session, sentKey);
					return;
				}

				if (session.type === 'siapakahaku') {
					const hasil = giveSiapakahakuHint(session);
					if (!hasil) return reply(`❌ ʜɪɴᴛ sᴜᴅᴀʜ ʜᴀʙɪs! (ᴍᴀx ${session.maxHint}x)`);

					const sentKey = await reply(`💡 *HINT* (${session.hintsUsed}/${session.maxHint})\n\n${hasil}`);
					trackSessionMsg(session, sentKey);
					return;
				}

				if (session.type === 'tebakbendera') {
					return reply(`❌ ɢᴀᴍᴇ ɪɴɪ ɴɢɢᴀᴋ ᴘᴀᴋᴇ ʜɪɴᴛ, ᴛᴇʙᴀᴋ ʟᴀɴɢsᴜɴɢ ᴀᴊᴀ~`);
				}

				if (session.type === 'tebaklirik') {
					return reply(`❌ ɢᴀᴍᴇ ɪɴɪ ɴɢɢᴀᴋ ᴘᴀᴋᴇ ʜɪɴᴛ, ᴛᴇʙᴀᴋ ʟᴀɴɢsᴜɴɢ ᴀᴊᴀ~`);
				}

				if (session.type === 'caklontong') {
					return reply(`❌ ɢᴀᴍᴇ ɪɴɪ ɴɢɢᴀᴋ ᴘᴀᴋᴇ ʜɪɴᴛ, ᴛᴇʙᴀᴋ ʟᴀɴɢsᴜɴɢ ᴀᴊᴀ~`);
				}

				if (session.type === 'tekateki') {
					return reply(`❌ ɢᴀᴍᴇ ɪɴɪ ɴɢɢᴀᴋ ᴘᴀᴋᴇ ʜɪɴᴛ, ᴛᴇʙᴀᴋ ʟᴀɴɢsᴜɴɢ ᴀᴊᴀ~`);
				}
				return;
			}
		}
	},
};
