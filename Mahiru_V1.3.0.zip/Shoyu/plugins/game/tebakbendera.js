import { loadGameData, trackSessionMsg, GAME_TIMEOUT } from '../../src/lib/games.js';

export default {
	command: ['tebakbendera', 'tbendera', 'guessflag'],
	group: true,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	async run(m, { Shoyu, reply, usedPrefix }) {
		if (global.gameSession[m.chat]) {
			return reply(`ᴍᴀsɪʜ ᴀᴅᴀ ɢᴀᴍᴇ ʏᴀɴɢ sᴇᴅᴀɴɢ ʙᴇʀʟᴀɴɢsᴜɴɢ ᴅɪ ᴄʜᴀᴛ ɪɴɪ!\nᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴜɴᴛᴜᴋ ᴍᴇɴʏᴇʀᴀʜ ᴅᴜʟᴜ.`);
		}

		const soalList = loadGameData('tebakbendera');
		const soal = soalList[Math.floor(Math.random() * soalList.length)];

		const session = {
			type: 'tebakbendera',
			jawaban: soal.name,
		};

		const waktu = GAME_TIMEOUT.tebakbendera;

		session.timer = setTimeout(async () => {
			if (global.gameSession[m.chat] === session) {
				delete global.gameSession[m.chat];
				await Shoyu.sendMessage(m.chat, {
					text: `⏰ *𝗪𝗔𝗞𝗧𝗨 𝗛𝗔𝗕𝗜𝗦!*\nJawabannya adalah *${soal.name}*`,
				});
			}
		}, waktu * 1000);

		global.gameSession[m.chat] = session;

		const sent = await Shoyu.sendMessage(
			m.chat,
			{
				image: { url: soal.img },
				caption: `🚩 *𝗧𝗘𝗕𝗔𝗞 𝗕𝗘𝗡𝗗𝗘𝗥𝗔*\n\nBendera negara apakah ini?\n\n*ʙᴀʟᴀs/ʀᴇᴘʟʏ ᴘᴇsᴀɴ ɢᴀᴍᴇ* ᴅᴇɴɢᴀɴ ᴊᴀᴡᴀʙᴀɴᴍᴜ!\n⏱️ Waktu: ${waktu} ᴅᴇᴛɪᴋ\n> ᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴋᴀʟᴏ ᴍᴀᴜ ᴍᴇɴʏᴇʀᴀʜ.`,
			},
			{ quoted: m }
		);

		trackSessionMsg(session, sent?.key);
	},
};
