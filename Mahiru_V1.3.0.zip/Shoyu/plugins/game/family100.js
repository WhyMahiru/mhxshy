import { loadGameData, renderFamilyBoard, trackSessionMsg, FAMILY_MAX_HINT, GAME_TIMEOUT } from '../../src/lib/games.js';

function renderTimeoutBoard(session) {
	const total = session.jawabanList.length;
	const totalBenar = session.found.filter(Boolean).length;
	const persen = Math.round((totalBenar / total) * 100);
	const terjawab = [];
	const belum = [];
	session.jawabanList.forEach((j, i) => {
		if (session.found[i]) terjawab.push(j.toUpperCase());
		else belum.push('???');
	});

	let body = `╭─❖ WAKTU HABIS ❖─╮\n\n`;
	body += `😔 Skor Kamu : ${totalBenar}/${total} (${persen}%)\n\n`;

	if (terjawab.length) {
		body += `📖 Sudah Terjawab\n`;
		terjawab.forEach((t, i) => {
			body += (i === terjawab.length - 1 ? '└ ' : '├ ') + t + '\n';
		});
		body += '\n';
	}
	if (belum.length) {
		body += `❔ Belum Terjawab\n`;
		belum.forEach((t, i) => {
			body += (i === belum.length - 1 ? '└ ' : '├ ') + t + '\n';
		});
	}
	return body.trim();
}

export default {
	command: ['family100', 'f100'],
	group: true,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	async run(m, { Shoyu, reply, command, usedPrefix, fgif }) {
		if (global.gameSession[m.chat]) {
			return reply(`ᴍᴀsɪʜ ᴀᴅᴀ ɢᴀᴍᴇ ʏᴀɴɢ sᴇᴅᴀɴɢ ʙᴇʀʟᴀɴɢsᴜɴɢ ᴅɪ ᴄʜᴀᴛ ɪɴɪ!\nᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴜɴᴛᴜᴋ ᴍᴇɴʏᴇʀᴀʜ ᴅᴜʟᴜ.`);
		}
		const soalList = loadGameData('family100');
		const soal = soalList[Math.floor(Math.random() * soalList.length)];
		const session = {
			type: 'family100',
			jawabanList: soal.jawaban,
			found: new Array(soal.jawaban.length).fill(false),
			hintsUsed: 0,
			maxHint: FAMILY_MAX_HINT,
		};
		const waktu = GAME_TIMEOUT.family100;

		session.timer = setTimeout(async () => {
			if (global.gameSession[m.chat] === session) {
				delete global.gameSession[m.chat];
				await Shoyu.sendMessage(
					m.chat,
					{ text: renderTimeoutBoard(session) },
					{ quoted: fgif }
				);
			}
		}, waktu * 1000);
		global.gameSession[m.chat] = session;
		const sent = await Shoyu.sendMessage(
			m.chat,
			{
				text: `👨‍👩‍👧‍👦 *𝗙𝗔𝗠𝗜𝗟𝗬 𝟭𝟬𝟬*\n\n${soal.soal}\n\nᴊᴜᴍʟᴀʜ ᴊᴀᴡᴀʙᴀɴ: ${soal.jawaban.length}\n\n${renderFamilyBoard(session)}\n\n*ʙᴀʟᴀs/ʀᴇᴘʟʏ ᴘᴇsᴀɴ ɢᴀᴍᴇ* ᴛɪᴀᴘ ᴊᴀᴡᴀʙ!\n⏱️ ᴡᴀᴋᴛᴜ: ${waktu} ᴅᴇᴛɪᴋ\n> ᴋᴇᴛɪᴋ *${usedPrefix}ʜɪɴᴛ* ʙᴜᴀᴛ ʙᴀɴᴛᴜᴀɴ (ᴍᴀx ${FAMILY_MAX_HINT}x), *${usedPrefix}ɴʏᴇʀᴀʜ* ʙᴜᴀᴛ ᴍᴇɴʏᴇʀᴀʜ.`,
			},
			{ quoted: fgif }
		);
		trackSessionMsg(session, sent?.key);
	},
};