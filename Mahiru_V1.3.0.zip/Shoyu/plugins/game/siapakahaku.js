import { loadGameData, getSiapakahakuMaxHint, trackSessionMsg, GAME_TIMEOUT } from '../../src/lib/games.js';

export default {
	command: ['siapakahaku', 'ska', 'tebakaku'],
	group: true,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	async run(m, { Shoyu, reply, usedPrefix, fgif }) {
		if (global.gameSession[m.chat]) {
			return reply(`ᴍᴀsɪʜ ᴀᴅᴀ ɢᴀᴍᴇ ʏᴀɴɢ sᴇᴅᴀɴɢ ʙᴇʀʟᴀɴɢsᴜɴɢ ᴅɪ ᴄʜᴀᴛ ɪɴɪ!\nᴋᴇᴛɪᴋ *${usedPrefix}ɴʏᴇʀᴀʜ* ᴜɴᴛᴜᴋ ᴍᴇɴʏᴇʀᴀʜ ᴅᴜʟᴜ.`);
		}

		const soalList = loadGameData('siapakahaku');
		const soal = soalList[Math.floor(Math.random() * soalList.length)];
		const maxHint = getSiapakahakuMaxHint(soal.jawaban);

		const session = {
			type: 'siapakahaku',
			jawaban: soal.jawaban,
			hintFront: false,
			hintBack: false,
			hintsUsed: 0,
			maxHint,
		};

		const waktu = GAME_TIMEOUT.siapakahaku;

		session.timer = setTimeout(async () => {
			if (global.gameSession[m.chat] === session) {
				delete global.gameSession[m.chat];
				await Shoyu.sendMessage(
					m.chat,
					{ text: `⏰ *𝗪𝗔𝗞𝗧𝗨 𝗛𝗔𝗕𝗜𝗦!*\nJawabannya adalah *${soal.jawaban}*` },
					{ quoted: fgif }
				);
			}
		}, waktu * 1000);

		global.gameSession[m.chat] = session;

		const sent = await Shoyu.sendMessage(
			m.chat,
			{
				text: `❓ *𝗦𝗜𝗔𝗣𝗔𝗞𝗔𝗛 𝗔𝗞𝗨*\n\n${soal.soal}\n\n*ʙᴀʟᴀs/ʀᴇᴘʟʏ ᴘᴇsᴀɴ ɢᴀᴍᴇ* ᴅᴇɴɢᴀɴ ᴊᴀᴡᴀʙᴀɴᴍᴜ!\n⏱️ Waktu: ${waktu} ᴅᴇᴛɪᴋ\n> ᴋᴇᴛɪᴋ *${usedPrefix}ʜɪɴᴛ* ʙᴜᴀᴛ ʙᴀɴᴛᴜᴀɴ (ᴍᴀx ${maxHint}x), *${usedPrefix}ɴʏᴇʀᴀʜ* ʙᴜᴀᴛ ᴍᴇɴʏᴇʀᴀʜ.`,
			},
			{ quoted: fgif }
		);

		trackSessionMsg(session, sent?.key);
	},
};
