import { scrapeYtmp3, extractVideoId } from '../../src/scrape/youtube.js';

export default {
  command: ['ytmp4', 'ytvideo', 'ytdlmp4'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ʏᴏᴜᴛᴜʙᴇ-ɴʏᴀ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://youtu.be/xxxxxxxxxxx`
      );
      return false;
    }

    const link = text.trim();
    if (!extractVideoId(link)) {
      reply('Link tidak valid, pastikan itu link video YouTube ya.');
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const result = await scrapeYtmp3(link, 'mp4');

      if (result.status !== 'success') {
        throw new Error(result.message || 'Gagal memproses link YouTube.');
      }
      if (!result.downloadUrl) {
        throw new Error('Link download tidak ditemukan dari server.');
      }

      const fileRes = await fetch(result.downloadUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
      });
      if (!fileRes.ok) throw new Error(`Gagal fetch file (${fileRes.status})`);
      const buffer = Buffer.from(await fileRes.arrayBuffer());

      const title = (result.title || 'video').trim();
      const caption =
        `╭─✦ 𝗬𝗼𝘂𝗧𝘂𝗯𝗲 𝗠𝗣𝟰\n` +
        `│⟡ Judul : ${title}\n` +
        `│⟡ Status : Berhasil diunduh\n` +
        `╰──────────✦`;

      await Shoyu.sendMessage(
        m.chat,
        {
          video: buffer,
          mimetype: 'video/mp4',
          fileName: `${title}.mp4`,
          caption,
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[YTMP4] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengunduh video dari YouTube.\n\n' + (err?.message || JSON.stringify(err)));
      return false;
    }
  },
};