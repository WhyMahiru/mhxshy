import { downloadTiktok } from '../../src/scrape/tiktok.js';
import { AIRich } from '../../src/lib/AIRich.js';

export default {
  command: ['tiktok', 'tt', 'tiktokdl'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ᴛɪᴋᴛᴏᴋ-ɴʏᴀ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://vt.tiktok.com/xxxxx`
      );
      return false;
    }

    if (!/tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(text.trim())) {
      reply('ʟɪɴᴋ-ɴʏᴀ ʜᴀʀᴜs ʟɪɴᴋ ᴛɪᴋᴛᴏᴋ ʏᴀ.');
      return false;
    }

    const rich = new AIRich(Shoyu)
      .addText('sᴇᴅᴀɴɢ ᴍᴇᴍᴘʀᴏsᴇs ᴠɪᴅᴇᴏ ᴛɪᴋᴛᴏᴋ', { id: 'status1' })
      .addVideo('', {
        status: 'GENERATING',
        estimatedTime: 15000,
        insertAt: 'status1',
        id: 'vid1',
      });

    await rich.send(m.chat);

    try {
      const result = await downloadTiktok(text.trim());

      const rawTitle = (result.title || '').trim();
      const hashtags = rawTitle.match(/#\S+/g) || [];
      const captionText = rawTitle.replace(/#\S+/g, '').replace(/\s+/g, ' ').trim();

      const caption = result.provider === 'ssstik' ? undefined :
        `𝗡𝗮𝗺𝗮 : ${result.author || '-'}\n` +
        `𝗖𝗮𝗽𝘁𝗶𝗼𝗻 : ${captionText || '-'}\n` +
        `𝗛𝗮𝘀𝘁𝗮𝗴 : ${hashtags.length ? hashtags.join(' ') : '-'}`;

      const fetchBuf = async (url) => {
        const r = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0' } });
        if (!r.ok) throw new Error(`Gagal fetch (${r.status})`);
        return Buffer.from(await r.arrayBuffer());
      };

      const audioLink = result.links.find((l) => /music|audio|mp3/i.test(l.text));

      rich.addText('ᴠɪᴅᴇᴏ ᴅɪᴛᴇᴍᴜᴋᴀɴ, sᴇᴅᴀɴɢ ᴍᴇɴɢᴜɴᴅᴜʜ ᴍᴇᴅɪᴀ...', { replace: 'status1' });
      await rich.sendEdit();

      const sendAudioIfAny = async () => {
        if (!audioLink) return;
        try {
          const audioBuf = await fetchBuf(audioLink.url);
          await Shoyu.sendMessage(
            m.chat,
            { audio: audioBuf, mimetype: 'audio/mpeg', fileName: 'tiktok-audio.mp3', ptt: false },
            { quoted: m }
          );
        } catch (e) {
        }
      };

      // ── SLIDE / FOTO-LIVE ──
      if (result.type === 'slide') {
        const slideItems = result.slideItems?.length
          ? result.slideItems
          : (result.images?.length ? result.images : result.links.filter((l) => /foto|photo|image|picture/i.test(l.text)).map((l) => l.url))
              .map((url) => ({ type: 'image', url }));

        if (!slideItems.length) throw new Error('Tidak ada foto yang bisa dikirim');

        const imageBufs = [];
        const videoBufs = [];
        for (const item of slideItems) {
          try {
            const buf = await fetchBuf(item.url);
            if (item.type === 'video') videoBufs.push(buf);
            else imageBufs.push(buf);
          } catch (e) {

          }
        }

        if (caption) {
          rich.addText(caption, { replace: 'status1' });
        } else {
          rich.delete('status1');
        }
        rich.delete('vid1');

        if (imageBufs.length) {
          rich.addImage(imageBufs);
        }
        if (videoBufs.length) {
          rich.addVideo(videoBufs);
        }
        await rich.sendEdit();

        await sendAudioIfAny();

        return;
      }

      const videoLink =
        result.links.find((l) => /hd/i.test(l.text)) ||
        result.links.find((l) => /no.?watermark|without/i.test(l.text)) ||
        result.links.find((l) => !/music|audio|mp3|watermark/i.test(l.text)) ||
        result.links[0];

      const videoBuf = await fetchBuf(videoLink.url);

      if (caption) {
        rich.addText(caption, { replace: 'status1' });
      } else {
        rich.delete('status1');
      }
      rich.addVideo(videoBuf, { replace: 'vid1' });
      await rich.sendEdit();

      await sendAudioIfAny();
    } catch (err) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal download TikTok-nya.\n\n' + err.message);
      return false;
    }
  },
};