import { scrapeYtmp3, extractVideoId } from '../../src/scrape/youtube.js';

export default {
  command: ['ytmp3', 'ytaudio', 'ytdlmp3'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ʏᴏᴜᴛᴜʙᴇ-ɴʏᴀ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://youtu.be/xxxxxxxxxxx`
      );
      return false;
    }

    const link = text.trim();
    if (!extractVideoId(link)) {
      reply('Link tidak valid, pastikan itu link video YouTube ya.');
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const result = await scrapeYtmp3(link, 'mp3');

      if (result.status !== 'success') {
        throw new Error(result.message || 'Gagal memproses link YouTube.');
      }
      if (!result.downloadUrl) {
        throw new Error('Link download tidak ditemukan dari server.');
      }

      const fileRes = await fetch(result.downloadUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
      });
      if (!fileRes.ok) throw new Error(`Gagal fetch file (${fileRes.status})`);
      const buffer = Buffer.from(await fileRes.arrayBuffer());

      const title = (result.title || 'audio').trim();

      await Shoyu.sendMessage(
        m.chat,
        {
          audio: buffer,
          mimetype: 'audio/mpeg',
          fileName: `${title}.mp3`,
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[YTMP3] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengunduh audio dari YouTube.\n\n' + (err?.message || JSON.stringify(err)));
      return false;
    }
  },
};