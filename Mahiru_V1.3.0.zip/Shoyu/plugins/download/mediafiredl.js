import axios from 'axios';
import { mediafire } from '../../src/scrape/mediafire.js';

export default {
  command: ['mediafiredl', 'mediafire', 'mfdl', 'mf'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ᴍᴇᴅɪᴀғɪʀᴇ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴜɴᴅᴜʜ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://www.mediafire.com/file/xxx/file.apk`
      );
      return false;
    }

    const link = text.trim();
    const isValidLink = /^https?:\/\/(www\.)?mediafire\.com\/file\/.+/i.test(link);

    if (!isValidLink) {
      reply('Link tidak valid, pastikan itu link file dari mediafire.com');
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const data = await mediafire(link);

      const fileRes = await axios.get(data.download_url, {
        responseType: 'arraybuffer',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          Referer: 'https://www.mediafire.com/',
        },
        timeout: 120000,
      });
      const buffer = Buffer.from(fileRes.data);

      const caption =
        `╭─✦ 𝗠𝗲𝗱𝗶𝗮𝗳𝗶𝗿𝗲 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱\n` +
        `│⟡ Nama : ${data.title}\n` +
        `│⟡ File : ${data.filename}\n` +
        `│⟡ Size : ${data.size || '-'}\n` +
        `│⟡ Status : Berhasil diunduh\n` +
        `╰──────────✦`;

      await Shoyu.sendMessage(
        m.chat,
        {
          document: buffer,
          fileName: data.filename,
          mimetype: data.mimetype,
          caption,
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[MEDIAFIREDL] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengunduh file dari Mediafire.\n\n' + (err?.message || JSON.stringify(err)));
      return false;
    }
  },
};
