import { sfileDownload } from '../../src/scrape/sfile.js';

export default {
  command: ['sfiledownload', 'sfiledl', 'sfiledown'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ғɪʟᴇ sfile.co ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴜɴᴅᴜʜ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://sfile.co/XU8W3i9kEG4\n\n` +
        `ᴛɪᴘ: ᴘᴀᴋᴀɪ *${usedPrefix}sfilesearch* ᴅᴜʟᴜ ᴜɴᴛᴜᴋ ᴄᴀʀɪ ʟɪɴᴋ-ɴʏᴀ.`
      );
      return false;
    }

    const fileLink = text.trim();
    const isValidLink = /^https?:\/\/sfile\.co\/.+/i.test(fileLink);

    if (!isValidLink) {
      reply('Link tidak valid, pastikan itu link dari sfile.co');
      return false;
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { metadata, buffer } = await sfileDownload(fileLink);

      if (!buffer?.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal mengunduh file, buffer kosong.');
        return false;
      }

      const fileName = metadata.filename || 'file';
      const sizeMb = (buffer.length / 1024 / 1024).toFixed(2);

      const caption =
        `╭─✦ 𝗦𝗙𝗶𝗹𝗲 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱\n` +
        `│⟡ Nama : ${fileName}\n` +
        `│⟡ Size : ${sizeMb} MB\n` +
        `│⟡ Uploader : ${metadata.author_name || '-'}\n` +
        `│⟡ Didownload : ${metadata.download_count || '-'}x\n` +
        `│⟡ Status : Berhasil diunduh\n` +
        `╰──────────✦`;

      await Shoyu.sendMessage(
        m.chat,
        {
          document: buffer,
          fileName,
          mimetype: metadata.mimetype || 'application/octet-stream',
          caption,
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[SFILEDOWN] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengunduh file.\n\n' + (err?.message || JSON.stringify(err)));
      return false;
    }
  },
};
