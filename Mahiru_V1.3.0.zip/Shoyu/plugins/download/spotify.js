import { downloadSpotifyAny, formatDuration } from '../../src/scrape/spotifyall.js';

export default {
  command: ['spotify', 'spotifydl'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ sᴘᴏᴛɪғʏ-ɴʏᴀ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://open.spotify.com/track/xxxxxxxxxxxxxxxxxxxxxx`
      );
      return false;
    }

    if (!/open\.spotify\.com\/track\//i.test(text.trim())) {
       reply('ʟɪɴᴋ-ɴʏᴀ ʜᴀʀᴜs ʟɪɴᴋ ᴛʀᴀᴄᴋ sᴘᴏᴛɪғʏ ʏᴀ (open.spotify.com/track/...).');
       return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await downloadSpotifyAny(text.trim());

      await Shoyu.sendMessage(
        m.chat,
        { audio: result.buffer, mimetype: 'audio/mpeg', fileName: result.filename, ptt: false },
        { quoted: m }
      );
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[SPOTIFYDL] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
       reply('Gagal download lagunya.\n\n' + err.message);
       return false;
    }
  },
};