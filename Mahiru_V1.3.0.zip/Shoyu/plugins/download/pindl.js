import { getPin, extractPinId, downloadPinterestMedia } from '../../src/scrape/pinterest.js';

export default {
  command: ['pindl', 'pindownload'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ᴘɪɴ ᴘɪɴᴛᴇʀᴇsᴛ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴅᴏᴡɴʟᴏᴀᴅ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://pinterest.com/pin/123456789/`
      );
    }

    const pinId = await extractPinId(text.trim());
    if (!pinId) {
      return reply(
        'Link tidak valid, pastikan itu link pin Pinterest (pinterest.com/pin/..., atau short link pin.it/...).',
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      let pin = null;
      try {
        pin = await getPin(pinId);
      } catch (err) {
        console.error('[PINDL] getPin gagal (lanjut pakai fallback):', err.message);
      }

      const caption = pin?.title || '';
      let type = pin?.type || null;
      let mediaUrl = pin?.media || null;

      try {
        const { medias } = await downloadPinterestMedia(text.trim());
        const videoMedia = medias.find((x) => x?.extension === 'mp4' || x?.type === 'video');

        if (videoMedia) {
          type = 'video';
          mediaUrl = videoMedia.url || videoMedia.link || mediaUrl;
        } else if (!mediaUrl) {
          const first = medias[0];
          mediaUrl = first?.url || first?.link || mediaUrl;
          if (!type) type = first?.extension === 'gif' ? 'gif' : 'image';
        }
      } catch (err) {
        console.error('[PINDL] downloadPinterestMedia gagal:', err.message);
        if (!mediaUrl) throw err;
      }

      if (!mediaUrl) throw new Error('Gagal mendapatkan URL media dari pin ini.');
      if (!type) type = 'image';

      if (type === 'video') {
        await Shoyu.sendMessage(m.chat, { video: { url: mediaUrl }, caption }, { quoted: m });
      } else if (type === 'gif') {
        await Shoyu.sendMessage(
          m.chat,
          { video: { url: mediaUrl }, gifPlayback: true, caption },
          { quoted: m },
        );
      } else {
        await Shoyu.sendMessage(m.chat, { image: { url: mediaUrl }, caption }, { quoted: m });
      }

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[PINDL] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal download pin.\n\n${err.message}`);
      return false;
    }
  },
};