import { generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { getStreamDongworld } from '../../src/scrape/dongworld.js';

export default {
  command: ['nonton', 'donghuadl'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const slug = text?.trim();

    if (!slug) {
      reply(
        `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
          `> \`${usedPrefix + command} <slug episode>\`\n\n` +
          `> Slug episode bisa didapat dari \`${usedPrefix}donghuainfo <slug series>\`\n\n` +
          `> Contoh:\n` +
          `> \`${usedPrefix + command} swallowed-star-episode-1\``
      );
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '🕕', key: m.key } });

    try {
      const result = await getStreamDongworld(slug, { allEpisodes: false });

      if (result.status !== 'success' || !result.streams?.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ Link stream untuk episode \`${slug}\` tidak ditemukan. Pastikan slug episode-nya benar.`);
        return false;
      }

      const buttons = result.streams.slice(0, 5).map((s) => ({
        name: 'cta_url',
        buttonParamsJson: JSON.stringify({
          display_text: s.provider.length > 28 ? s.provider.slice(0, 25) + '...' : s.provider,
          url: s.url,
        }),
      }));

      const extra = result.streams.length > 5 ? result.streams.slice(5) : [];
      const extraText = extra.length
        ? `\n\n_Link lainnya:_\n${extra.map((s) => `• ${s.provider}: ${s.url}`).join('\n')}`
        : '';

      const body = `🎬 *Link Stream*\n\n✦ Episode: ${slug}\n✦ Provider tersedia: ${result.streams.length}\n\nᴛᴀᴘ ᴛᴏᴍʙᴏʟ ᴅɪ ʙᴀᴡᴀʜ ᴜɴᴛᴜᴋ ʟᴀɴɢsᴜɴɢ ʙᴜᴋᴀ ʟɪɴᴋ-ɴʏᴀ✦${extraText}`;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: { title: 'Nonton Donghua', subtitle: `by ${global.namaBot}`, hasMediaAttachment: false },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: { buttons },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[NONTON] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`❌ ${err.message || 'Gagal mengambil link stream.'}`);
      return false;
    }
  },
};