import { getVideoDetail } from '../../src/scrape/seegore.js';

export default {
  command: ['goredownload', 'goredownload', 'goreget', 'goredl'],
  group: false,
  limit: true,
  premium: true,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const input = text?.trim();
    if (!input) {
       reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ᴀᴛᴀᴜ sʟᴜɢ sᴇᴇɢᴏʀᴇ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://seegore.com/random-video/`);
        return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const detail = await getVideoDetail(input);
      if (!detail || !detail.videos?.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
         reply('ᴠɪᴅᴇᴏ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ ᴀᴛᴀᴜ ᴛɪᴅᴀᴋ ᴍᴇᴍɪʟɪᴋɪ ᴍᴇᴅɪᴀ.');
         return false;
      }

      const videoSrc = detail.videos[0]?.src;
      if (!videoSrc) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
         reply('ᴜʀʟ ᴠɪᴅᴇᴏ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ.');
         return false;
      }

      const caption =
        `*${detail.title || 'No Title'}*\n\n` +
        `📁 Kategori: ${detail.category || '-'}\n` +
        `👁 Views: ${detail.views || '-'}\n` +
        `👍 Upvotes: ${detail.upvotes || '-'}\n` +
        `💬 Komentar: ${detail.comments_count || '0'}\n` +
        `📅 ${detail.date || '-'}`;

      await Shoyu.sendMessage(
        m.chat,
        { video: { url: videoSrc }, caption, mimetype: 'video/mp4' },
        { quoted: m },
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[GOREDOWNLOAD] Error:', err.message);

      if (err.code === 'ENOSPC' || err.message?.includes('no space left')) {
        await Shoyu.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
         reply('⚠️ *Disk server penuh!*\nᴛɪᴅᴀᴋ ʙɪsᴀ ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ.\nʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ᴜɴᴛᴜᴋ ʙᴇʀsɪʜɪɴ sᴇʀᴠᴇʀ.');
         return false;
      }

      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`ɢᴀɢᴀʟ ᴅᴏᴡɴʟᴏᴀᴅ.\n\n${err.message}`);
      return false;
    }
  },
};