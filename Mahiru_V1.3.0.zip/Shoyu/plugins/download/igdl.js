import { downloadInstagram } from '../../src/scrape/instagram.js';

export default {
  command: ['ig', 'igdl', 'instagram'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ɪɴsᴛᴀɢʀᴀᴍ-ɴʏᴀ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://www.instagram.com/reel/xxxxx/`
      );
      return false;
    }

    if (!/instagram\.com/i.test(text.trim())) {
      reply('ʟɪɴᴋ-ɴʏᴀ ʜᴀʀᴜs ʟɪɴᴋ ɪɴsᴛᴀɢʀᴀᴍ ʏᴀ.');
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const result = await downloadInstagram(text.trim());

      const caption = (result.title || '').trim() || undefined;

      const fetchBuf = async (url) => {
        const r = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0' } });
        if (!r.ok) throw new Error(`Gagal fetch (${r.status})`);
        return Buffer.from(await r.arrayBuffer());
      };

      // ── CAROUSEL / SLIDE ──
      if (result.type === 'slide') {
        const slideItems = result.slideItems || [];
        if (!slideItems.length) throw new Error('Tidak ada media yang bisa dikirim');

        for (let i = 0; i < slideItems.length; i++) {
          try {
            const item = slideItems[i];
            const buf = await fetchBuf(item.url);
            const isFirst = i === 0;
            const content = item.type === 'video'
              ? { video: buf, mimetype: 'video/mp4', caption: isFirst ? caption : undefined, fileName: `ig-${i + 1}.mp4` }
              : { image: buf, caption: isFirst ? caption : undefined };
            await Shoyu.sendMessage(m.chat, content, { quoted: isFirst ? m : undefined });
          } catch (e) {
            console.error(`[IG DL] Slide item ${i + 1} di-skip:`, e.message);
          }
        }

        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }

      // ── FOTO TUNGGAL ──
      if (result.type === 'image') {
        const imgUrl = result.images?.[0] || result.links?.[0]?.url;
        if (!imgUrl) throw new Error('Tidak ada link foto');
        const buf = await fetchBuf(imgUrl);
        await Shoyu.sendMessage(m.chat, { image: buf, caption }, { quoted: m });
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }

      // ── VIDEO ──
      const videoLink = result.links?.[0];
      if (!videoLink) throw new Error('Tidak ada link video');
      const videoBuf = await fetchBuf(videoLink.url);
      await Shoyu.sendMessage(
        m.chat,
        { video: videoBuf, mimetype: 'video/mp4', caption, fileName: 'instagram.mp4' },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal download Instagram-nya.\n\n' + err.message);
      return false;
    }
  },
};