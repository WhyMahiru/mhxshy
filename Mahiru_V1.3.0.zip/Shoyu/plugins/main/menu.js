import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { readdirSync, existsSync, readFileSync, watch } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { getUserProfile, getRegisteredUser } from '../../src/lib/database.js';
import { getThumbnailBuffer } from '../../src/lib/thumb.js';


const LABEL_RE = /\/\/\s*@([a-zA-Z0-9_-]+)--([a-zA-Z0-9_-]+)/g;

let pluginCache = null;
let watcherReady = false;

const invalidatePluginCache = () => {
	pluginCache = null;
};

const initPluginWatcher = (pluginsDir) => {
	if (watcherReady) return;
	watcherReady = true;
	try {
		watch(pluginsDir, { recursive: true }, () => invalidatePluginCache());
	} catch {
	}
};

const scanInlineLabels = (filePath) => {
	try {
		const content = readFileSync(filePath, 'utf-8');
		const labels = [];
		let match;
		while ((match = LABEL_RE.exec(content)) !== null) {
			labels.push({ category: match[1], displayName: match[2] });
		}
		LABEL_RE.lastIndex = 0;
		return labels;
	} catch {
		return [];
	}
};

const scanPlugins = async () => {
	const pluginsDir = join(fileURLToPath(import.meta.url), '../../');
	initPluginWatcher(pluginsDir);

	if (pluginCache) return pluginCache;

	const result = {};
	if (!existsSync(pluginsDir)) return result;

	const folders = readdirSync(pluginsDir, { withFileTypes: true })
		.filter((d) => d.isDirectory())
		.map((d) => d.name);

	for (const folder of folders) {
		const folderPath = join(pluginsDir, folder);
		const files = readdirSync(folderPath).filter((f) => f.endsWith('.js'));

		for (const file of files) {
			const filePath = join(folderPath, file);
			try {
				const mod = await import(filePath + `?t=${Date.now()}`);
				const plugin = mod.default;
				if (!plugin?.command?.length) continue;

				const primary = plugin.command[0];

				const pushCmd = (category, name) => {
					if (!result[category]) result[category] = [];
					if (!result[category].some((c) => c.name === name)) {
						result[category].push({ name });
					}
				};

				const inlineLabels = scanInlineLabels(filePath);

				if (inlineLabels.length > 0) {
					for (const { category, displayName } of inlineLabels) {
						pushCmd(category, displayName);
					}
					const allLabelNames = inlineLabels.map((l) => l.displayName);
					if (!allLabelNames.includes(primary)) {
						pushCmd(folder, primary);
					}
				} else {
					const base = file.replace('.js', '');
					const displayName = base.includes('--')
						? base.split('--').slice(1).join('-')
						: base;
					pushCmd(folder, displayName);
				}
			} catch (_) {}
		}
	}

	pluginCache = result;
	return result;
};

// ====== KONVERSI UNICODE: BOLD SANS-SERIF & SMALLCAPS ======
const BOLD_SANS_MAP = (() => {
	const map = {};
	for (let i = 0; i < 26; i++) {
		map[String.fromCharCode(65 + i)] = String.fromCodePoint(0x1d5d4 + i); // A-Z
		map[String.fromCharCode(97 + i)] = String.fromCodePoint(0x1d5ee + i); // a-z
	}
	for (let i = 0; i < 10; i++) {
		map[String(i)] = String.fromCodePoint(0x1d7ec + i); // 0-9
	}
	return map;
})();

const SMALLCAPS_MAP = {
	a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ',
	i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ',
	q: 'q', r: 'ʀ', s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x',
	y: 'ʏ', z: 'ᴢ',
};

const toBoldSans = (str = '') =>
	String(str)
		.split('')
		.map((ch) => BOLD_SANS_MAP[ch] || ch)
		.join('');

const toSmallCaps = (str = '') =>
	String(str)
		.split('')
		.map((ch) => SMALLCAPS_MAP[ch.toLowerCase()] || ch)
		.join('');

const formatCmd = (usedPrefix, c) => `${usedPrefix}${c.name}`;

const formatSection = (title, cmds, usedPrefix) => {
	if (!cmds.length) return '';
	const rows = cmds.map((c) => `│  ✧${toSmallCaps(formatCmd(usedPrefix, c))}`);
	return `\n╭─〔 ✦ ${toBoldSans(title.toUpperCase())} ✦ 〕\n│\n${rows.join('\n')}\n│\n╰─✦`;
};

const getStatusLabel = (isOwner, isPremium) => {
	if (isOwner) return 'ᴏᴡɴᴇʀ';
	if (isPremium) return 'ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀ';
	return 'ғʀᴇᴇ ᴜsᴇʀ';
};

const getUserLimit = (sender, isOwner, isPremium) => {
	if (isOwner) return 'ᴜɴʟɪᴍɪᴛᴇᴅ';
	const profile = getUserProfile(sender);
	return profile?.limit ?? global.limitawal?.free ?? 0;
};

export default {
	command: ['menu', 'start'],
	group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,

	async run(m, { Shoyu, usedPrefix, getPluginStats, isOwner, isPremium, text, ftroli }) {
		const prefixMode = global.public ? 'ᴘᴜʙʟɪᴄ' : 'sᴇʟғ';
		const info = getPluginStats();
		const sub = (text || '').trim().toLowerCase();

		const allCategories = await scanPlugins();

		const ownerCats = Object.fromEntries(Object.entries(allCategories).filter(([c]) => c === 'owner'));
		const userCats = Object.fromEntries(Object.entries(allCategories).filter(([c]) => c !== 'owner'));

		const statusLabel = getStatusLabel(isOwner, isPremium);
		const userLimit = getUserLimit(m.sender, isOwner, isPremium);
		const regUser = getRegisteredUser(m.sender);
		const profUser = getUserProfile(m.sender);
		const totalCmds = info.totalFiles ?? 0;

		let teks = '';

		// ====== MENU SAMBUTAN (default) ======
		if (!sub || (!allCategories[sub] && sub !== 'owner' && sub !== 'all')) {
			teks =
`ʜᴀʟᴏ, *${m.pushName}!* 👋*${ucapan()}*
sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ *${global.namaBot}* ᴀᴋᴜ sɪᴀᴘ ᴍᴇᴍʙᴀɴᴛᴜ ᴋᴀᴍᴜ ᴋᴀᴘᴀɴ sᴀᴊᴀ ᴊɪᴋᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ/ᴇʀᴏʀ sᴇɢᴇʀᴀ ʟᴀᴘᴏʀ ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴅᴇɴɢᴀɴ ᴋᴇᴛɪᴋ ${usedPrefix}ʀᴇᴘᴏʀᴛ

╭─────────────────
│  *𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗕𝗢𝗧*
│ ┌ ᴏᴡɴᴇʀ : *${global.namaOwner}*
│ ├ ᴘʀᴇғɪx : *${usedPrefix}*
│ ├ ᴍᴏᴅᴇ : *${prefixMode}*
│ ├ ғɪᴛᴜʀ : *${totalCmds} ғɪᴛᴜʀ*
╰─────────────────
╭─────────────────
│  *𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗨𝗦𝗘𝗥*
│ ┌ ɴᴀᴍᴀ : *${m.pushName}*
│ ├ ʟɪᴍɪᴛ : *${userLimit}*
│ ├ ᴍᴏɴᴇʏ : *${formatMoney(profUser?.money ?? 0)}*
│ └ sᴛᴀᴛᴜs : *${statusLabel}*
╰─────────────────
_ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ_`;

		// ====== MENU OWNER ======
		} else if (sub === 'owner') {
			const sections = Object.entries(ownerCats).map(([cat, cmds]) => formatSection(cat, cmds, usedPrefix)).join('\n');
			teks =
`ʜᴀʟᴏ, *${m.pushName}!* 👋*${ucapan()}*
sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ *${global.namaBot}* ᴀᴋᴜ sɪᴀᴘ ᴍᴇᴍʙᴀɴᴛᴜ ᴋᴀᴍᴜ ᴋᴀᴘᴀɴ sᴀᴊᴀ ᴊɪᴋᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ/ᴇʀᴏʀ sᴇɢᴇʀᴀ ʟᴀᴘᴏʀ ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴅᴇɴɢᴀɴ ᴋᴇᴛɪᴋ ${usedPrefix}ʀᴇᴘᴏʀᴛ

╭─────────────────
│  *𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗨𝗦𝗘𝗥*
│ ┌ ɴᴀᴍᴀ : *${m.pushName}*
│ ├ ʟɪᴍɪᴛ : *${userLimit}*
│ ├ ᴍᴏɴᴇʏ : *${formatMoney(profUser?.money ?? 0)}*
│ └ sᴛᴀᴛᴜs : *${statusLabel}*
╰─────────────────
_ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ_
${sections}`;

		// ====== MENU ALL ======
		} else if (sub === 'all') {
			const allSections = Object.entries(allCategories)
				.map(([cat, cmds]) => formatSection(cat, cmds, usedPrefix))
				.join('\n');
			
			const displayTotal = totalCmds;
			
			teks =
`ʜᴀʟᴏ, *${m.pushName}!* 👋*${ucapan()}*
sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ *${global.namaBot}* ᴀᴋᴜ sɪᴀᴘ ᴍᴇᴍʙᴀɴᴛᴜ ᴋᴀᴍᴜ ᴋᴀᴘᴀɴ sᴀᴊᴀ ᴊɪᴋᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ/ᴇʀᴏʀ sᴇɢᴇʀᴀ ʟᴀᴘᴏʀ ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴅᴇɴɢᴀɴ ᴋᴇᴛɪᴋ ${usedPrefix}ʀᴇᴘᴏʀᴛ

╭─────────────────
│  *𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗨𝗦𝗘𝗥*
│ ┌ ɴᴀᴍᴀ : *${m.pushName}*
│ ├ ʟɪᴍɪᴛ : *${userLimit}*
│ ├ ᴍᴏɴᴇʏ : *${formatMoney(profUser?.money ?? 0)}*
│ └ sᴛᴀᴛᴜs : *${statusLabel}*
╰─────────────────
_ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ_
${allSections}`;

		// ====== MENU KATEGORI SPESIFIK ======
		} else if (allCategories[sub]) {
			teks =
`ʜᴀʟᴏ, *${m.pushName}!* 👋*${ucapan()}*
sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ *${global.namaBot}* ᴀᴋᴜ sɪᴀᴘ ᴍᴇᴍʙᴀɴᴛᴜ ᴋᴀᴍᴜ ᴋᴀᴘᴀɴ sᴀᴊᴀ ᴊɪᴋᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ/ᴇʀᴏʀ sᴇɢᴇʀᴀ ʟᴀᴘᴏʀ ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴅᴇɴɢᴀɴ ᴋᴇᴛɪᴋ ${usedPrefix}ʀᴇᴘᴏʀᴛ

╭─────────────────
│  *𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗨𝗦𝗘𝗥*
│ ┌ ɴᴀᴍᴀ : *${m.pushName}*
│ ├ ʟɪᴍɪᴛ : *${userLimit}*
│ ├ ᴍᴏɴᴇʏ : *${formatMoney(profUser?.money ?? 0)}*
│ └ sᴛᴀᴛᴜs : *${statusLabel}*
╰─────────────────
_ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ_
${formatSection(sub, allCategories[sub], usedPrefix)}`;
		}

		// ====== ROWS UNTUK LIST BUTTON ======
		const ownerCmdCount = Object.values(ownerCats).reduce((sum, cmds) => sum + cmds.length, 0);

		const mainRows = [
			{
				title: toBoldSans('Semua Fitur'),
				description: toSmallCaps(`${totalCmds} command tersedia`),
				id: `${usedPrefix}menu all`,
			},
			{
				title: toBoldSans('Owner'),
				description: toSmallCaps(`${ownerCmdCount} command tersedia`),
				id: `${usedPrefix}menu owner`,
			},
		];

		const otherRows = Object.keys(allCategories)
			.filter((cat) => cat !== 'owner')
			.map((cat) => ({
				title: toBoldSans(cat.charAt(0).toUpperCase() + cat.slice(1)),
				description: toSmallCaps(`${allCategories[cat].length} command tersedia`),
				id: `${usedPrefix}menu ${cat}`,
			}));

		const pp = await getThumbnailBuffer();
		const media = await generateWAMessageContent(
			{ image: pp },
			{ upload: Shoyu.waUploadToServer }
		);

		const msg = generateWAMessageFromContent(
			m.chat,
			{
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: global.namaBot,
								subtitle: `by ${global.namaOwner}`,
								hasMediaAttachment: true,
								imageMessage: media.imageMessage,
							},
							body: { text: teks },
							footer: { text: `${global.namaBot}  •  ${prefixMode} ᴍᴏᴅᴇ  •  ${getTime('HH:mm')} WIB` },
							nativeFlowMessage: {
								buttons: [
									{
										name: 'single_select',
										buttonParamsJson: JSON.stringify({
											title: 'ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ',
											sections: [
												{ title: 'Menu Utama', highlight_label: 'Rekomendasi', rows: mainRows },
												{ title: 'Kategori Menu Lain', rows: otherRows },
											],
											icon: 'DEFAULT',
										}),
									},
									{
										name: 'single_select',
										buttonParamsJson: JSON.stringify({
											title: 'ɪɴғᴏʀᴍᴀᴛɪᴏɴ',
											sections: [{
												title: 'Lainnya',
												highlight_label: 'ɪɴғᴏʀᴍᴀsɪ',
												rows: [
													{ title: toBoldSans('Source Code'), description: toSmallCaps('lihat source code'), id: `${usedPrefix}script` },
													{ title: toBoldSans('Kontak Owner'), description: toSmallCaps('hubungi owner'), id: `${usedPrefix}owner` },
												],
											}],
											icon: 'REVIEW',
										}),
									},
								
								],
								messageParamsJson: JSON.stringify({
									bottom_sheet: {
										in_thread_buttons_limit: 1,
										divider_indices: [1, 2],
										list_title: 'Pilih Menu',
										button_title: ' ❰ 𝐏𝐈𝐋𝐈𝐇 𝐌𝐄𝐍𝐔 ❱ ',
									},
								}),
							},
						},
					},
				},
			},
			{ userJid: Shoyu.user.id, quoted: ftroli }
		);

		await Shoyu.relayMessage(m.chat, msg.message, {
			messageId: msg.key.id,
			additionalNodes: [
				{
					tag: 'biz',
					attrs: {},
					content: [{
						tag: 'interactive',
						attrs: { type: 'native_flow', v: '1' },
						content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
					}],
				},
			],
		});
	},
};