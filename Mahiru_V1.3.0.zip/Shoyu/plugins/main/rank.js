import { getLevelInfo } from '../../src/lib/level.js';

export default {
  command: ['rank', 'level'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { reply, usedPrefix }) {
    const info = getLevelInfo(m.sender);
    if (!info) return reply(`❌ ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ. ᴋᴇᴛɪᴋ *${usedPrefix}ᴅᴀғᴛᴀʀ* ᴅᴜʟᴜ ʏᴀ!`);

    return reply(
      `╭─〔 ✦ *𝗥𝗔𝗡𝗞 𝗜𝗡𝗙𝗢* ✦ 〕\n` +
      `│\n` +
      `│ 👤 ${m.pushName || 'ᴜsᴇʀ'}\n` +
      `│ 🎖️ ʀᴀɴᴋ : *${info.role}*\n` +
      `│ 📊 ʟᴇᴠᴇʟ : *${info.level}*\n` +
      `│ ✨ xᴘ : *${info.experience} / 100*\n` +
      `│\n` +
      `│ [${info.bar}]\n` +
      `│\n` +
      `╰──────────────────✦`
    );
  }
};
