import { getRegisteredUser, getUserProfile, isPremiumUser } from '../../src/lib/database.js';
import { getRole } from '../../src/lib/level.js';
import { getThumbnailBuffer } from '../../src/lib/thumb.js';

export default {
	command: ['profile', 'me'],
	group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,

	async run(m, { reply, Shoyu, fdoc }) {
		const target = m.quoted
			? m.quoted.sender
			: m.mentionedJid && m.mentionedJid[0]
				? Shoyu.getJid(m.mentionedJid[0])
				: m.sender;

		const isSelf = target === m.sender;

		const globalOwners = (global.owner || []).map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');
		const targetIsOwner = globalOwners.includes(target) || (isSelf && m.fromMe);
		const targetIsPremium = isPremiumUser(target);

		const regUser = getRegisteredUser(target);
		const profUser = getUserProfile(target);

		if (!isSelf && !profUser) {
			return reply('❌ User yang di-reply/tag belum terdaftar!');
		}

		const level = profUser?.level ?? 1;
		const role = getRole(level);
		const limDisplay = targetIsOwner ? 'ᴜɴʟɪᴍɪᴛᴇᴅ' : formatMoney(profUser?.limit ?? 0);

		const txt = `
╭─〔 ✦ 𝗣𝗥𝗢𝗙𝗜𝗟 ${isSelf ? '𝗞𝗔𝗠𝗨' : '@' + target.split('@')[0]} ✦ 〕
│
│ 👤 ɴᴀᴍᴀ : ${m.pushName}
│ 🎂 ᴜᴍᴜʀ : ${regUser?.age || '-'}
│ 📱 ɴᴏᴍᴏʀ : ${target.split('@')[0]}
│ 🏷️ sᴛᴀᴛᴜs : ${targetIsOwner ? 'ᴏᴡɴᴇʀ' : targetIsPremium ? 'ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀ' : 'ғʀᴇᴇ ᴜsᴇʀ'}
│ 🎖️ ʀᴀɴᴋ : ${role}
│ 📊 ʟᴇᴠᴇʟ : ${level}
│ 💰 sᴀʟᴅᴏ : ${formatMoney(profUser?.money ?? 0)}
│ 💎 ʟɪᴍɪᴛ : ${limDisplay}
╰──────────────────✦
`.trim();

		const pp = await getThumbnailBuffer();

		await Shoyu.sendMessage(m.chat, {
			image: pp,
			caption: txt,
			mentions: isSelf ? [] : [target]
		}, { quoted: fdoc });
	},
};