export default {
  command: ['delppbot', 'deleteprofilebot'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {
    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      await Shoyu.removeProfilePicture(Shoyu.user.id);

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return reply('Berhasil hapus foto profil bot!');
    } catch (err) {
      console.error(err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return reply('Gagal hapus foto profil bot! Kemungkinan memang belum ada foto profil.');
    }
  }
};
