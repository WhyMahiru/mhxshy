import { startAutoBackup, stopAutoBackup } from '../../src/lib/autobackup.js';

export default {
  command: ['autobackup'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,

  async run(m, { Shoyu, args, reply }) {
    const sub = args[0]?.toLowerCase();
    const ownerJids = (global.owner || []).map((v) => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');

    if (sub === 'start') {
      if (!ownerJids.length) return reply('Nomor owner belum diatur di *global.owner* (settings/setting.js).');
      startAutoBackup(Shoyu, ownerJids);
      reply(`✅ Auto backup aktif (setiap 5 jam) → dikirim ke ${ownerJids.length} nomor owner.`);
    } else if (sub === 'stop') {
      stopAutoBackup();
      reply('🛑 Auto backup dihentikan.');
    } else {
      reply('ℹ️ Penggunaan:\n.autobackup start → aktifkan\n.autobackup stop → matikan');
    }
  }
};