export default {
  command: ["anticall"],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { reply, args, command, usedPrefix, updateData }) {
    let status = (args[0] || "").toLowerCase();

    if (!["on", "off"].includes(status)) {
      return reply(
        `📵 *𝗔𝗻𝘁𝗶 𝗖𝗮𝗹𝗹*\n\n` +
        `> Status: *${global.anticall ? "Aktif ✅" : "Nonaktif ❌"}*\n\n` +
        `Contoh: ${usedPrefix + command} on/off`
      );
    }

    const isEnable = status === "on";
    const dbValue = isEnable ? 1 : 0;

    try {
      global.anticall = isEnable;
      await updateData('settings', 'bot', 'anticall', dbValue);

      m.reply(`Anti Call berhasil di${isEnable ? 'aktifkan ✅' : 'matikan ❌'}`);
    } catch (e) {
      console.error(e);
      reply('Gagal menyimpan ke database.');
    }
  }
};