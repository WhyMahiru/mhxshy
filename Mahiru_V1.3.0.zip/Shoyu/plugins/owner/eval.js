import util from 'util';
import { exec } from 'child_process';

export default {
  command: ['ambilq', 'q', 'eval', '>', '$'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, reply, mess, command, text, usedPrefix }) {
  
  	const body = m.text.trim();
  	const baseCommand = command.toLowerCase();
  	let codeBody = text;
  
  	if (baseCommand === '>' || baseCommand === '$') {
  		codeBody = m.text.slice(usedPrefix.length + baseCommand.length).trim();
  	}
  
  	switch (baseCommand) {
  	    // @owner--q
  		case 'ambilq':
  		case 'q':
  			try {
  				if (!m.quoted) return reply(`Ex: ${usedPrefix}q (reply pesannya)`);
  				const result = m.quoted;
  				const output = util.inspect(result, { depth: 5 });
  				await Shoyu.sendMessage(m.chat, { text: output }, { quoted: m });
  			} catch (err) {
  				await Shoyu.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
  			}
  			break;
        // @owner--eval
  		case 'eval':
  			try {
  				const code = codeBody;
  				if (!code) return reply(`Ex: ${usedPrefix}eval kode yang mau di eval`);
  
  				const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
  				const fn = new AsyncFunction('Shoyu', 'm', 'reply', 'text', 'mess', 'util', 'usedPrefix', code);
  				const result = await fn(Shoyu, m, reply, text, mess, util, usedPrefix);
  
  				const output = typeof result === 'string' ? result : util.inspect(result);
  				await Shoyu.sendMessage(m.chat, { text: output }, { quoted: m });
  			} catch (err) {
  				await Shoyu.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
  			}
  			break;
        
        // @owner-->
  		case '>':
  			try {
  				const code = codeBody;
  				if (!code) return reply(`Ex: ${usedPrefix}> kodenya`);
  
  				let result = await (async () => eval(code))();
  				if (typeof result !== 'string') result = util.inspect(result);
  
  				await Shoyu.sendMessage(m.chat, { text: result }, { quoted: m });
  			} catch (err) {
  				await Shoyu.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
  			}
  			break;
        // @owner--$
  		case '$':
  			const shellCommand = codeBody;
  			if (!shellCommand) return reply(`Ex: ${usedPrefix}$ command nya`);
  
  			exec(shellCommand, (err, stdout, stderr) => {
  				if (err) return Shoyu.sendMessage(m.chat, { text: err.toString() }, { quoted: m });
  				if (stdout) return Shoyu.sendMessage(m.chat, { text: util.format(stdout) }, { quoted: m });
  				if (stderr) return Shoyu.sendMessage(m.chat, { text: util.format(stderr) }, { quoted: m });
  
  				return Shoyu.sendMessage(m.chat, { text: 'Done (No output)' }, { quoted: m });
  			});
  			break;
  
  		default:
  			break;
  	}
  
  }
};
