export default {
  command: ['mode', 'public', 'self'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  
  async run(m, { args, command, usedPrefix, updateData }) {
  
  	const text = args[0] ? args[0].toLowerCase() : '';
  
  	const changeMode = async (isPublic) => {
  		global.public = isPublic;
  		try {
  			await updateData('settings', 'bot', 'public', isPublic ? 1 : 0);
  		} catch (e) {
  			console.error('Gagal update database:', e);
  		}
  	};
  
  	if (command === 'mode' && text === 'public') {
  		await changeMode(true);
  		return m.reply('Sukses mengubah ke *mode public*');
  	}
  
  	if (command === 'mode' && text === 'self') {
  		await changeMode(false);
  		return m.reply('Sukses mengubah ke *mode self*');
  	}
  
  	if (command === 'mode') {
  		const isPublic = global.public;
  		const statusStr = isPublic ? 'Public mode' : 'Self mode';
  
  		const msg =
  			`*Mode bot settings*\n` +
  			`- Mode saat ini: *${statusStr}*\n\n` +
  			`*Command vailid*\n` +
  			`- ${usedPrefix}mode public *semua orang bisa pakai bot*\n` +
  			`- ${usedPrefix}mode self *hanya owner yang bisa pakai bot*`;
  
  		return m.reply(msg);
  	}
  
  }
};
