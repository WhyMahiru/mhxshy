import fs from 'fs';

export default {
  command: ['clsesi', 'clearsesion', 'clearsesi'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, reply }) {
  
  	const pathAuth = './Auth';
  	const pathTrash = './data/trash';
  
  	if (!fs.existsSync(pathAuth)) fs.mkdirSync(pathAuth, { recursive: true });
  	if (!fs.existsSync(pathTrash)) fs.mkdirSync(pathTrash, { recursive: true });
  	const dirsesi = fs.readdirSync(pathAuth).filter((e) => e !== 'creds.json');
  	const dirsampah = fs.readdirSync(pathTrash).filter((e) => e !== 'tmp');
  
  	for (const file of dirsesi) {
  		try {
  			fs.unlinkSync(`${pathAuth}/${file}`);
  		} catch (e) {
  			console.error(`Gagal hapus ${file}:`, e.message);
  		}
  	}
  
  	for (const file of dirsampah) {
  		try {
  			fs.unlinkSync(`${pathTrash}/${file}`);
  		} catch (e) {
  			console.error(`Gagal hapus ${file}:`, e.message);
  		}
  	}
  
  	reply(`*Berhasil membersihkan sampah ✅*
  - *${dirsesi.length}* sampah session
  - *${dirsampah.length}* sampah file`);
  
  }
};
