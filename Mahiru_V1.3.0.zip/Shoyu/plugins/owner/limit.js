import { addUserLimit, resetAllLimit, getUserProfile } from '../../src/lib/database.js';

export default {
	command: ['addlimit', 'resetlimit'],
	group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: true,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	
	async run(m, { Shoyu, args, command, reply, usedPrefix, example }) {
		switch (command) {
		    // @owner--addlimit
			case 'addlimit': {
				const raw0 = args[0] || '';
				const [rawTarget, pipeJumlah] = raw0.split('|');

				let target, amount;

				if (m.quoted) {
					target = m.quoted.sender;
					amount = parseInt(pipeJumlah || args[0]);
				} else if (m.mentionedJid && m.mentionedJid[0]) {
					target = Shoyu.getJid(m.mentionedJid[0]);
					amount = parseInt(pipeJumlah || args[1]);
				} else if (rawTarget) {
					target = rawTarget.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
					amount = parseInt(pipeJumlah || args[1]);
				} else {
					target = null;
				}

				if (!target) return reply(example(`tag/nomor|jumlah\n *${usedPrefix + command}* 628xx|5\n *${usedPrefix + command}* @tag|5\n(atau reply pesan user ${usedPrefix + command} 5)`));
				if (isNaN(amount) || amount <= 0) return reply('❌ Masukkan jumlah limit yang valid!');

				const found = getUserProfile(target);
				if (!found) return reply('❌ User belum terdaftar!');

				addUserLimit(target, amount);
				const updated = getUserProfile(target);
				return Shoyu.sendMessage(
					m.chat,
					{
						text: `✅ Berhasil menambah ${amount} limit ke @${target.split('@')[0]}!\nSisa limit sekarang: *${updated?.limit ?? 0}*`,
						mentions: [target],
					},
					{ quoted: m }
				);
			}
            
            // @owner--resetlimit
			case 'resetlimit': {
				resetAllLimit();
				return reply('✅ Semua limit user telah direset ke limit awal!');
			}
		}
	},
};
