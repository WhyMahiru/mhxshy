import crypto from 'crypto'
import { proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'

global.relayStore = global.relayStore || {}

class Button {
	constructor(Shoyu) {
		this.Shoyu = Shoyu
		this.title = ''
		this.subtitle = ''
		this.body = ''
		this.footer = ''
		this.media = null
		this.params = {}
		this.buttons = []
		this.copies = []
	}

	setTitle(title) { this.title = title; return this }
	setSubtitle(subtitle) { this.subtitle = subtitle; return this }
	setBody(body) { this.body = body; return this }
	setFooter(footer) { this.footer = footer; return this }
	setMedia(media) { this.media = media; return this }
	setParams(params) { this.params = params; return this }

	addCopy(label, value) {
		this.copies.push({ label, value: String(value || '') })
		return this
	}

	addQuickReply(text, id = text) {
		this.buttons.push({
			name: 'quick_reply',
			buttonParamsJson: JSON.stringify({ display_text: text, id })
		})
		return this
	}

	addButton(name, paramsJson) {
		this.buttons.push({
			name,
			buttonParamsJson: typeof paramsJson === 'string' ? paramsJson : JSON.stringify(paramsJson)
		})
		return this
	}

	async send(jid, options = {}) {
		const nativeButtons = [
			...this.copies.map(c => ({
				name: 'cta_copy',
				buttonParamsJson: JSON.stringify({
					display_text: c.label,
					copy_code: c.value
				})
			})),
			...this.buttons
		]

		const bottomSheet = this.params?.bottom_sheet || {}
		const limitedOffer = this.params?.limited_time_offer || null

		const messageParamsJson = JSON.stringify({
			...(Object.keys(bottomSheet).length ? { bottom_sheet: bottomSheet } : {}),
			...(limitedOffer ? { limited_time_offer: limitedOffer } : {})
		})

		const msg = {
			viewOnceMessage: {
				message: {
					messageContextInfo: {
						deviceListMetadata: {},
						deviceListMetadataVersion: 2
					},
					interactiveMessage: {
						header: {
							title: this.title,
							subtitle: this.subtitle || '',
							hasMediaAttachment: !!this.media,
							...(this.media || {})
						},
						body: { text: this.body },
						footer: { text: this.footer },
						nativeFlowMessage: {
							buttons: nativeButtons,
							messageParamsJson
						}
					}
				}
			}
		}

		return this.Shoyu.relayMessage(jid, msg, {
			messageId: options.messageId || crypto.randomUUID(),
			additionalNodes: [
				{
					tag: 'biz',
					attrs: {},
					content: [
						{
							tag: 'interactive',
							attrs: { type: 'native_flow', v: '1' },
							content: [
								{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }
							]
						}
					]
				}
			],
			...options
		})
	}
}

const resolveEnum = (enumObj, value) => {
	if (!enumObj) return value
	if (typeof value === 'number') return value
	if (typeof value !== 'string') return value
	return enumObj[value] ?? enumObj.UNKNOWN ?? value
}

const messageMiddleware = [
	{
		types: [/^pollCreationMessage/i],
		run(message) {
			message.messageContextInfo = message.messageContextInfo || {}
			if (!message.messageContextInfo.messageSecret) {
				message.messageContextInfo.messageSecret = crypto.randomBytes(32).toString('base64')
			}
		}
	},
	{
		types: ['eventMessage'],
		run(message) {
			message.messageContextInfo = message.messageContextInfo || {}
			if (!message.messageContextInfo.messageSecret) {
				message.messageContextInfo.messageSecret = crypto.randomBytes(32).toString('base64')
			}
		}
	},
	{
		types: ['interactiveMessage', 'buttonsMessage'],
		run(message) {
			message.messageContextInfo = message.messageContextInfo || {}
			message.messageContextInfo.deviceListMetadata = message.messageContextInfo.deviceListMetadata || {}
			message.messageContextInfo.deviceListMetadataVersion = 2
		}
	},
	{
		types: ['buttonsMessage'],
		run(bm) {
			const BUTTON_TYPE = proto?.Message?.ButtonsMessage?.Button?.Type
			const HEADER_TYPE = proto?.Message?.ButtonsMessage?.HeaderType
			if (bm.headerType !== undefined) bm.headerType = resolveEnum(HEADER_TYPE, bm.headerType)
			if (Array.isArray(bm.buttons)) {
				for (const btn of bm.buttons) {
					if (btn?.type !== undefined) btn.type = resolveEnum(BUTTON_TYPE, btn.type)
				}
			}
		}
	},
	{
		types: ['listMessage'],
		run(message) {
			message.messageContextInfo = message.messageContextInfo || {}
			message.messageContextInfo.deviceListMetadata = message.messageContextInfo.deviceListMetadata || {}
			message.messageContextInfo.deviceListMetadataVersion = 2
			const LIST_TYPE = proto?.Message?.ListMessage?.ListType
			if (message.listType !== undefined) message.listType = resolveEnum(LIST_TYPE, message.listType)
		}
	},
	{
		types: ['templateMessage'],
		run(message) {
			message.messageContextInfo = message.messageContextInfo || {}
			message.messageContextInfo.deviceListMetadata = message.messageContextInfo.deviceListMetadata || {}
			message.messageContextInfo.deviceListMetadataVersion = 2
		}
	},
	{
		types: ['richResponseMessage'],
		run(rm) {
			const MESSAGE_TYPE = proto?.AIRichResponseMessageType
			const SUBMESSAGE_TYPE = proto?.AIRichResponseSubMessageType
			const HIGHLIGHT_TYPE = proto?.AIRichResponseCodeMetadata?.AIRichResponseCodeHighlightType
			if (rm.messageType !== undefined) rm.messageType = resolveEnum(MESSAGE_TYPE, rm.messageType)
			if (Array.isArray(rm.submessages)) {
				for (const subm of rm.submessages) {
					if (subm?.messageType !== undefined) subm.messageType = resolveEnum(SUBMESSAGE_TYPE, subm.messageType)
					const blocks = subm?.codeMetadata?.codeBlocks
					if (!Array.isArray(blocks)) continue
					for (const cb of blocks) {
						if (cb?.highlightType !== undefined) cb.highlightType = resolveEnum(HIGHLIGHT_TYPE, cb.highlightType)
					}
				}
			}
		}
	},
	{
		types: [
			'productMessage', 'orderMessage', 'invoiceMessage',
			'requestPaymentMessage', 'sendPaymentMessage',
			'declinePaymentRequestMessage', 'cancelPaymentRequestMessage',
			'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension',
			'ephemeralMessage', 'documentWithCaptionMessage', 'albumMessage'
		],
		run(message) {
			message.messageContextInfo = message.messageContextInfo || {}
			message.messageContextInfo.deviceListMetadata = message.messageContextInfo.deviceListMetadata || {}
			message.messageContextInfo.deviceListMetadataVersion = 2
		}
	}
]

function detectInteractiveSubtype(interactiveMsg) {
	const buttons = interactiveMsg?.nativeFlowMessage?.buttons || []

	for (const btn of buttons) {
		const name = btn?.name || ''

		if (name === 'payment_key_info') return 'payment_key_info'
		if (name === 'review_and_pay' || name === 'order_details') return 'order_details'
	}

	const paramsJson = interactiveMsg?.nativeFlowMessage?.messageParamsJson
	if (paramsJson) {
		try {
			const parsed = JSON.parse(paramsJson)
			if (parsed?.catalog_id || parsed?.catalog) return 'catalog_message'
		} catch {}
	}

	const header = interactiveMsg?.header
	if (header?.hasMediaAttachment && interactiveMsg?.nativeFlowMessage?.buttons?.some(b => b?.name === 'single_select')) {
	}

	return 'mixed'
}

function getInteractiveAdditionalNodes(interactiveMsg) {
	const subtype = detectInteractiveSubtype(interactiveMsg)

	if (subtype === 'catalog_message') {
		return [{ tag: 'biz', attrs: { native_flow_name: 'catalog_message' } }]
	}

	if (subtype === 'order_details') {
		return [{ tag: 'biz', attrs: { native_flow_name: 'order_details' } }]
	}

	if (subtype === 'payment_key_info') {
		return [
			{
				tag: 'biz',
				attrs: {},
				content: [
					{
						tag: 'interactive',
						attrs: { type: 'native_flow', v: '1' },
						content: [
							{ tag: 'native_flow', attrs: { name: 'payment_key_info' } }
						]
					}
				]
			}
		]
	}

	return [
		{
			tag: 'biz',
			attrs: {},
			content: [
				{
					tag: 'interactive',
					attrs: { type: 'native_flow', v: '1' },
					content: [
						{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }
					]
				}
			]
		}
	]
}

function resolveAdditionalNodes(message) {
	const nodes = []
	const visited = new WeakSet()

	const walk = obj => {
		if (!obj || typeof obj !== 'object') return
		if (visited.has(obj)) return
		visited.add(obj)

		const type = getType(obj)

		if (type) {
			const node = obj[type]

			if (type === 'interactiveMessage') {
				nodes.push(...getInteractiveAdditionalNodes(node))

			} else if (/^pollCreationMessage/i.test(type)) {
				nodes.push({ tag: 'meta', attrs: { polltype: 'creation' } })

			} else if (type === 'eventMessage') {
				nodes.push({ tag: 'meta', attrs: { event_type: 'creation' } })

			} else if (type === 'buttonsMessage') {
				nodes.push({
					tag: 'biz',
					attrs: {},
					content: [
						{
							tag: 'interactive',
							attrs: { type: 'native_flow', v: '1' },
							content: [
								{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }
							]
						}
					]
				})

			} else if (type === 'templateMessage') {
				nodes.push({
					tag: 'biz',
					attrs: {},
					content: [
						{
							tag: 'interactive',
							attrs: { type: 'native_flow', v: '1' },
							content: [
								{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }
							]
						}
					]
				})

			} else if (type === 'productMessage' || type === 'invoiceMessage') {
				nodes.push({ tag: 'biz', attrs: {}, content: [] })

			} else if (type === 'orderMessage') {
				nodes.push({ tag: 'biz', attrs: { native_flow_name: 'order_details' } })

			} else if (
				type === 'requestPaymentMessage' ||
				type === 'sendPaymentMessage' ||
				type === 'declinePaymentRequestMessage' ||
				type === 'cancelPaymentRequestMessage'
			) {
				nodes.push({
					tag: 'biz',
					attrs: {},
					content: [
						{
							tag: 'interactive',
							attrs: { type: 'native_flow', v: '1' },
							content: [
								{ tag: 'native_flow', attrs: { name: 'payment_key_info' } }
							]
						}
					]
				})
			}
		}

		for (const key in obj) {
			const value = obj[key]
			if (value && typeof value === 'object') walk(value)
		}
	}

	walk(message)

	const seen = new Set()
	return nodes.filter(node => {
		const k = JSON.stringify({ tag: node.tag, attrs: node.attrs })
		if (seen.has(k)) return false
		seen.add(k)
		return true
	})
}

function walkTree(message) {
	const relayOptions = {}
	const visited = new WeakSet()

	const walk = obj => {
		if (!obj || typeof obj !== 'object') return
		if (visited.has(obj)) return
		visited.add(obj)

		const type = getType(obj)

		if (type && obj[type]) {
			const node = obj[type]
			for (const mw of messageMiddleware) {
				if (mw.types.some(rule => matchType(type, rule))) {
					mw.run(node, obj, type)
				}
			}
		}

		for (const key in obj) {
			const value = obj[key]
			if (value && typeof value === 'object') walk(value)
		}
	}

	walk(message)

	const additionalNodes = resolveAdditionalNodes(message)
	if (additionalNodes.length) {
		relayOptions.additionalNodes = additionalNodes
	}

	return relayOptions
}

const getType = obj => {
	if (!obj || typeof obj !== 'object') return null
	return Object.keys(obj).find(k => k.endsWith('Message')) || null
}

function matchType(type, rule) {
	if (rule instanceof RegExp) return rule.test(type)
	return rule === type
}

function stringify(obj) {
	return JSON.stringify(obj, (key, value) => {
		if (Buffer.isBuffer(value)) return value.toString('base64')
		if (value?.type === 'Buffer' && Array.isArray(value.data)) {
			return Buffer.from(value.data).toString('base64')
		}
		return value
	}, 2)
}

function mergeOptions(target, source) {
	for (const key in source) {
		if (Array.isArray(source[key])) {
			target[key] = target[key] || []
			target[key].push(...source[key])
		} else if (typeof source[key] === 'object') {
			target[key] = target[key] || {}
			mergeOptions(target[key], source[key])
		} else {
			target[key] = source[key]
		}
	}
}

export default {
  command: ['crm', 'relay', 'evalrelay'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  async run(m, { Shoyu, text, command, usedPrefix }) {
  
  
  	if (command === 'evalrelay') {
  		const id = text.trim()
  		if (!id) return m.reply('ID relay?')
  		const code = global.relayStore?.[id]
  		if (!code) return m.reply('Relay expired')
  		try {
  			await eval(`(async () => { ${code} })()`)
  			delete global.relayStore[id]
  		} catch (e) {
  			m.reply(String(e))
  		}
  		return
  	}
  
  	if (command === 'relay') {
  		if (!m.quoted) return m.reply('Reply pesannya!')
  		const msg = global.store.loadMessage(m.quoted.remoteJid || m.chat, m.quoted.id) || m.quoted.fakeObj
  		if (!msg) return m.reply('Pesan tidak ditemukan!')
  		if (!msg.message) return m.reply('Message kosong!')
  		const relayOptions = walkTree(msg.message)
  		const relay = await Shoyu.relayMessage(m.chat, msg.message, relayOptions)
  		return m.reply(JSON.stringify(relay, null, 2))
  	}
  
  	if (command === 'crm') {
  		if (!m.quoted) return m.reply('Reply pesannya!')
  
  		const msg = global.store.loadMessage(m.quoted.remoteJid || m.chat, m.quoted.id) || m.quoted.fakeObj
  		if (!msg) return m.reply('Pesan tidak ditemukan!')
  		if (!msg.message) return m.reply('Message kosong!')
  
  		const type = m.quoted.mtype || getType(msg.message)
  		const relayOptions = walkTree(msg.message)
  
  		const raw = stringify(msg)
  		const message = stringify(msg.message)
  		const key = stringify(msg.key)
  		const participant = m.sender || msg.key?.remoteJid || msg.key?.participant || '-'
  		const msgId = msg.key?.id || '-'
  		const fullOptionsStr = stringify(relayOptions)
  
  		const relayId = crypto.randomBytes(5).toString('hex')
  
  		const relayCode = `await Shoyu.relayMessage(
    m.chat,
    ${message},
    ${fullOptionsStr}
  )`.trim()
  
  		global.relayStore[relayId] = relayCode
  
  		// upload file relay ke WA media server
  		let mediaObj = {
  			documentMessage: {
  				url: 'https://mmg.whatsapp.net',
  				mimetype: 'application/javascript',
  				title: `${type || 'message'}.js`,
  				fileName: `${type || 'message'}.js`,
  				fileLength: relayCode.length,
  				pageCount: 1,
  				mediaKey: crypto.randomBytes(32),
  				fileSha256: crypto.randomBytes(32),
  				fileEncSha256: crypto.randomBytes(32),
  				directPath: '/v/t62.7118-24/fake'
  			}
  		}
  
  		try {
  			const uploaded = await prepareWAMessageMedia(
  				{ document: Buffer.from(relayCode), mimetype: 'application/javascript' },
  				{ upload: Shoyu.waUploadToServer }
  			)
  			mediaObj = {
  				documentMessage: {
  					...uploaded.documentMessage,
  					title: `${type || 'message'}.js`,
  					fileName: `${type || 'message'}.js`
  				}
  			}
  		} catch {}
  
  		await new Button(Shoyu)
  			.setTitle(String(type || 'Unknown'))
  			.setBody('Results Create relay message')
  			.setFooter(`${global.footer}`)
  			.setMedia(mediaObj)
  			.setParams({
  				bottom_sheet: {
  					in_thread_buttons_limit: 1,
  					list_title: `Powored By ${global.footer}`,
  					button_title: 'select'
  				}
  			})
  			.addCopy('Copy relay', relayCode)
  			.addCopy('Copy raw', raw)
  			.addCopy('Copy message', message)
  			.addCopy('Copy key', key)
  			.addCopy('Copy sender', participant)
  			.addCopy('Copy msgId', msgId)
  			.addCopy('Copy options', fullOptionsStr)
  			.addQuickReply('Eval code', `${usedPrefix}evalrelay ${relayId}`)
  			.send(m.chat, { quoted: m })
  	}
  
  }
};