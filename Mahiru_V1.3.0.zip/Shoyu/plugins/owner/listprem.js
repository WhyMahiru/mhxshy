/**
 * Plugin CekPrem
 * ----------------
 * case 'cekprem' -> tampilkan semua daftar premium — owner only
 */
import { getPremiumList, getPremiumDetail } from '../../src/lib/database.js';

function formatSisaWaktu(ms) {
  if (ms == null) return 'ᴘᴇʀᴍᴀɴᴇɴᴛ';
  if (ms <= 0) return 'ᴇxᴘɪʀᴇᴅ';

  const sec = Math.floor(ms / 1000);
  const bulan = Math.floor(sec / (30 * 24 * 3600));
  let sisa = sec % (30 * 24 * 3600);
  const hari = Math.floor(sisa / (24 * 3600));
  sisa %= 24 * 3600;
  const jam = Math.floor(sisa / 3600);
  sisa %= 3600;
  const menit = Math.floor(sisa / 60);
  const detik = sisa % 60;

  const parts = [];
  if (bulan > 0) parts.push(`${bulan} ʙᴜʟᴀɴ`);
  if (hari > 0) parts.push(`${hari} ʜᴀʀɪ`);
  if (jam > 0) parts.push(`${jam} ᴊᴀᴍ`);
  if (menit > 0) parts.push(`${menit} ᴍᴇɴɪᴛ`);
  if (detik > 0 || parts.length === 0) parts.push(`${detik} ᴅᴇᴛɪᴋ`);

  return parts.join(' ');
}

export default {
  command: ['cekprem', 'listprem'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { reply }) {
    if (m.isBaileys) return m.reply('ngapain 😂?');

    const list = getPremiumList();
    if (list.length === 0) return reply('📋 ʙᴇʟᴜᴍ ᴀᴅᴀ ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ sᴀᴀᴛ ɪɴɪ.');

    let teks = `📋 *𝗗𝗔𝗙𝗧𝗔𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠* (${list.length})\n\n`;
    list.forEach((jid, i) => {
      const detail = getPremiumDetail(jid);
      const sisaMs = detail?.expired_at ? detail.expired_at - Date.now() : null;
      teks += `${i + 1}. @${jid.split('@')[0]}\n   ⏳ sɪsᴀ: ${formatSisaWaktu(sisaMs)}\n\n`;
    });

    reply(teks.trim(), { mentions: list });
  }
};