export default {
  command: ["gconly"],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply, args, command, usedPrefix, updateData }) {
    let status = (args[0] || "").toLowerCase();
    
    if (!["on", "off"].includes(status)) {
      return reply(`Contoh: ${usedPrefix + command} on/off`);
    }

    const isEnable = status === "on";
    const dbValue = isEnable ? 1 : 0;

    try {
      global.gconly = isEnable;
      await updateData('settings', 'bot', 'gconly', dbValue);

      if (isEnable) {
        global.pconly = false;
        await updateData('settings', 'bot', 'pconly', 0);
      }

      m.reply(`Mode *${command.toUpperCase()}* berhasil di${isEnable ? 'aktifkan' : 'matikan'}`);

    } catch (e) {
      console.error(e);
      reply('Gagal menyimpan ke database.');
    }
  }
};