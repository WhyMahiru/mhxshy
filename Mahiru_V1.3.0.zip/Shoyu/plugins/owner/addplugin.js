import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
  command: ['addplugin', 'addp'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, text, command, reply, usedPrefix }) {
    try {
      let fileName, fileContent;
      if (m.quoted && m.quoted.text) {
        fileName = text.trim();
        fileContent = m.quoted.text;
      } else {
        if (!text) return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*`);

        const splitIndex = text.indexOf(' ');
        if (splitIndex === -1) return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*`);

        fileName = text.substring(0, splitIndex).trim();
        fileContent = text.substring(splitIndex + 1).trim();
      }

      if (!fileName.endsWith('.js')) {
        return reply(`Gagal! Nama file harus berakhiran *.js*\nContoh: *command/menu.js*`);
      }

      // Validasi format plugin (format export default { ... })
      const hasExport = /export\s+default\s+\{/.test(fileContent);
      const hasCommand = /command\s*:/.test(fileContent);
      const hasRun = /async\s+run\s*\(/.test(fileContent);

      if (!hasExport || !hasCommand || !hasRun) {
        const contoh = `export default {\n  command: ['tes'],\n  group: false,\n  limit: false,\n  premium: false,\n  admin: false,\n  owner: true,\n  botAdmin: false,\n  privates: false,\n  usePrefix: true,\n  disable: false,\n  noJadiBot: true,\n  async run(m, { Shoyu }) {\n    m.reply('contoh!!')\n  }\n};`;
        return reply(`*Format plugin tidak valid!*\n\n*Contoh kode plugin benar:*\n\`\`\`\n${contoh}\n\`\`\``);
      }

      const pluginsDir = path.join(__dirname, '../../plugins');
      const fullPath = path.join(pluginsDir, fileName);
      const dir = path.dirname(fullPath);

      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

      fs.writeFileSync(fullPath, fileContent, 'utf8');
      reply(`✅ Plugin *${fileName}* berhasil ditambahkan!\n\n> Restart bot agar plugin aktif.`);
    } catch (err) {
      console.error(err);
      reply(`❌ Gagal: ${err.message}`);
    }
  }
};
