import { delay } from '@whiskeysockets/baileys';

async function trickDelete(Shoyu, chatId, targetId) {
    const t1 = await Shoyu.relayMessage(
        chatId,
        {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: '',
                        contextInfo: { isGroupStatus: true }
                    }
                }
            }
        },
        {}
    );

    const t2 = await Shoyu.relayMessage(
        chatId,
        {
            protocolMessage: {
                key: { jid: chatId, fromMe: true, id: t1 },
                type: 14,
                editedMessage: {
                    extendedTextMessage: {
                        text: '\0',
                        contextInfo: { isGroupStatus: false }
                    }
                }
            }
        },
        { messageId: targetId }
    );

    await delay(150);

    await Promise.allSettled([
        Shoyu.sendMessage(chatId, {
            delete: { remoteJid: chatId, id: t1, fromMe: true }
        }),
        Shoyu.sendMessage(chatId, {
            delete: { remoteJid: chatId, id: t2, fromMe: true }
        })
    ]);
}

export default {
    command: ['dmsg', 'delmsg'],
    group: true,
    limit: false,
    premium: false,
    admin: false,
    owner: true,
    botAdmin: false,
    privates: false,
    noJadiBot: false,

    async run(m, { Shoyu, args, reply, usedPrefix, command }) {
        if (!m.isGroup) return;

        const chatId = m.chat;
        const cmdId = m.key.id;
        const jumlah = parseInt(args[0]);

        // ================= MODE: .dmsg 50 =================
        if (jumlah && jumlah > 0) {
            if (jumlah > 50) {
                return reply('❌ Maksimal 50 pesan per eksekusi!');
            }

            if (!global.store?.getRecentMessages) {
                return;
            }

            const keys = global.store.getRecentMessages(chatId, jumlah);

            if (!keys.length) {
                return;
            }

            try {
                for (const key of keys) {
                    try {
                        await trickDelete(Shoyu, chatId, key.id);
                    } catch (e) {
                        console.error('[DMSG] Gagal hapus satu pesan:', e.message);
                    }
                }

                await trickDelete(Shoyu, chatId, cmdId);

            } catch (e) {
                console.error('[DMSG] Error:', e);
            }

            return;
        }

        if (!m.quoted) {
            return reply(
            `𝗖𝗔𝗥𝗔 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔\n\n` +
            `${usedPrefix + command} ʀᴇᴘʟʏ ᴘᴇsᴀɴɴʏᴀ\n` +
            `${usedPrefix + command} 10 ( ᴍᴀx 50 )`
            );
        }

        const stanzaId = m.quoted.id;

        try {
            await trickDelete(Shoyu, chatId, stanzaId);
            await trickDelete(Shoyu, chatId, cmdId);
        } catch (e) {
            console.error('[DMSG] Error:', e);
        }
    }
};