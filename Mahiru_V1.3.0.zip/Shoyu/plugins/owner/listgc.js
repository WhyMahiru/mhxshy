export default {
  command: ['listgc', 'listgroup', 'cekgc'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,

  async run(m, { Shoyu }) {
    const sent = await Shoyu.sendMessage(m.chat, { text: '⏳ Mengambil daftar grup...' }, { quoted: m });
    const key = sent.key;

    try {
      const groups = await Shoyu.groupFetchAllParticipating();
      const list = Object.values(groups || {});

      if (!list.length) {
        return Shoyu.sendMessage(m.chat, {
          edit: key,
          text: 'Bot belum join grup manapun.',
        });
      }

      list.sort((a, b) => (b.participants?.length || 0) - (a.participants?.length || 0));

      const botNumber = (Shoyu.decodeJid ? Shoyu.decodeJid(Shoyu.user.id) : Shoyu.user.id)
        .replace(/[^0-9]/g, '');

      const lines = list.map((g, i) => {
        const totalMember = g.participants?.length || 0;
        const isBotAdmin = g.participants?.some((p) => {
          const candidates = [p.id, p.jid, p.phoneNumber, p.lid].filter(Boolean);
          const matches = candidates.some((c) => c.replace(/[^0-9]/g, '') === botNumber);
          return matches && ['admin', 'superadmin'].includes(p.admin);
        });
        return (
          `*${i + 1}. ${g.subject || '(ᴛᴀɴᴘᴀ ɴᴀᴍᴀ)'}*\n` +
          `   ɪᴅ: ${g.id}\n` +
          `   ᴍᴇᴍʙᴇʀ: ${totalMember} | ʙᴏᴛ ᴀᴅᴍɪɴ: ${isBotAdmin ? '✅' : '❌'}`
        );
      });

      const teks =
        `📋 *𝗟𝗜𝗦𝗧 𝗚𝗥𝗢𝗨𝗣 𝗕𝗢𝗧* (${list.length})\n` +
        `${'─'.repeat(24)}\n\n` +
        lines.join('\n\n');

      const maxLen = 4000;
      const finalText = teks.length > maxLen
        ? teks.slice(0, maxLen) + `\n\n…(dipotong, total ${list.length} grup)`
        : teks;

      await Shoyu.sendMessage(m.chat, {
        edit: key,
        text: finalText,
      });
    } catch (err) {
      console.log(err);
      await Shoyu.sendMessage(m.chat, {
        edit: key,
        text: '❌ Gagal mengambil daftar grup.',
      });
    }
  },
};