import { runBackup } from '../../src/lib/autobackup.js';

export default {
  command: ['backup'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,

  async run(m, { Shoyu, reply }) {
    const ownerJids = (global.owner || []).map((v) => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');

    if (!ownerJids.length) return reply('Nomor owner belum diatur di *global.owner* (settings/setting.js).');

    try {
      await reply('⏳ Memproses backup...');
      await runBackup(Shoyu, ownerJids);
      if (m.chat !== ownerJids[0]) {
        reply(`📬 Backup telah dikirim ke nomor owner (${ownerJids.length} nomor).`);
      }
    } catch (e) {
      reply('❌ Backup gagal: ' + e.message);
    }
  }
};