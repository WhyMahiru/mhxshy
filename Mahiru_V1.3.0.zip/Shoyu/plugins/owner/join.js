export default {
  command: ['join', 'masuk'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, args, usedPrefix, command, reply }) {
    const sumberTeks = [args.join(' '), m.quoted?.text || ''].join(' ');
    const match = sumberTeks.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i);

    if (!match) {
      return reply(
        `Masukkan/reply link grup WhatsApp yang valid.\n\nContoh: ${usedPrefix + command} https://chat.whatsapp.com/xxxxxxxxxxxxx`
      );
    }

    const code = match[1];

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const info = await Shoyu.groupGetInviteInfo(code).catch(() => null);
      await Shoyu.groupAcceptInvite(code);

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return reply(`Berhasil join ke grup${info?.subject ? ` *${info.subject}*` : ''}!`);
    } catch (err) {
      console.error(err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return reply('Gagal join grup! Kemungkinan link sudah kadaluarsa, grup penuh, atau bot sudah kena banned dari grup tersebut.');
    }
  }
};
