export default {
  command: ["autotyping"],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { reply, args, command, usedPrefix, updateData }) {
    let status = (args[0] || "").toLowerCase();

    if (!["on", "off"].includes(status)) {
      return reply(
        `📝 *𝗔𝘂𝘁𝗼 𝗧𝘆𝗽𝗶𝗻𝗴*\n\n` +
        `> Status: *${global.autotyping ? "Aktif ✅" : "Nonaktif ❌"}*\n\n` +
        `Contoh: ${usedPrefix + command} on/off`
      );
    }

    const isEnable = status === "on";
    const dbValue = isEnable ? 1 : 0;

    try {
      global.autotyping = isEnable;
      await updateData('settings', 'bot', 'autotyping', dbValue);

      m.reply(`Auto Typing berhasil di${isEnable ? 'aktifkan ✅' : 'matikan ❌'}`);
    } catch (e) {
      console.error(e);
      reply('Gagal menyimpan ke database.');
    }
  }
};
