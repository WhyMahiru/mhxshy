import { bots, startJadiBot, stopJadiBot, normalizeNumber } from '../../src/lib/jadibot.js';

export default {
	command: ['jadibot', 'listjadibot', 'listbot', 'stopjadibot', 'stopbot'],
	group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: true,
	botAdmin: false,
	privates: false,
	noJadiBot: true,

	async run(m, { command, args, usedPrefix }) {
		switch (command) {

			// @owner--jadibot
			case 'jadibot': {
				const number = normalizeNumber(args[0] || '');
				if (!number) return m.reply(`Masukkan nomor terdaftar di WhatsApp!\n\nExample: ${usedPrefix}jadibot 628xxxx`);
				if (bots.has(number)) return m.reply('Bot sudah aktif');
				await m.reply('Load pairing code. . .');
				await startJadiBot(number, m);
				break;
			}

			// @owner--listjadibot
			case 'listjadibot':
			case 'listbot': {
				if (bots.size === 0) return m.reply('Tidak ada jadibot aktif');
				let text = '*List jadibot:*\n\n';
				for (const [num] of bots) text += `• ${num}\n`;
				return m.reply(text.trim());
			}

			// @owner--stopjadibot
			case 'stopjadibot':
			case 'stopbot': {
				const number = normalizeNumber(args[0] || '');
				if (!number) return m.reply(`Example: ${usedPrefix}stopjadibot 62xxx\n\n${usedPrefix}listjadibot untuk melihat nomor`);
				const stopped = await stopJadiBot(number);
				if (!stopped) return m.reply('Nomor tidak ditemukan sebagai jadibot');
				return m.reply('*Jadibot* berhasil dimatikan!');
			}
		}
	},
};
