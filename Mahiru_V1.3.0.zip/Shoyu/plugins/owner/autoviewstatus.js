export default {
  command: ["autoviewstatus", "autoview"],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { reply, args, command, usedPrefix, updateData }) {
    let status = (args[0] || "").toLowerCase();

    if (!["on", "off"].includes(status)) {
      return reply(
        `👀 *𝗔𝘂𝘁𝗼 𝗩𝗶𝗲𝘄 𝗦𝘁𝗮𝘁𝘂𝘀*\n\n` +
        `> Status: *${global.autoviewstatus ? "Aktif ✅" : "Nonaktif ❌"}*\n\n` +
        `Contoh: ${usedPrefix + command} on/off`
      );
    }

    const isEnable = status === "on";
    const dbValue = isEnable ? 1 : 0;

    try {
      global.autoviewstatus = isEnable;
      await updateData('settings', 'bot', 'autoviewstatus', dbValue);

      m.reply(`Auto View Status berhasil di${isEnable ? 'aktifkan ✅' : 'matikan ❌'}`);
    } catch (e) {
      console.error(e);
      reply('Gagal menyimpan ke database.');
    }
  }
};
