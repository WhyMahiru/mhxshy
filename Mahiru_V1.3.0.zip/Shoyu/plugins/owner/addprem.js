import ms from 'ms';
import { addPremium, isPremiumUser } from '../../src/lib/database.js';

export default {
  command: ['addprem', 'addpremium'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, args, reply, example, command, usedPrefix }) {
    if (m.isBaileys) return m.reply('ngapain 😂?');

    const raw = args[0] || '';
    const [nomorRaw, durasiRaw] = raw.split('|');

    let nomor;
    if (m.quoted) {
      nomor = m.quoted.sender.replace(/[^0-9]/g, '');
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      nomor = Shoyu.getJid(m.mentionedJid[0]).replace(/[^0-9]/g, '');
    } else if (nomorRaw) {
      nomor = nomorRaw.replace(/[^0-9]/g, '');
    } else {
      nomor = null;
    }

    if (!nomor) {
  return reply(example(`nomor|durasi\n *${usedPrefix + command}* 628xx|30d\n *${usedPrefix + command}* @tag|30d\n`));
}

    let durationMs = null;
    if (durasiRaw) {
      durationMs = ms(durasiRaw.trim());
      if (!durationMs || isNaN(durationMs) || durationMs <= 0) {
        return reply(`Format durasi tidak valid: "${durasiRaw.trim()}"\nContoh yang valid: 30d, 12h, 1w, 1y`);
      }
    }

    nomor += '@s.whatsapp.net';

    let ceknya = await Shoyu.onWhatsApp(nomor);
    if (ceknya.length == 0) {
      return reply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!`);
    }

    nomor = ceknya[0].jid;

    if (isPremiumUser(nomor)) {
      return reply('Nomor sudah ada di daftar premium');
    }

    addPremium(nomor, durationMs);

    const info = durationMs
      ? `ʙᴇʀʟᴀᴋᴜ sᴇʟᴀᴍᴀ: *${ms(durationMs, { long: true })}*`
      : `ʙᴇʀʟᴀᴋᴜ: *ᴘᴇʀᴍᴀɴᴇɴ*`;

    reply(`ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ${nomor} ᴋᴇ ᴅᴀғᴛᴀʀ ᴘʀᴇᴍɪᴜᴍ\n${info}`);
  }
};