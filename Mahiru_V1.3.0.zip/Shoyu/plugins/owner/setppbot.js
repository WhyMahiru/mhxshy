export default {
  command: ['setppbot', 'setprofilebot'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, usedPrefix, command, reply }) {
    const quoted = m.quoted && ['imageMessage'].includes(m.quoted.mtype) ? m.quoted : (m.mtype === 'imageMessage' ? m : null);
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';

    if (!quoted || !/image/i.test(mime)) {
      return reply(
        `Kirim/reply *foto* dengan caption *${usedPrefix + command}* untuk mengganti foto profil bot.`
      );
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('Gagal ambil fotonya, coba reply/kirim ulang.');
      }

      await Shoyu.updateProfilePicture(Shoyu.user.id, buffer);

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return reply('Berhasil ganti foto profil bot!');
    } catch (err) {
      console.error(err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return reply('Gagal ganti foto profil bot! Pastikan foto yang dikirim valid (format jpg/png, tidak corrupt).');
    }
  }
};
