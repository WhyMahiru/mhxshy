import { addMoney, delMoney, getUserProfile } from '../../src/lib/database.js';

export default {
  command: ['addmoney', 'delmoney'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, args, command, reply, usedPrefix, example }) {
    const raw0 = args[0] || '';
    const [rawTarget, pipeJumlah] = raw0.split('|');

    let nomor, jumlah;

    if (m.quoted) {
      nomor = m.quoted.sender;
      jumlah = parseInt(pipeJumlah || args[0]);
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      nomor = Shoyu.getJid(m.mentionedJid[0]);
      jumlah = parseInt(pipeJumlah || args[1]);
    } else if (rawTarget) {
      nomor = rawTarget.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
      jumlah = parseInt(pipeJumlah || args[1]);
    } else {
      nomor = null;
    }

    if (!nomor) {
      return reply(example(`tag/nomor|jumlah\n *${usedPrefix + command}* 628xx|5000\n *${usedPrefix + command}* @tag|5000\n(atau reply pesan langsung ${usedPrefix + command} 1000)`
      ));
    }

    if (isNaN(jumlah) || jumlah <= 0) return reply('❌ Masukkan jumlah money yang valid!');

    const user = getUserProfile(nomor);
    if (!user) return reply('❌ User belum terdaftar!');

    const oldMoney = user.money;

    switch (command) {

      // @owner--addmoney
      case 'addmoney': {
        addMoney(nomor, jumlah);
        const updated = getUserProfile(nomor);
        return Shoyu.sendMessage(
          m.chat,
          {
            text: `✅ *Berhasil tambah money!*\n\n` +
              `👤 @${nomor.split('@')[0]}\n` +
              `💰 Money : *${formatMoney(oldMoney)}* → *${formatMoney(updated?.money ?? oldMoney + jumlah)}*`,
            mentions: [nomor],
          },
          { quoted: m }
        );
      }

      // @owner--delmoney
      case 'delmoney': {
        delMoney(nomor, jumlah);
        const updated = getUserProfile(nomor);
        return Shoyu.sendMessage(
          m.chat,
          {
            text: `✅ *Berhasil kurangi money!*\n\n` +
              `👤 @${nomor.split('@')[0]}\n` +
              `💰 Money : *${formatMoney(oldMoney)}* → *${formatMoney(updated?.money ?? Math.max(0, oldMoney - jumlah))}*`,
            mentions: [nomor],
          },
          { quoted: m }
        );
      }
    }
  }
};
