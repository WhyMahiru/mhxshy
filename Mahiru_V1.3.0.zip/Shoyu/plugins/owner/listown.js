import fs from 'fs';

export default {
  command: ['listown', 'listowner'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, text, reply, owners }) {
  
  	if (m.isBaileys) return m.reply('ngapain 😂?');
  
  	if (owners.length < 1) return m.reply('Tidak ada owner tambahan');
  	let teks = `*List Owner*:\n\n`;
  	for (let i of owners) {
  		teks += `* ${i.split('@')[0]} (@${i.split('@')[0]})\n`;
  	}
  	Shoyu.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: m });
  
  }
};
