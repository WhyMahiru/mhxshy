
export default {
  command: ['prefix', 'setprefix', 'setp'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { command, args, usedPrefix, updateData }) {
    switch (command) {

      // @owner--setprefix
      case 'setprefix': 
      case 'setp': {
        if (!args[0]) {
          return m.reply(`*Cara penggunan:*
- ${usedPrefix}setprefix [new prefix]

*Contoh penggunaan*
- ${usedPrefix}setprefix /`);
        }

        const newPrefix = args[0];
        global.prefix = newPrefix;
        await updateData('settings', 'bot', 'prefix', newPrefix);

        return m.reply(`Prefix *[ ${usedPrefix} ]* berhasil di ubah menjadi *[ ${newPrefix} ]*`);
      }

      // @owner--prefix
      case 'prefix': {
        const mode = args[0] ? args[0].toLowerCase() : '';

        if (mode === 'on') {
          if (global.multiprefix) return m.reply('Sudah dalam mode aktif!');
          let p = global.prefix || '.';
          global.multiprefix = true;
          await updateData('settings', 'bot', 'multiprefix', 1);
          return m.reply(`*Prefix ON ✅*
            
Gunakan awalan prefix *${p}* untuk memulai bot!

${usedPrefix}setprefix *untuk mengganti prefix*
${usedPrefix}prefix off *agar tanpa prefix*`);
        }

        if (mode === 'off') {
          if (!global.multiprefix) return m.reply('Sudah dalam mode offline!');
          global.multiprefix = false;
          await updateData('settings', 'bot', 'multiprefix', 0);
          return m.reply(`*Prefix OFF ✅*
            
*Gunakan bot tanpa awalan prefix*
${usedPrefix}prefix on *agar menggunakan prefix*`);
        }

        let status = global.multiprefix ? 'ON' : 'OFF';
        let p = global.prefix || '.';

        let msg = `*Prefix settings*
- Mode prefix : *${status}*
- Prefix saat ini : *${p}*

*Command :*
- ${usedPrefix}prefix on *menggunakan prefix*
- ${usedPrefix}prefix off *tanpa prefix*
- ${usedPrefix}setprefix *settings prefix*`;

        return m.reply(msg);
      }
    }
  }
};