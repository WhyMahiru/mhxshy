import { addOwner, getOwnerList } from '../../src/lib/database.js';

export default {
  command: ['addown', 'addowner'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,

  async run(m, { Shoyu, args, reply, example }) {
    if (m.isBaileys) return m.reply('ngapain 😂?');

    let nomor;
    if (m.quoted) {
      nomor = m.quoted.sender.replace(/[^0-9]/g, '');
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      nomor = Shoyu.getJid(m.mentionedJid[0]).replace(/[^0-9]/g, '');
    } else if (args[0]) {
      nomor = args[0].replace(/[^0-9]/g, '');
    } else {
      nomor = null;
    }

    if (!nomor) return reply(example(`reply/tag`));
    nomor += '@s.whatsapp.net';

    let ceknya = await Shoyu.onWhatsApp(nomor);
    if (ceknya.length == 0) return reply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!`);

    const ownerList = getOwnerList();
    if (ownerList.includes(nomor)) return reply('Nomor sudah ada di daftar owner.');

    addOwner(nomor);
    reply(`Berhasil menambahkan ${nomor} ke daftar owner.`);
  }
};
