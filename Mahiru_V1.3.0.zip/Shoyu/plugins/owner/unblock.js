export default {
  command: ['unblock', 'unblockir'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, args, reply, example, command, usedPrefix }) {
    if (m.isBaileys) return m.reply('ngapain 😂?');

    let nomor;
    if (m.quoted) {
      nomor = m.quoted.sender.replace(/[^0-9]/g, '');
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      nomor = Shoyu.getJid(m.mentionedJid[0]).replace(/[^0-9]/g, '');
    } else if (args[0]) {
      nomor = args[0].replace(/[^0-9]/g, '');
    } else {
      nomor = null;
    }

    if (!nomor) {
      return reply(example(`nomor\n *${usedPrefix + command}* 628xx\n *${usedPrefix + command}* (reply/tag)\n`));
    }

    const jid = nomor + '@s.whatsapp.net';

    try {
      await Shoyu.updateBlockStatus(jid, 'unblock');
      reply(`✅ Berhasil membuka blokir *${nomor}*`);
    } catch (e) {
      console.error(e);
      reply('Gagal membuka blokir nomor tersebut.');
    }
  }
};
