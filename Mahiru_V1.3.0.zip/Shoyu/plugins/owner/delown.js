import { delOwner, getOwnerList } from '../../src/lib/database.js';

export default {
  command: ['delown', 'delowner'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,

  async run(m, { Shoyu, args, reply, example }) {
    if (m.isBaileys) return m.reply('ngapain 😂?');

    let nomor;
    if (m.quoted) {
      nomor = m.quoted.sender.replace(/[^0-9]/g, '');
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      nomor = Shoyu.getJid(m.mentionedJid[0]).replace(/[^0-9]/g, '');
    } else if (args[0]) {
      nomor = args[0].replace(/[^0-9]/g, '');
    } else {
      nomor = null;
    }

    if (!nomor) return reply(example(`reply/tag`));
    nomor += '@s.whatsapp.net';

    const ownerList = getOwnerList();
    if (!ownerList.includes(nomor)) return reply('Nomor tidak ditemukan di daftar owner.');

    delOwner(nomor);
    reply(`Berhasil menghapus ${nomor} dari daftar owner.`);
  }
};
