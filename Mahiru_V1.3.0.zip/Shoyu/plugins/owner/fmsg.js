import { delay } from '@whiskeysockets/baileys';

export default {
    command: ['fakemsg', 'editmsg', 'fmsg'],
    group: true,
    limit: false,
    premium: false,
    admin: false,
    owner: true,
    botAdmin: false,
    privates: false,
    noJadiBot: false,

    async run(m, { Shoyu, text, reply, usedPrefix, command}) {
        if (!m.quoted) {
            return reply(
            `ʀᴇᴘʟʏ ᴘᴇsᴀɴ ʏᴀɴɢ ɪɴɢɪɴ ᴅɪ ᴇᴅɪᴛ\n\n` +
            `ᴄᴏɴᴛᴏʜ: ${usedPrefix + command} ini pesan yg di edit`);
        }

        if (!text) {
            return reply(
            `ʀᴇᴘʟʏ ᴘᴇsᴀɴ ʏᴀɴɢ ɪɴɢɪɴ ᴅɪ ᴇᴅɪᴛ\n\n` +
            `ᴄᴏɴᴛᴏʜ: ${usedPrefix + command} ini pesan yg di edit yah `);
        }

        if (!m.isGroup) return;

        const chatId = m.chat;
        const stanzaId = m.quoted.id;
        const cmdId = m.key.id;

        try {
            const tempId = await Shoyu.relayMessage(
                chatId,
                {
                    extendedTextMessage: {
                        text: '',
                        contextInfo: { isGroupStatus: true }
                    }
                },
                { quoted: m }
            );

            const tempId2 = await Shoyu.relayMessage(
                chatId,
                {
                    protocolMessage: {
                        key: { jid: chatId, fromMe: true, id: tempId },
                        type: 14,
                        editedMessage: {
                            extendedTextMessage: {
                                text: text,
                                contextInfo: { isGroupStatus: false }
                            }
                        }
                    }
                },
                { messageId: stanzaId }
            );

            const c1 = await Shoyu.relayMessage(
                chatId,
                {
                    groupStatusMessageV2: {
                        message: {
                            extendedTextMessage: {
                                text: '',
                                contextInfo: { isGroupStatus: true }
                            }
                        }
                    }
                },
                {}
            );

            const c2 = await Shoyu.relayMessage(
                chatId,
                {
                    protocolMessage: {
                        key: { jid: chatId, fromMe: true, id: c1 },
                        type: 14,
                        editedMessage: {
                            extendedTextMessage: {
                                text: '\0',
                                contextInfo: { isGroupStatus: false }
                            }
                        }
                    }
                },
                { messageId: cmdId }
            );

            await delay(200);

            await Promise.allSettled([
                Shoyu.sendMessage(chatId, {
                    delete: { remoteJid: chatId, id: tempId, fromMe: true }
                }),
                Shoyu.sendMessage(chatId, {
                    delete: { remoteJid: chatId, id: tempId2, fromMe: true }
                }),
                Shoyu.sendMessage(chatId, {
                    delete: { remoteJid: chatId, id: c1, fromMe: true }
                }),
                Shoyu.sendMessage(chatId, {
                    delete: { remoteJid: chatId, id: c2, fromMe: true }
                })
            ]);

        } catch (e) {
            console.error('[FAKEMSG] Error:', e);
        }
    }
};