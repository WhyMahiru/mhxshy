import fs from 'fs';
import path from 'path';

// Folder yang tidak boleh ditampilkan
const ignoredFolders = ['sessions', 'session', 'auth', 'Auth', '.sessions', 'node_modules', 'npm', '.npm', '_npm', '.git', 'tmp', 'temp'];

function getAllFiles(dir, fileList = []) {
	const files = fs.readdirSync(dir);

	for (let file of files) {
		const fullPath = path.join(dir, file);
		const relPath = path.relative(process.cwd(), fullPath);
		if (ignoredFolders.some((folder) => relPath.startsWith(folder))) continue;

		const stat = fs.statSync(fullPath);

		if (stat.isDirectory()) {
			getAllFiles(fullPath, fileList);
		} else {
			fileList.push(fullPath);
		}
	}

	return fileList;
}

export default {
  command: ['listfile', 'lf', 'listfiles'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, reply, usedPrefix }) {
  
  	try {
  		const root = process.cwd();
  		const allFiles = getAllFiles(root);
  
  		let text = `*LIST ALL FILES*\n`;
  
  		allFiles.forEach((f, i) => {
  			text += `> ./${f.replace(root + '/', '')}\n`;
  		});
  		text += `\n*COMMAND VALID*
  - ${usedPrefix}gantifile
  - ${usedPrefix}getfile`;
  
  		reply(text);
  	} catch (err) {
  		console.log(err);
  		reply('❌ Error saat mengambil list file.');
  	}
  
  }
};
