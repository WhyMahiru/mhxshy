import { PassThrough } from 'stream'
import ffmpeg from 'fluent-ffmpeg'

async function toVN(buffer) {
	return new Promise((resolve, reject) => {
		const input = new PassThrough()
		const output = new PassThrough()
		const chunks = []

		input.end(buffer)

		ffmpeg(input)
			.noVideo()
			.audioCodec('libopus')
			.format('ogg')
			.on('error', reject)
			.on('end', () => resolve(Buffer.concat(chunks)))
			.pipe(output)

		output.on('data', c => chunks.push(c))
	})
}

export default {
  command: ['swgc'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix }) {
  
  
  	let args = (text || '')
  		.split('|')
  		.map(v => v.trim())
  		.filter(v => v)
  
  	let teks = ''
  	let warna = ''
  	let target = ''
  
  	for (let v of args) {
  		if (/chat\.whatsapp\.com\//i.test(v)) {
  			target = v
  		} else if (/@g\.us$/.test(v) || /^\d+$/.test(v)) {
  			target = v
  		} else if (!teks) {
  			teks = v
  		} else if (!warna) {
  			warna = v
  		}
  	}
  
  	let jid = m.chat
  
  	if (target) {
  		if (/chat\.whatsapp\.com\//i.test(target)) {
  			const code = target.split('chat.whatsapp.com/')[1]
  			try {
  				const info = await Shoyu.groupGetInviteInfo(code)
  				jid = info.id
  			} catch {
  				return m.reply('Link grup tidak valid / bot belum join')
  			}
  		} else {
  			jid = /^\d+$/.test(target) ? target + '@g.us' : target
  		}
  	}
  
  	const quoted = m.quoted || m
  	const mime = quoted.mimetype || ''
  	const caption = quoted.caption || teks || ''
  
  	const warnaMap = {
  		biru: '#34B7F1',
  		hijau: '#25D366',
  		kuning: '#FFD700',
  		jingga: '#FF8C00',
  		merah: '#FF3B30',
  		ungu: '#9C27B0',
  		abu: '#9E9E9E',
  		hitam: '#000000',
  		putih: '#FFFFFF',
  		cyan: '#00BCD4'
  	}
  
  	const colors = Object.values(warnaMap)
  	const bgColor = warna
  		? warnaMap[warna.toLowerCase()]
  		: colors[Math.floor(Math.random() * colors.length)]
  
  	if (!caption && !m.quoted) {
  		return m.reply(`
  *Example:*
  
  ${usedPrefix}swgc halo
  ${usedPrefix}swgc halo|merah
  ${usedPrefix}swgc halo|linkgrup atau groupid
  
  Reply foto/video/audio/sticker:
  ${usedPrefix}swgc
  ${usedPrefix}swgc linkgrup atau groupid
  		`.trim())
  	}
  
  	if (/image/i.test(mime)) {
  		const buffer = await quoted.download()
  		await Shoyu.sendMessage(jid, {
  			image: buffer,
  			caption,
  			contextInfo: { isGroupStatus: true }
  		})
  		return m.reply(`Succes upload status!\n*GroupID:* ${jid}`)
  	}
  
  	if (/video/i.test(mime)) {
  		const buffer = await quoted.download()
  		await Shoyu.sendMessage(jid, {
  			video: buffer,
  			caption,
  			contextInfo: { isGroupStatus: true }
  		})
  		return m.reply(`Succes upload status!\n*GroupID:* ${jid}`)
  	}
  
  	if (/audio/i.test(mime)) {
  		const buffer = await quoted.download()
  		const vn = await toVN(buffer)
  		await Shoyu.sendMessage(jid, {
  			audio: vn,
  			ptt: true,
  			mimetype: 'audio/ogg; codecs=opus',
  			contextInfo: { isGroupStatus: true }
  		})
  		return m.reply(`Succes upload status!\n*GroupID:* ${jid}`)
  	}
  
  	if (/sticker/i.test(mime)) {
  		const buffer = await quoted.download()
  		await Shoyu.sendMessage(jid, {
  			sticker: buffer,
  			contextInfo: { isGroupStatus: true }
  		})
  		return m.reply(`Succes upload status!\n*GroupID:* ${jid}`)
  	}
  
  	await Shoyu.sendMessage(jid, {
  		text: caption,
  		backgroundColor: bgColor,
  		contextInfo: { isGroupStatus: true }
  	})
  
  	return m.reply(`Succes upload status!\n*GroupID:* ${jid}`)
  
  }
};
