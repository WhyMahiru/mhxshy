import { addLevel, setLevel, getUserProfile } from '../../src/lib/database.js';
import { getRole } from '../../src/lib/level.js';

export default {
  command: ['addlevel', 'setlevel', 'dellevel'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, args, command, reply, usedPrefix, example}) {
    const raw0 = args[0] || '';
    const [rawTarget, pipeJumlah] = raw0.split('|');

    let nomor, jumlah;

    if (m.quoted) {
      nomor = m.quoted.sender;
      jumlah = parseInt(pipeJumlah || args[0]);
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      nomor = Shoyu.getJid(m.mentionedJid[0]);
      jumlah = parseInt(pipeJumlah || args[1]);
    } else if (rawTarget) {
      nomor = rawTarget.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
      jumlah = parseInt(pipeJumlah || args[1]);
    } else {
      nomor = null;
    }

    if (!nomor) {
      return reply(example(`tag/nomor|durasi\n *${usedPrefix + command}* 628xx|5\n *${usedPrefix + command}* @tag|5`
      ));
    }

    if (isNaN(jumlah) || jumlah <= 0) return reply('❌ Masukkan jumlah level yang valid!');

    const user = getUserProfile(nomor);
    if (!user) return reply('❌ User belum terdaftar!');

    const oldLevel = user.level;
    const oldRole = getRole(oldLevel);

    switch (command) {
    
      // @owner--addlevel
      case 'addlevel': {
        addLevel(nomor, jumlah);
        const newLevel = oldLevel + jumlah;
        const newRole = getRole(newLevel);
        await reply(
          `✅ *Berhasil tambah level!*\n\n` +
          `👤 @${nomor.split('@')[0]}\n` +
          `📊 Level : *${oldLevel}* → *${newLevel}*\n` +
          `🎖️ Rank  : *${newRole}*`,
          { mentions: [nomor] }
        );
        if (newRole !== oldRole) {
          await Shoyu.sendMessage(m.chat, {
            text: `🎊 *RANK UP!* @${nomor.split('@')[0]}\n\n${oldRole} → *${newRole}*`,
            mentions: [nomor]
          }, { quoted: m });
        }
        return;
      }
      
      // @owner--setlevel
      case 'setlevel': {
        setLevel(nomor, jumlah);
        const newRole = getRole(jumlah);
        await reply(
          `✅ *Berhasil set level!*\n\n` +
          `👤 @${nomor.split('@')[0]}\n` +
          `📊 Level : *${oldLevel}* → *${jumlah}*\n` +
          `🎖️ Rank  : *${newRole}*`,
          { mentions: [nomor] }
        );
        if (newRole !== oldRole) {
          await Shoyu.sendMessage(m.chat, {
            text: `🎊 *RANK UP!* @${nomor.split('@')[0]}\n\n${oldRole} → *${newRole}*`,
            mentions: [nomor]
          }, { quoted: m });
        }
        return;
      }
      // @owner--dellevel
      case 'dellevel': {
        const newLevel = Math.max(1, oldLevel - jumlah);
        setLevel(nomor, newLevel);
        return reply(
          `✅ *Berhasil kurangi level!*\n\n` +
          `👤 @${nomor.split('@')[0]}\n` +
          `📊 Level : *${oldLevel}* → *${newLevel}*\n` +
          `🎖️ Rank  : *${getRole(newLevel)}*`,
          { mentions: [nomor] }
        );
      }
    }
  }
};