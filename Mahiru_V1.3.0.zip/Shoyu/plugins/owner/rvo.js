export default {
  command: ['rvo', 'readviewonce', 'baca'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  
  async run(m, { Shoyu, reply }) {
    if (!m.quoted) {
      return reply('Reply pesan *foto/video/audio* mode sekali lihat (view once) yang mau dibuka.');
    }

    const mtype = m.quoted.mtype;
    const supported = ['imageMessage', 'videoMessage', 'audioMessage'];

    if (!supported.includes(mtype)) {
      return reply('Pesan yang di-reply bukan media (foto/video/audio) sekali lihat.');
    }

    try {
      const buffer = await m.quoted.download();

      if (!buffer || buffer.length === 0) {
        return reply('Gagal ambil media-nya. Kemungkinan udah kelewat/expired.');
      }

      const caption = m.quoted.text || '';

      if (mtype === 'imageMessage') {
        await Shoyu.sendMessage(m.chat, { image: buffer, caption }, { quoted: m });
      } else if (mtype === 'videoMessage') {
        await Shoyu.sendMessage(m.chat, { video: buffer, caption }, { quoted: m });
      } else if (mtype === 'audioMessage') {
        await Shoyu.sendMessage(
          m.chat,
          { audio: buffer, mimetype: 'audio/mpeg', ptt: m.quoted.ptt || false },
          { quoted: m }
        );
      }
    } catch (err) {
      console.error('[RVO] Error:', err);
      return reply('Gagal buka pesan view once-nya. Kemungkinan udah expired/dihapus/gak valid.');
    }
  }
};
