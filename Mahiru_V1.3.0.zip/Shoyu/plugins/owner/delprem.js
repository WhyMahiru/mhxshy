import { delPremium, isPremiumUser } from '../../src/lib/database.js';

export default {
  command: ['delprem', 'delpremium'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, args, reply, example }) {
    if (m.isBaileys) return m.reply('ngapain 😂?');

    let nomor;
    if (m.quoted) {
      nomor = m.quoted.sender.replace(/[^0-9]/g, '');
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      nomor = Shoyu.getJid(m.mentionedJid[0]).replace(/[^0-9]/g, '');
    } else if (args[0]) {
      nomor = args[0].replace(/[^0-9]/g, '');
    } else {
      nomor = null;
    }

    if (!nomor) return reply(example(`reply/tag/nomor`));

    nomor += '@s.whatsapp.net';

    if (!isPremiumUser(nomor)) {
      return reply('Nomor tidak ditemukan di daftar premium');
    }

    delPremium(nomor);
    reply(`Berhasil menghapus ${nomor} dari daftar premium`);
  }
};