export default {
  command: ["autoread"],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { reply, args, command, usedPrefix, updateData }) {
    let status = (args[0] || "").toLowerCase();

    if (!["on", "off"].includes(status)) {
      return reply(
        `📖 *𝗔𝘂𝘁𝗼 𝗥𝗲𝗮𝗱*\n\n` +
        `> Status: *${global.autoread ? "Aktif ✅" : "Nonaktif ❌"}*\n\n` +
        `Contoh: ${usedPrefix + command} on/off`
      );
    }

    const isEnable = status === "on";
    const dbValue = isEnable ? 1 : 0;

    try {
      global.autoread = isEnable;
      await updateData('settings', 'bot', 'autoread', dbValue);

      m.reply(`Auto Read berhasil di${isEnable ? 'aktifkan ✅' : 'matikan ❌'}`);
    } catch (e) {
      console.error(e);
      reply('Gagal menyimpan ke database.');
    }
  }
};
