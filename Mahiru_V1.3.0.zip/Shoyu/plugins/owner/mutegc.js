export default {
  command: ['mutegc', 'unmute', 'mute'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply, usedPrefix, args, getGroup, updateData }) {
    try {
      const targetId = args[0] || null;

      if (targetId) {
        const chatDb = await getGroup(targetId);
        const isMuted = chatDb?.mute === 1;

        let nama = targetId;
        try {
          const meta = await Shoyu.groupMetadata(targetId);
          nama = meta.subject;
        } catch {}

        if (isMuted) {
          await updateData('groups', targetId, 'mute', 0);
          return reply(`🔊 *${nama}*\nBerhasil di *unmute*.`);
        } else {
          await updateData('groups', targetId, 'mute', 1);
          return reply(`🔇 *${nama}*\nBerhasil di *mute*.`);
        }
      }

      const groups = await Shoyu.groupFetchAllParticipating();
      const groupList = Object.values(groups);

      if (!groupList.length) {
        return reply('Bot belum join grup manapun.');
      }

      let mutedCount = 0;

      const rows = await Promise.all(
        groupList.map(async (g) => {
          const chatDb = await getGroup(g.id);
          const isMuted = chatDb?.mute === 1;
          if (isMuted) mutedCount++;

          return {
            title: `${isMuted ? '🔇' : '🔊'} ${g.subject || 'Unknown'}`,
            description: isMuted
              ? 'Sedang di-mute • tap untuk unmute'
              : 'Aktif • tap untuk mute',
            id: `${usedPrefix}mutegc ${g.id}`,
          };
        })
      );

      return Shoyu.sendButtons(
        m.chat,
        {
          title: '𝗠𝗨𝗧𝗘 𝗚𝗥𝗨𝗣 𝗠𝗔𝗡𝗔𝗚𝗘𝗥',
          text:
            `Kelola notifikasi grup bot dalam satu tempat.\n\n` +
            `Total grup : *${groupList.length}*\n` +
            `Sedang mute : *${mutedCount}*\n\n` +
            `Tap salah satu grup di bawah buat toggle mute/unmute-nya.`,
          footer: global.namaBot,
          buttons: [
            {
              title: '𝗗𝗮𝗳𝘁𝗮𝗿 𝗚𝗿𝘂𝗽',
              rows,
            },
          ],
        },
        { quoted: m }
      );
    } catch (e) {
      console.error('[mutegc]', e);
      return reply(
        'Terjadi kesalahan di command mutegc.\n\n' +
        String(e?.message || e)
      );
    }
  },
};
