import fs from 'fs';
import path from 'path';

export default {
  command: ['getfile', 'gf'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, text, command, reply, usedPrefix }) {

  	const ownerJids = (global.owner || []).map((v) => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');

  	if (!ownerJids.length) return reply('Nomor owner belum diatur di *global.owner* (settings/setting.js).');

  	if (!text)
  		return reply(`*Cara penggunan:* 
  - ${usedPrefix + command} index.js
  - ${usedPrefix + command} src/lib/namafile.js`);

  	let filePath = text.trim();

  	if (!fs.existsSync(filePath)) {
  		return reply(`File tidak ditemukan: *${filePath}*`);
  	}

  	if (!fs.statSync(filePath).isFile()) {
  		return reply(`Path tersebut folder tidak bisa\n*${usedPrefix}listfile* untuk melihat detail`);
  	}

  	try {
  		let buffer = fs.readFileSync(filePath);
  		let fileName = path.basename(filePath);

  		for (const jid of ownerJids) {
  			await Shoyu.sendMessage(jid, {
  				document: buffer,
  				fileName,
  				mimetype: 'application/octet-stream',
  				caption: `*Success get file*\n- Target: *${filePath}*\n- Requested by: *${m.pushName || m.sender}*`,
  			});
  		}

  		await reply(`📬 *File berhasil diambil!*\nFile telah dikirim ke *nomor owner* (${ownerJids.length} nomor).`);
  	} catch (err) {
  		console.log(err);
  		return reply('❌ Gagal mengirim file.');
  	}

  }
};