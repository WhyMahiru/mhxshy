import { spawn } from 'child_process';
import { flushAllDB } from '../../src/lib/database.js';

export default {
  command: ['rst', 'restart'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, reply }) {

  	const restartServer = () => {
  		// Flush semua DB ke disk dulu sebelum mati
  		flushAllDB();

  		const newProcess = spawn(process.argv[0], process.argv.slice(1), {
  			detached: true,
  			stdio: 'inherit',
  		});
  		process.exit(0);
  	};

  	await reply(`\`\`\`Restarting bot . . .\`\`\``);
  	setTimeout(() => restartServer(), 4500);

  }
};
