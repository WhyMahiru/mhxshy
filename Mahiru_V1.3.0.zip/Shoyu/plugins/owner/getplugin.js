import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


function findPluginFile(baseDir, target) {
  const normalizedTarget = target.replace(/\\/g, '/');

  const direct = path.join(baseDir, normalizedTarget);
  if (fs.existsSync(direct) && fs.statSync(direct).isFile()) return direct;

  const targetName = path.basename(normalizedTarget);
  const matches = [];

  const categories = fs.readdirSync(baseDir).filter((f) =>
    fs.statSync(path.join(baseDir, f)).isDirectory()
  );

  for (const category of categories) {
    const catPath = path.join(baseDir, category);
    const files = fs.readdirSync(catPath).filter((f) => f.endsWith('.js'));

    for (const file of files) {
      if (file === targetName || file === `${category}--${targetName}` || file.endsWith(`--${targetName}`)) {
        matches.push(path.join(catPath, file));
      }
    }
  }

  return matches;
}

export default {
  command: ['getp', 'gp', 'getplugin', 'getplugins'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: true,
  
  async run(m, { Shoyu, text, command, reply, usedPrefix }) {

  	try {
  		const baseDir = path.join(__dirname, '../../plugins');

  		if (!text || !text.endsWith('.js')) return reply(`ᴄᴏɴᴛᴏʜ: *${usedPrefix + command}* ɴᴀᴍᴀғɪʟᴇ.ᴊs\nᴀᴛᴀᴜ: *${usedPrefix + command}* ᴄᴀᴛᴇɢᴏʀʏ--ɴᴀᴍᴀғɪʟᴇ.ᴊs\n\nᴋᴇᴛɪᴋ: *${usedPrefix}listplugin* ᴜɴᴛᴜᴋ ʟɪʜᴀᴛ ғɪʟᴇ ᴘʟᴜɢɪɴs`);

  		const result = findPluginFile(baseDir, text.trim());

  		let targetPath;

  		if (typeof result === 'string') {
  			targetPath = result;
  		} else if (Array.isArray(result) && result.length === 1) {
  			targetPath = result[0];
  		} else if (Array.isArray(result) && result.length > 1) {
  			const list = result.map((p) => `> ${path.relative(baseDir, p)}`).join('\n');
  			return reply(`ᴅɪᴛᴇᴍᴜᴋᴀɴ ʟᴇʙɪʜ ᴅᴀʀɪ sᴀᴛᴜ ᴘʟᴜɢɪɴ ᴅᴇɴɢᴀɴ ɴᴀᴍᴀ *${text.trim()}*:\n\n${list}\n\nsᴇʀᴛᴀᴋᴀɴ ɴᴀᴍᴀ ғᴏʟᴅᴇʀɴʏᴀ, ᴄᴏɴᴛᴏʜ: *${usedPrefix + command}* ${path.relative(baseDir, result[0])}`);
  		}

  		if (!targetPath) return reply(`ᴘʟᴜɢɪɴ *${text.trim()}* ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ ᴅɪ ғᴏʟᴅᴇʀ ᴘʟᴜɢɪɴs.\n\n ᴋᴇᴛɪᴋ: *${usedPrefix}listplugin* ᴜɴᴛᴜᴋ ʟɪʜᴀᴛ ғɪʟᴇ ᴘʟᴜɢɪɴs`);

  		const fileContent = fs.readFileSync(targetPath, 'utf8');
  		const relPath = path.relative(baseDir, targetPath);
  		const fileName = path.basename(targetPath);
  		const category = path.dirname(relPath) === '.' ? '-' : path.dirname(relPath);

  		return await Shoyu.createAIRich({ footer: `GET | ${relPath}` })
  			.addText(`📝 *ᴘʟᴜɢɪɴ:* ${fileName}\n🗄️ *ᴄᴀᴛᴇɢᴏʀʏ:* ${category}`)
  			.addCode('javascript', fileContent)
  			.send(m.chat, { quoted: m });
  	} catch (err) {
  		console.error(err);
  		return reply('Terjadi kesalahan saat membaca plugin.');
  	}

  }
};