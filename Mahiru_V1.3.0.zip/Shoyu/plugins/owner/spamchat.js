export default {
	command: ['spamchat', 'spam'],
	group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: true,
	botAdmin: false,
	privates: false,
	noJadiBot: false,

	async run(m, { Shoyu, args, reply, command, usedPrefix }) {
		if (args.length < 2) {
			return reply(
				`❌ 𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!\n\n` +
				`ᴄᴏɴᴛᴏʜ: *${usedPrefix + command}* ʜᴀʟᴏ 20`
			);
		}

		const lastArg = args[args.length - 1];
		const jumlah = parseInt(lastArg);

		if (isNaN(jumlah)) {
			return reply(`❌ ᴊᴜᴍʟᴀʜ ᴘᴇsᴀɴ ʜᴀʀᴜs ᴀɴɢᴋᴀ ᴅɪ ᴘᴀʟɪɴɢ ᴀᴋʜɪʀ.\nᴄᴏɴᴛᴏʜ: *${usedPrefix + command}* ʜᴀʟᴏ 20`);
		}

		const teks = args.slice(0, -1).join(' ');
		if (!teks) return reply(`❌ ᴛᴇᴋs ɢᴀᴋ ʙᴏʟᴇʜ ᴋᴏsᴏɴɢ.\nᴄᴏɴᴛᴏʜ: *.${usedPrefix + command}* ʜᴀʟᴏ 20`);

		if (jumlah <= 0) return reply('❌ ᴊᴜᴍʟᴀʜ ʜᴀʀᴜs ʟᴇʙɪʜ ᴅᴀʀɪ 0.');

		const start = Date.now();
		await reply(`ᴍᴇᴍᴜʟᴀɪ sᴘᴀᴍ: *${jumlah}*\n ᴛᴇᴋs: "*${teks}*"`);

		for (let i = 1; i <= jumlah; i++) {
			await Shoyu.sendMessage(m.chat, { text: teks });
		}

		const totalMs = Date.now() - start;
		const avgMs = (totalMs / jumlah).toFixed(2);

		await Shoyu.sendMessage(m.chat, {
			text:
				`✅ *𝗦𝗣𝗔𝗠 𝗦𝗘𝗟𝗦𝗔𝗜*\n\n` +
				`📊 ᴛᴏᴛᴀʟ ᴘᴇsᴀɴ : ${jumlah}\n` +
				`📝 ᴛᴇᴋs : ${teks}\n`
		});
	}
};