import { kecocokanNamaPasangan } from '../../src/scrape/primbon.js';

export default {
  command: ['kecocokanpasangan', 'kecocokannama'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const [nama1, nama2] = (text || '').split('&').map((s) => s?.trim());

    if (!nama1 || !nama2) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ 𝟸 ɴᴀᴍᴀ ᴅɪᴘɪsᴀʜ ᴛᴀɴᴅᴀ &.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} kelvin & siapa yah`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await kecocokanNamaPasangan(nama1, nama2);
      const { nama_anda, nama_pasangan, sisi_positif, sisi_negatif, skor, analisis } = result.data;

      const totalHati = 5;
      const isiHati = skor ? Math.max(0, Math.min(totalHati, skor)) : 0;
      const barHati = skor ? '❤️'.repeat(isiHati) + '🖤'.repeat(totalHati - isiHati) : '';

      const teks =
        `💑 *𝗞𝗲𝗰𝗼𝗰𝗼𝗸𝗮𝗻 𝗡𝗮𝗺𝗮 𝗣𝗮𝘀𝗮𝗻𝗴𝗮𝗻*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `👤 *Nama Anda:* ${nama_anda}\n` +
        `💞 *Nama Pasangan:* ${nama_pasangan}\n\n` +
        `✅ *Sisi Positif Anda:* ${sisi_positif}\n` +
        `❌ *Sisi Negatif Anda:* ${sisi_negatif}\n\n` +
        (barHati ? `${barHati}\n\n` : '') +
        `📝 *Analisis*\n${analisis}`;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[kecocokannama] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil data.\n\n' + (err.message || 'Cek kembali kedua nama.'));
    }
  },
};