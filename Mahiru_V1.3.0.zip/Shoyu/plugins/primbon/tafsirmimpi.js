import { tafsirMimpi } from '../../src/scrape/primbon.js';

export default {
  command: ['tafsirmimpi', 'mimpi'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴋᴀᴛᴀ ᴋᴜɴᴄɪ ᴍɪᴍᴘɪ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴛᴀꜰsɪʀᴋᴀɴ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} kucing`
      );
    }

    const keyword = text.trim();

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await tafsirMimpi(keyword);
      const { arti } = result.data;

      const daftarArti = arti.map((a) => `• ${a}`).join('\n\n');

      const teks =
        `🌙 *𝗧𝗮𝗳𝘀𝗶𝗿 𝗠𝗶𝗺𝗽𝗶: ${keyword}*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        daftarArti;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[tafsirmimpi] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil tafsir mimpi.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};