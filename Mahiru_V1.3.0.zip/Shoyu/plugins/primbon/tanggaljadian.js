import { tanggalJadianPernikahan } from '../../src/scrape/primbon.js';

export default {
  command: ['tanggaljadian', 'jadianpernikahan'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const [tgl, bln, thn] = (text || '').trim().split(/[\/\-\s]+/);

    if (!tgl || !bln || !thn || isNaN(tgl) || isNaN(bln) || isNaN(thn)) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴛᴀɴɢɢᴀʟ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴇᴋ ᴋᴀʀᴀᴋᴛᴇʀɪsᴛɪᴋɴʏᴀ (ᴜɴᴛᴜᴋ ᴛᴀɴɢɢᴀʟ ᴘᴇʀɴɪᴋᴀʜᴀɴ).\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 17-08-2026`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await tanggalJadianPernikahan(tgl, bln, thn);
      const { tanggal, karakteristik, catatan } = result.data;

      if (!tanggal && !karakteristik) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('Data tidak ditemukan, cek kembali tanggal/bulan/tahunnya.');
      }

      const teks =
        `💍 *𝗧𝗮𝗻𝗴𝗴𝗮𝗹 𝗝𝗮𝗱𝗶𝗮𝗻 𝗣𝗲𝗿𝗻𝗶𝗸𝗮𝗵𝗮𝗻*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `📅 *Tanggal*\n${tanggal}\n\n` +
        `📝 *Karakteristik*\n${karakteristik}\n\n` +
        `━━━━━━━━━━━━━━━━━━\n💡 ${catatan}`;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[tanggaljadian] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil data.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};
