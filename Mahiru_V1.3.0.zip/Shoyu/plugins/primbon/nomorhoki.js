import { nomorHokiBaguaShuzi } from '../../src/scrape/primbon.js';

export default {
  command: ['nomorhoki', 'cekhp', 'hokihp'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim() || isNaN(text.trim())) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ɴᴏᴍᴏʀ ʜᴘ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴇᴋ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 081234567890`
      );
    }

    const nomor = text.trim();

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await nomorHokiBaguaShuzi(nomor);
      const { nomer_hp, angka_shuzi, energi_positif, energi_negatif } = result.data;

      const teks =
        `📱 *𝗡𝗼𝗺𝗼𝗿 𝗛𝗼𝗸𝗶*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `No. HP: ${nomer_hp}\n` +
        `Angka Bagua Shuzi: ${angka_shuzi}\n\n` +
        `✅ *Energi Positif* ${energi_positif.persentase ? `(${energi_positif.persentase})` : ''}\n` +
        `Kekayaan: ${energi_positif.kekayaan}\n` +
        `Kesehatan: ${energi_positif.kesehatan}\n` +
        `Cinta/Relasi: ${energi_positif.cinta}\n` +
        `Kestabilan: ${energi_positif.kestabilan}\n\n` +
        `❌ *Energi Negatif* ${energi_negatif.persentase ? `(${energi_negatif.persentase})` : ''}\n` +
        `Perselisihan: ${energi_negatif.perselisihan}\n` +
        `Kehilangan: ${energi_negatif.kehilangan}\n` +
        `Malapetaka: ${energi_negatif.malapetaka}\n` +
        `Kehancuran: ${energi_negatif.kehancuran}`;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[nomorhoki] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengecek nomor hoki.\n\n' + (err.message || 'Cek kembali nomornya.'));
    }
  },
};
