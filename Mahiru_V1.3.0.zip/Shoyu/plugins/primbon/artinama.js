import { artinama } from '../../src/scrape/primbon.js';

export default {
  command: ['artinama', 'arti'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ɴᴀᴍᴀ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ ᴀʀᴛɪɴʏᴀ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} Farhan`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await artinama(text.trim());

      if (!result?.trim()) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Arti nama tidak ditemukan.');
      }

      await reply(`🔎 *Arti Nama: ${text.trim()}*\n\n${result.trim()}`);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[ARTINAMA] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil arti nama.\n\n' + err.message);
    }
  },
};