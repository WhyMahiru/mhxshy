import { sifatKarakterTanggalLahir } from '../../src/scrape/primbon.js';

export default {
  command: ['sifatkarakter'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const [nama, tgl] = (text || '').split('|').map((s) => s?.trim());
    const [tanggal, bulan, tahun] = (tgl || '').split(/[\/\-\s]+/);

    if (!nama || !tanggal || !bulan || !tahun) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ɴᴀᴍᴀ ᴅᴀɴ ᴛᴀɴɢɢᴀʟ ʟᴀʜɪʀ, ᴅɪᴘɪsᴀʜ |.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} Yanto | 17-08-1998`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await sifatKarakterTanggalLahir(nama, tanggal, bulan, tahun);
      const { nama: namaHasil, tanggal_lengkap, angka_garis_hidup, karakter } = result.data;

      const teks =
        `*𝗦𝗶𝗳𝗮𝘁 𝗞𝗮𝗿𝗮𝗸𝘁𝗲𝗿 𝗠𝗲𝗻𝘂𝗿𝘂𝘁 𝗧𝗮𝗻𝗴𝗴𝗮𝗹 𝗟𝗮𝗵𝗶𝗿*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `👤 *Nama*\n${namaHasil}\n\n` +
        `📅 *Tanggal Lahir*\n${tanggal_lengkap}\n\n` +
        `🔢 *Garis Hidup ${angka_garis_hidup}*\n\n` +
        `📝 *Karakter*\n${karakter}`;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[sifatkarakter] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil data.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};