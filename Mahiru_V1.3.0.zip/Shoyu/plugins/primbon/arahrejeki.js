import { primbonArahRejeki } from '../../src/scrape/primbon.js';

export default {
  command: ['arahrejeki'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const [tgl, bln, thn] = (text || '').trim().split(/[\/\-\s]+/);

    if (!tgl || !bln || !thn || isNaN(tgl) || isNaN(bln) || isNaN(thn)) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴛᴀɴɢɢᴀʟ-ʙᴜʟᴀɴ-ᴛᴀʜᴜɴ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴇᴋ ᴀʀᴀʜ ʀᴇᴊᴇᴋɪɴʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 17-08-2026`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await primbonArahRejeki(tgl, bln, thn);
      const { tanggal_lengkap, arah_rejeki } = result.data;

      const teks =
        `🧭 *𝗔𝗿𝗮𝗵 𝗥𝗲𝗷𝗲𝗸𝗶*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `📅 *Tanggal*\n${tanggal_lengkap}\n\n` +
        `🧭 *Arah Rejeki*\n${arah_rejeki}`;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[arahrejeki] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil data.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};