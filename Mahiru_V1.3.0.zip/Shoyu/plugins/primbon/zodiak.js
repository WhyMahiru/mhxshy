import { zodiak } from '../../src/scrape/primbon.js';

export default {
  command: ['zodiak'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ɴᴀᴍᴀ ᴢᴏᴅɪᴀᴋ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴇᴋ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} gemini`
      );
    }

    const nama = text.trim();

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await zodiak(nama);
      const {
        nomor_keberuntungan,
        aroma_keberuntungan,
        planet_yang_mengitari,
        bunga_keberuntungan,
        warna_keberuntungan,
        batu_keberuntungan,
        elemen_keberuntungan,
        pasangan_serasi,
        deskripsi,
      } = result.data;

      const namaCapital = nama[0].toUpperCase() + nama.slice(1);

      const teks =
        `🔮 *𝗭𝗼𝗱𝗶𝗮𝗸: ${namaCapital}*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `🔢 *Nomor Keberuntungan*\n${nomor_keberuntungan}\n\n` +
        `🌸 *Aroma Keberuntungan*\n${aroma_keberuntungan}\n\n` +
        `🪐 *Planet Yang Mengitari*\n${planet_yang_mengitari}\n\n` +
        `💐 *Bunga Keberuntungan*\n${bunga_keberuntungan}\n\n` +
        `🎨 *Warna Keberuntungan*\n${warna_keberuntungan}\n\n` +
        `💎 *Batu Keberuntungan*\n${batu_keberuntungan}\n\n` +
        `🌬️ *Elemen Keberuntungan*\n${elemen_keberuntungan}\n\n` +
        `💞 *Pasangan Serasi*\n${pasangan_serasi}\n` +
        (deskripsi
          ? `\n━━━━━━━━━━━━━━━━━━\n📝 *Tentang ${namaCapital}*\n${deskripsi}`
          : '');

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[zodiak] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(
        (err.message || 'Gagal mengambil data zodiak.') +
        `\n\nᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} gemini`
      );
    }
  },
};