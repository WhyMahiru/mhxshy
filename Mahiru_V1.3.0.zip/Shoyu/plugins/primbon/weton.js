import { wetonJawa } from '../../src/scrape/primbon.js';

export default {
  command: ['weton'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const [tgl, bln, thn] = (text || '').trim().split(/[\/\-\s]+/);

    if (!tgl || !bln || !thn || isNaN(tgl) || isNaN(bln) || isNaN(thn)) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴛᴀɴɢɢᴀʟ ʟᴀʜɪʀ ʏᴀ (ᴛɢʟ ʙʟɴ ᴛʜɴ).\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 17-08-1998`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await wetonJawa(tgl, bln, thn);
      const { tanggal, jumlah_neptu, watak_hari, naga_hari, jam_baik, watak_kelahiran } = result.data;

      if (!tanggal && !watak_hari) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('Data weton tidak ditemukan, cek kembali tanggal/bulan/tahunnya.');
      }

      const teks =
        `📿 *𝗪𝗲𝘁𝗼𝗻 𝗝𝗮𝘄𝗮*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `📅 *Tanggal*\n${tanggal}\n\n` +
        `🔢 *Jumlah Neptu*\n${jumlah_neptu}\n\n` +
        `🎭 *Watak Hari (Kamarokam)*\n${watak_hari}\n\n` +
        `🐉 *Naga Hari*\n${naga_hari}\n\n` +
        `⏰ *Jam Baik*\n${jam_baik}\n\n` +
        `👤 *Watak Kelahiran*\n${watak_kelahiran}`;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[weton] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil data weton.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};
