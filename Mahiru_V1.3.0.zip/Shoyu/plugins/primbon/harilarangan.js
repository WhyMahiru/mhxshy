import { hariSangarTaliwangke } from '../../src/scrape/primbon.js';

export default {
  command: ['harilarangan', 'harinaas'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const [tgl, bln, thn] = (text || '').trim().split(/[\/\-\s]+/);

    if (!tgl || !bln || !thn || isNaN(tgl) || isNaN(bln) || isNaN(thn)) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴛᴀɴɢɢᴀʟ-ʙᴜʟᴀɴ-ᴛᴀʜᴜɴ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴇᴋ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 02-01-2030`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await hariSangarTaliwangke(tgl, bln, thn);
      const { tanggal_lengkap, is_sangar, status, keterangan } = result.data;

      const teks =
        `${is_sangar ? '⚠️' : '✅'} *𝗛𝗮𝗿𝗶 𝗟𝗮𝗿𝗮𝗻𝗴𝗮𝗻*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `📅 *Tanggal*\n${tanggal_lengkap}\n\n` +
        `${is_sangar ? '⚠️' : '📝'} *Status*\n${status}` +
        (keterangan ? `\n\n${keterangan}` : '');

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[harilarangan] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil data.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};