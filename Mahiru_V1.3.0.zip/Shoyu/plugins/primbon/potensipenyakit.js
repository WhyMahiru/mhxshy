import { cekPotensiPenyakit } from '../../src/scrape/primbon.js';

export default {
  command: ['cekpenyakit', 'potensipenyakit'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const [tgl, bln, thn] = (text || '').trim().split(/[\/\-\s]+/);

    if (!tgl || !bln || !thn || isNaN(tgl) || isNaN(bln) || isNaN(thn)) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴛᴀɴɢɢᴀʟ ʟᴀʜɪʀ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴇᴋ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 17-08-1996`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await cekPotensiPenyakit(tgl, bln, thn);
      const { tanggal_lengkap, analisis } = result.data;

      const teks =
        `🩺 *𝗖𝗲𝗸 𝗣𝗼𝘁𝗲𝗻𝘀𝗶 𝗣𝗲𝗻𝘆𝗮𝗸𝗶𝘁*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `📅 *Tanggal Lahir*\n${tanggal_lengkap}\n\n` +
        `📝 *Analisis*\n${analisis}\n\n` +
        `━━━━━━━━━━━━━━━━━━\n💡 Potensi penyakit harus dipandang secara positif. Ini bukan kepastian, tapi antisipasi dini.`;

      await reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[cekpenyakit] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil data.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};