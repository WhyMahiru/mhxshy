import { petungHariBaik } from '../../src/scrape/primbon.js';

export default {
  command: ['haribaik'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      return reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴛᴀɴɢɢᴀʟ-ʙᴜʟᴀɴ-ᴛᴀʜᴜɴ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴇᴋ ᴡᴀᴛᴀᴋɴʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 02-09-2026`
      );
    }

    const parts = text.trim().split(/[\/\-\s]+/);
    const [tgl, bln, thn] = parts;

    if (!tgl || !bln || !thn || isNaN(tgl) || isNaN(bln) || isNaN(thn)) {
      return reply(
        `Format salah, gunakan: tanggal-bulan-tahun\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 17-08-1945`
      );
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const result = await petungHariBaik(tgl, bln, thn);
      const { hari_pasaran, tanggal, nuju_pati, kala_tinantang } = result.data;

      if (!hari_pasaran && !nuju_pati) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('Watak hari tidak ditemukan, cek kembali tanggal/bulan/tahunnya.');
      }

      let teks =
        `🗓️ *𝗛𝗮𝗿𝗶 𝗕𝗮𝗶𝗸*\n` +
        `━━━━━━━━━━━━━━━━━━\n\n`;

      if (hari_pasaran) teks += `📅 *Hari Pasaran*\n${hari_pasaran}\n\n`;
      if (tanggal) teks += `📆 *Tanggal*\n${tanggal}\n\n`;
      if (nuju_pati) teks += `⚠️ *Nuju Pati*\n${nuju_pati}\n\n`;
      if (kala_tinantang) teks += `⏳ *Kala Tinantang*\n${kala_tinantang}\n\n`;

      await reply(teks.trim());
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[haribaik] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil watak hari.\n\n' + (err.message || 'Cek kembali input kamu.'));
    }
  },
};