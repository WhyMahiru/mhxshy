function convertEsmToCjs(src) {
  let out = src;

  out = out.replace(
    /import\s+([A-Za-z0-9_$]+)\s*,\s*\{([^}]+)\}\s+from\s+['"]([^'"]+)['"];?/g,
    (_, def, named, mod) => {
      const names = named
        .split(',')
        .map((n) => n.trim())
        .filter(Boolean)
        .join(', ');
      return `const ${def} = require('${mod}');\nconst { ${names} } = require('${mod}');`;
    }
  );

  out = out.replace(
    /import\s+\*\s+as\s+([A-Za-z0-9_$]+)\s+from\s+['"]([^'"]+)['"];?/g,
    (_, ns, mod) => `const ${ns} = require('${mod}');`
  );

  out = out.replace(
    /import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"];?/g,
    (_, named, mod) => {
      const names = named
        .split(',')
        .map((n) => n.trim().replace(/\s+as\s+/, ': '))
        .filter(Boolean)
        .join(', ');
      return `const { ${names} } = require('${mod}');`;
    }
  );

  out = out.replace(
    /import\s+([A-Za-z0-9_$]+)\s+from\s+['"]([^'"]+)['"];?/g,
    (_, def, mod) => `const ${def} = require('${mod}');`
  );

  out = out.replace(
    /import\s+['"]([^'"]+)['"];?/g,
    (_, mod) => `require('${mod}');`
  );

  out = out.replace(
    /export\s+default\s+/g,
    'module.exports = '
  );

  out = out.replace(
    /export\s+(const|let|var)\s+([A-Za-z0-9_$]+)/g,
    (_, kind, name) => `${kind} ${name}`
  );

  out = out.replace(
    /export\s+function\s+([A-Za-z0-9_$]+)/g,
    (_, name) => `function ${name}`
  );

  out = out.replace(
    /export\s+class\s+([A-Za-z0-9_$]+)/g,
    (_, name) => `class ${name}`
  );

  out = out.replace(
    /export\s+\{([^}]+)\};?/g,
    (_, named) => {
      const lines = named
        .split(',')
        .map((n) => n.trim())
        .filter(Boolean)
        .map((n) => {
          const asMatch = n.match(/^(\S+)\s+as\s+(\S+)$/);
          if (asMatch) return `exports.${asMatch[2]} = ${asMatch[1]};`;
          return `exports.${n} = ${n};`;
        })
        .join('\n');
      return lines;
    }
  );

  return out.trim();
}

export default {
  command: ['esmtocjs', 'tocjs'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const quoted =
      m.quoted && m.quoted.mtype === 'documentMessage' ? m.quoted : null;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';
    const fileName = quoted?.msg?.fileName || quoted?.fileName || '';
    const isJsFile = /javascript|\.js$/i.test(mime) || /\.(js|mjs|cjs)$/i.test(fileName);

    let source = '';

    if (quoted && isJsFile) {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });
      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil file-nya, coba reply ulang.');
        return false;
      }
      source = buffer.toString('utf-8');
    } else if (text && text.trim()) {
      source = text.trim();
    } else if (m.quoted && m.quoted.text) {
      source = m.quoted.text.trim();
    }

    if (!source) {
      reply(
        `ᴋɪʀɪᴍ/ʀᴇᴘʟʏ ᴋᴏᴅᴇ ᴇsᴍ (.ᴊs) ʟᴀʟᴜ ᴋᴇᴛɪᴋ ${usedPrefix + command}\n\n` +
        `Contoh:\n${usedPrefix + command} import fs from 'fs';`
      );
      return false;
    }

    try {
      const converted = convertEsmToCjs(source);

      if (quoted && isJsFile) {
        const outName = (fileName || 'converted.js').replace(/\.(js|mjs)$/i, '.cjs.js');
        await Shoyu.sendMessage(
          m.chat,
          {
            document: Buffer.from(converted, 'utf-8'),
            fileName: outName,
            mimetype: 'application/javascript',
          },
          { quoted: m }
        );
      } else {
        reply('```' + converted + '```');
      }

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[esmtocjs]', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal convert kodenya.\n\n' + err.message);
      return false;
    }
  },
};