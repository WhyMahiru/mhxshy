import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { bacaresep, bacaresepMulti } from '../../src/scrape/scraper.js';

export default {
  command: ['bacaresep', 'detailresep'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ʟɪɴᴋ ʀᴇsᴇᴘɴʏᴀ ᴍᴀɴᴀ?\n\n` +
        `ʙɪᴀsᴀɴʏᴀ ᴅɪᴘᴀɴɢɢɪʟ ᴏᴛᴏᴍᴀᴛɪs ᴅᴀʀɪ ʜᴀsɪʟ ${usedPrefix}cariresep, ᴛᴀᴘɪ ʙɪsᴀ ᴊᴜɢᴀ ᴍᴀɴᴜᴀʟ:\n` +
        `${usedPrefix + command} <link resepkoki.id>`
      );
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    const raw = text.trim();
    const hashIndex = raw.lastIndexOf('#');
    const hasIndex = hashIndex !== -1 && /^\d+$/.test(raw.slice(hashIndex + 1));
    const link = hasIndex ? raw.slice(0, hashIndex) : raw;
    const pickIndex = hasIndex ? parseInt(raw.slice(hashIndex + 1), 10) : null;

    let parsedUrl;
    try {
      parsedUrl = new URL(link);
    } catch {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(
        `Link yang diterima gak valid (kemungkinan kepotong).\n\n` +
        `📥 *Diterima persis:*\n\`${raw}\`\n\n` +
        `Kalau ini kependekan dibanding link resep aslinya, kemungkinan besar WhatsApp motong field id-nya karena kepanjangan — kabarin ke pembuat bot biar dicek.`
      );
      return false;
    }

    if (!parsedUrl.hostname.includes('resepkoki.id')) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(
        `Link yang diterima bukan dari resepkoki.id.\n\n` +
        `📥 *Diterima persis:*\n\`${raw}\``
      );
      return false;
    }

    try {
      if (pickIndex !== null) {
        const multi = await bacaresepMulti(link);
        const item = multi.data.find((d) => d.index === pickIndex);

        if (!item) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          reply(`Resep nomor ${pickIndex} gak ketemu di halaman ini.`);
          return false;
        }

        const bahanList = (item.bahan || '')
          .split('\n')
          .filter(Boolean)
          .map((b) => `• ${b.trim()}`)
          .join('\n');

        const teks =
          `╭─✦ 𝗥𝗲𝘀𝗲𝗽: ${item.judul}\n` +
          `│⟡ Dari : ${multi.judul_artikel}\n` +
          `╰──────────✦\n\n` +
          `🧂 *Bahan-Bahan*\n${bahanList || '-'}\n\n` +
          `👨‍🍳 *Langkah-Langkah*\n${item.langkah || '-'}`;

        reply(teks);
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }

      const r = await bacaresep(link).catch(() => null);

      if (r?.judul_nya) {
        const bahanList = (r.bahan_nya || '')
          .split('\n')
          .filter(Boolean)
          .map((b) => `• ${b.trim()}`)
          .join('\n');

        const langkahList = (r.langkah_langkah || '')
          .split('\n\n')
          .filter(Boolean)
          .map((step, i) => `*${i + 1}.* ${step.trim()}`)
          .join('\n\n');

        const teks =
          `╭─✦ 𝗥𝗲𝘀𝗲𝗽: ${r.judul_nya}\n` +
          `│⟡ Waktu : ${r.waktu_nya || '-'}\n` +
          `│⟡ Porsi : ${r.hasil_nya || '-'}\n` +
          `│⟡ Level : ${r.tingkat_kesulitan || '-'}\n` +
          `╰──────────✦\n\n` +
          `🧂 *Bahan-Bahan*\n${bahanList || '-'}\n\n` +
          `👨‍🍳 *Langkah-Langkah*\n${langkahList || '-'}`;

        if (r.thumb_nya) {
          await Shoyu.sendMessage(m.chat, { image: { url: r.thumb_nya }, caption: teks }, { quoted: m });
        } else {
          reply(teks);
        }

        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }

      const multi = await bacaresepMulti(link).catch(() => null);

      if (!multi?.data?.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(
          `Resep tidak ditemukan di halaman ini.\n\n` +
          `📥 *Link yang dicoba:*\n\`${link}\``
        );
        return false;
      }

      const rows = multi.data.slice(0, 10).map((item) => ({
        title: item.judul.length > 24 ? item.judul.slice(0, 21) + '...' : item.judul,
        description: 'Ketuk untuk lihat bahan & langkah',
        id: `${usedPrefix}bacaresep ${link}#${item.index}`,
      }));

      const body =
        `📖 *${multi.judul_artikel}*\n\n` +
        `Halaman ini berisi *${rows.length}* resep sekaligus.\n` +
        `Pilih salah satu di bawah ini untuk melihat bahan dan langkahnya`;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: 'Pilih Resep',
                  subtitle: `by ${global.namaBot}`,
                  hasMediaAttachment: false,
                },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'single_select',
                      buttonParamsJson: JSON.stringify({
                        title: 'Pilih Resep',
                        sections: [{ title: 'Isi Halaman Ini', rows }],
                        icon: 'DEFAULT',
                      }),
                    },
                  ],
                  messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                      in_thread_buttons_limit: 1,
                      list_title: 'Pilih Resep',
                      button_title: ' ✦ Lihat Isi ✦ ',
                    },
                  }),
                },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[BACARESEP] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal ambil detail resepnya.\n\n' + err.message);
      return false;
    }
  },
};