import {
  getVideoDetail,
  getTrendingVideos,
  getLatestVideos,
} from '../../src/scrape/seegore.js';

export default {
  command: ['gore', 'gorepl', 'gorerandom'],
  group: false,
  limit: false,
  premium: true,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const cmd = command;

    if (cmd === 'gore') {
      let msg = `*🔞 𝗦𝗘𝗘𝗚𝗢𝗥𝗘 𝗠𝗘𝗡𝗨*\n\n`;
      msg += `*ᴘᴇʀɪɴᴛᴀʜ ᴛᴇʀsᴇᴅɪᴀ:*\n`;
      msg += `▸${usedPrefix}gorepl *ʟɪʜᴀᴛ ᴘᴏᴘᴜʟᴀʀ & ʟᴀᴛᴇsᴛ*\n`;
      msg += `▸${usedPrefix}gorerandom *ᴠɪᴅᴇᴏ ᴀᴄᴀᴋ*\n`;
      msg += `▸${usedPrefix}searchgore <ǫᴜᴇʀʏ> *ᴄᴀʀɪ ᴠɪᴅᴇᴏ*\n`;
      msg += `▸${usedPrefix}goredownload <ʟɪɴᴋ> *ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ*\n`;
      return reply(msg);
    }

    if (cmd === 'gorepl') {
      await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

      const trending = await getTrendingVideos();
      const latest = await getLatestVideos(1);

      if (!trending.length && !latest.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴅᴀᴛᴀ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ sᴀᴀᴛ ɪɴɪ.');
      }

      let msg = `*🔞 SeeGore — Popular & Latest*\n\n`;

      if (trending.length) {
        msg += `*📈 𝗧𝗥𝗘𝗡𝗗𝗜𝗡𝗚:*\n`;
        trending.forEach((v, i) => {
          msg += `${i + 1}. ${v.title}\n`;
          msg += `   👁 ${v.views || 0}  •  👍 ${v.upvotes || 0}\n`;
          msg += `   🔗 ${v.url}\n\n`;
        });
      }

      if (latest.length) {
        msg += `*🆕 𝗟𝗔𝗧𝗘𝗦𝗧:*\n`;
        latest.forEach((v, i) => {
          msg += `${i + 1}. ${v.title}\n`;
          msg += `   👁 ${v.views || 0}  •  👍 ${v.upvotes || 0}\n`;
          msg += `   🔗 ${v.url}\n\n`;
        });
      }

      msg += `_ᴋᴇᴛɪᴋ ${usedPrefix}goredownload <ʟɪɴᴋ> ᴜɴᴛᴜᴋ ᴅᴏᴡɴʟᴏᴀᴅ._`;

      await reply(msg.trim());
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return;
    }

    if (cmd === 'gorerandom') {
      await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

      try {
        const trending = await getTrendingVideos();
        const latest = await getLatestVideos(1);
        const pool = [...trending, ...latest].filter(
          (v, i, a) => a.findIndex((t) => t.url === v.url) === i,
        );

        if (!pool.length) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          return reply('ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴠɪᴅᴇᴏ ᴛᴇʀsᴇᴅɪᴀ.');
        }

        const randomCard = pool[Math.floor(Math.random() * pool.length)];
        const detail = await getVideoDetail(randomCard.url);

        if (!detail || !detail.videos?.length) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          return reply('ɢᴀɢᴀʟ ᴀᴍʙɪʟ ᴅᴇᴛᴀɪʟ ᴠɪᴅᴇᴏ ᴀᴄᴀᴋ.');
        }

        const videoSrc = detail.videos[0]?.src;
        if (!videoSrc) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          return reply('ᴜʀʟ ᴠɪᴅᴇᴏ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ.');
        }

        const caption =
          `*🎲 𝗥𝗔𝗡𝗗𝗢𝗠 𝗩𝗜𝗗𝗘𝗢*\n\n` +
          `*${detail.title || 'No Title'}*\n\n` +
          `📁 Kategori: ${detail.category || '-'}\n` +
          `👁 Views: ${detail.views || '-'}\n` +
          `👍 Upvotes: ${detail.upvotes || '-'}\n` +
          `💬 Komentar: ${detail.comments_count || '0'}\n` +
          `📅 ${detail.date || '-'}`;

        await Shoyu.sendMessage(
          m.chat,
          { video: { url: videoSrc }, caption, mimetype: 'video/mp4' },
          { quoted: m },
        );

        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      } catch (err) {
        console.error('[GORERANDOM] Error:', err.message);

        if (err.code === 'ENOSPC' || err.message?.includes('no space left')) {
          await Shoyu.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
          return reply('⚠️ *Disk server penuh!*\nᴛɪᴅᴀᴋ ʙɪsᴀ ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ.\nʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ᴜɴᴛᴜᴋ ʙᴇʀsɪʜɪɴ sᴇʀᴠᴇʀ.');
        }

        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`Error: ${err.message}`);
      }
      return;
    }
  },
};