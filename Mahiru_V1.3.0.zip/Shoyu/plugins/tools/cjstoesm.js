function convertCjsToEsm(src) {
  let out = src;

  out = out.replace(
    /(?:const|let|var)\s+([A-Za-z0-9_$]+)\s*=\s*require\(\s*['"]([^'"]+)['"]\s*\);?/g,
    (_, name, mod) => `import ${name} from '${mod}';`
  );

  out = out.replace(
    /(?:const|let|var)\s*\{([^}]+)\}\s*=\s*require\(\s*['"]([^'"]+)['"]\s*\);?/g,
    (_, named, mod) => {
      const names = named
        .split(',')
        .map((n) => n.trim().replace(/:\s*/, ' as '))
        .filter(Boolean)
        .join(', ');
      return `import { ${names} } from '${mod}';`;
    }
  );

  out = out.replace(
    /(?<!\S)require\(\s*['"]([^'"]+)['"]\s*\);?/g,
    (_, mod) => `import '${mod}';`
  );

  out = out.replace(
    /module\.exports\.([A-Za-z0-9_$]+)\s*=\s*/g,
    (_, name) => `export const ${name} = `
  );

  out = out.replace(
    /(?<!module\.)exports\.([A-Za-z0-9_$]+)\s*=\s*/g,
    (_, name) => `export const ${name} = `
  );

  out = out.replace(
    /module\.exports\s*=\s*/g,
    'export default '
  );

  return out.trim();
}

export default {
  command: ['cjstoesm', 'toesm'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const quoted =
      m.quoted && m.quoted.mtype === 'documentMessage' ? m.quoted : null;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';
    const fileName = quoted?.msg?.fileName || quoted?.fileName || '';
    const isJsFile = /javascript|\.(js|cjs)$/i.test(mime) || /\.(js|cjs)$/i.test(fileName);

    let source = '';

    if (quoted && isJsFile) {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });
      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil file-nya, coba reply ulang.');
        return false;
      }
      source = buffer.toString('utf-8');
    } else if (text && text.trim()) {
      source = text.trim();
    } else if (m.quoted && m.quoted.text) {
      source = m.quoted.text.trim();
    }

    if (!source) {
      reply(
        `ᴋɪʀɪᴍ/ʀᴇᴘʟʏ ᴋᴏᴅᴇ ᴄᴏᴍᴍᴏɴ.ᴊs (.ᴊs/.ᴄᴊs) ʟᴀʟᴜ ᴋᴇᴛɪᴋ ${usedPrefix + command}\n\n` +
        `Contoh:\n${usedPrefix + command} const fs = require('fs');`
      );
      return false;
    }

    try {
      const converted = convertCjsToEsm(source);

      if (quoted && isJsFile) {
        const outName = (fileName || 'converted').replace(/\.(js|cjs)$/i, '') + '.esm.js';
        await Shoyu.sendMessage(
          m.chat,
          {
            document: Buffer.from(converted, 'utf-8'),
            fileName: outName,
            mimetype: 'application/javascript',
          },
          { quoted: m }
        );
      } else {
        reply('```' + converted + '```');
      }

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[cjstoesm]', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal convert kodenya.\n\n' + err.message);
      return false;
    }
  },
};