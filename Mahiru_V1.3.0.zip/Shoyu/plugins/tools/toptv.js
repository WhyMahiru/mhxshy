import { PassThrough } from 'stream';
import ffmpeg from 'fluent-ffmpeg';

function toRoundVideo(buffer) {
  return new Promise((resolve, reject) => {
    const input = new PassThrough();
    const output = new PassThrough();
    const chunks = [];

    input.end(buffer);

    ffmpeg(input)
      .videoFilters([
        'crop=\'min(iw,ih)\':\'min(iw,ih)\'',
        'scale=480:480',
      ])
      .videoCodec('libx264')
      .outputOptions(['-preset veryfast', '-pix_fmt yuv420p', '-movflags frag_keyframe+empty_moov'])
      .audioCodec('aac')
      .format('mp4')
      .on('error', reject)
      .on('end', () => resolve(Buffer.concat(chunks)))
      .pipe(output);

    output.on('data', (c) => chunks.push(c));
  });
}

export default {
  command: ['toptv', 'ptv', 'videonote'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, usedPrefix, command, reply }) {
    const isVideo = m.mtype === 'videoMessage';
    const quoted = m.quoted;
    const isQuotedVideo = quoted && quoted.mtype === 'videoMessage';

    if (!isVideo && !isQuotedVideo) {
      reply(
        `ᴋɪʀɪᴍ/ʀᴇᴘʟʏ *ᴠɪᴅᴇᴏ* ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴜʙᴀʜ ᴊᴀᴅɪ ᴘᴛᴠ (ᴠɪᴅᴇᴏ ɴᴏᴛᴇ).\n\n` +
        `ᴄᴏɴᴛᴏʜ: ʀᴇᴘʟʏ/ᴋɪʀɪᴍ ᴠɪᴅᴇᴏ ʟᴀʟᴜ ᴋᴇᴛɪᴋ ${usedPrefix + command}`
      );
      return false;
    }

    const target = isQuotedVideo ? quoted : m;

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const buffer = await target.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil videonya, coba reply ulang.');
        return false;
      }

      const round = await toRoundVideo(buffer);

      await Shoyu.sendMessage(
        m.chat,
        {
          video: round,
          ptv: true,
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[tovideobulat]', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal convert ke video bulat.\n\n' + err.message);
      return false;
    }
  },
};