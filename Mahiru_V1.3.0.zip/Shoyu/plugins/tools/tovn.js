import { PassThrough } from 'stream';
import ffmpeg from 'fluent-ffmpeg';

function toVN(buffer) {
  return new Promise((resolve, reject) => {
    const input = new PassThrough();
    const output = new PassThrough();
    const chunks = [];

    input.end(buffer);

    ffmpeg(input)
      .noVideo()
      .audioCodec('libopus')
      .format('ogg')
      .on('error', reject)
      .on('end', () => resolve(Buffer.concat(chunks)))
      .pipe(output);

    output.on('data', (c) => chunks.push(c));
  });
}

export default {
  command: ['tovn', 'toptt', 'tovoicenote'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, usedPrefix, command, reply }) {
    const isMedia = m.mtype === 'audioMessage' || m.mtype === 'videoMessage';
    const quoted = m.quoted;
    const isQuotedMedia =
      quoted && (quoted.mtype === 'audioMessage' || quoted.mtype === 'videoMessage');

    if (!isMedia && !isQuotedMedia) {
      reply(
        `ᴋɪʀɪᴍ ᴀᴛᴀᴜ ʀᴇᴘʟʏ *ᴀᴜᴅɪᴏ/ᴠɪᴅᴇᴏ* ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴜʙᴀʜ ᴊᴀᴅɪ ᴠᴏɪᴄᴇ ɴᴏᴛᴇ.\n\n` +
        `ᴄᴏɴᴛᴏʜ: ʀᴇᴘʟʏ ᴀᴜᴅɪᴏ/ᴠɪᴅᴇᴏ ʟᴀʟᴜ ᴋᴇᴛɪᴋ ${usedPrefix + command}`
      );
      return false;
    }

    const target = isQuotedMedia ? quoted : m;

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const buffer = await target.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil media-nya, coba reply ulang.');
        return false;
      }

      const vn = await toVN(buffer);

      await Shoyu.sendMessage(
        m.chat,
        {
          audio: vn,
          ptt: true,
          mimetype: 'audio/ogg; codecs=opus',
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[tovn]', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal convert ke voice note.\n\n' + err.message);
      return false;
    }
  },
};