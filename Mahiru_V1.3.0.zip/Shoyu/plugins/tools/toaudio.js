import { PassThrough } from 'stream';
import ffmpeg from 'fluent-ffmpeg';

function toAudio(buffer) {
  return new Promise((resolve, reject) => {
    const input = new PassThrough();
    const output = new PassThrough();
    const chunks = [];

    input.end(buffer);

    ffmpeg(input)
      .noVideo()
      .audioCodec('libmp3lame')
      .audioBitrate('128k')
      .format('mp3')
      .on('error', reject)
      .on('end', () => resolve(Buffer.concat(chunks)))
      .pipe(output);

    output.on('data', (c) => chunks.push(c));
  });
}

export default {
  command: ['toaudio'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, usedPrefix, command, reply }) {
    const isMedia = m.mtype === 'audioMessage' || m.mtype === 'videoMessage';
    const quoted = m.quoted;
    const isQuotedMedia =
      quoted && (quoted.mtype === 'audioMessage' || quoted.mtype === 'videoMessage');

    if (!isMedia && !isQuotedMedia) {
      reply(
        `ᴋɪʀɪᴍ/ʀᴇᴘʟʏ *ᴠɴ/ᴠɪᴅᴇᴏ* ʏᴀɴɢ ᴍᴀᴜ ᴅɪ ᴜʙᴀʜ ᴋᴇ ᴀᴜᴅɪᴏ.\n\n` +
        `ᴄᴏɴᴛᴏʜ: ʀᴇᴘʟʏ/ᴋɪʀɪᴍ ᴠɪᴅᴇᴏ ᴋᴇᴛɪᴋ ${usedPrefix + command}`
      );
      return false;
    }

    const target = isQuotedMedia ? quoted : m;

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const buffer = await target.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil media-nya, coba reply ulang.');
        return false;
      }

      const audio = await toAudio(buffer);

      await Shoyu.sendMessage(
        m.chat,
        {
          audio: audio,
          ptt: false,
          mimetype: 'audio/mpeg',
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[toaudio]', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal convert ke audio.\n\n' + err.message);
      return false;
    }
  },
};