export default {
  command: ['idch', 'cekidch', 'cekch'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, reply }) {
    if (!text) return reply('💬 masukan link channelnya');
    if (!text.includes('https://whatsapp.com/channel/')) return reply('❌ Link tautan tidak valid!');

    const link = text.trim();

    try {
      const invite = link.split('https://whatsapp.com/channel/')[1]?.split(/[?\s]/)[0];

      const cekInfoCh = async (input) => {
        const metadataCh = await Shoyu.newsletterMetadata('invite', input);
        const followers = metadataCh.thread_metadata.subscribers_count;
        const verif = metadataCh.thread_metadata.verification;
        const name = metadataCh.thread_metadata.name.text;
        const id = metadataCh.id;
        const state = metadataCh.state.type;
        return { followers, verif, name, id, state };
      };

      const output = await cekInfoCh(invite);

      const teks =
        `╭─✦ 𝗜𝗻𝗳𝗼 𝗖𝗵𝗮𝗻𝗻𝗲𝗹 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽\n` +
        `⟡ 𝗡𝗔𝗠𝗘 : ${output.name}\n` +
        `⟡ 𝗙𝗼𝗹𝗹𝗼𝘄𝗲𝗿𝘀 : ${output.followers}\n` +
        `⟡ 𝗦𝘁𝗮𝘁𝘂𝘀 : ${output.verif === 'verified' ? 'Verified ✅' : 'Belum Verified ❌'}\n` +
        `⟡ 𝗜𝗗 : ${output.id}\n` +
        `╰──────────✦`;

      await Shoyu.sendButtons(
        m.chat,
        {
          text: teks,
          footer: global.namaBot || 'Info Channel',
          buttons: [
            { text: 'Buka Channel', url: link },
            { text: 'Salin ID Saluran', copy: output.id },
          ],
        },
        { quoted: m }
      );
    } catch (err) {
      console.error('[IDCH] Error:', err);
      reply(`❌ Gagal mengambil data channel!\n📄 ${err.message}`);
    }
  },
};