import { enhanceImage } from '../../src/scrape/Hd-imglarger.js';

export default {
  command: ['enhance', 'hd1', 'enlarger'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, command, usedPrefix, reply }) {
    const quoted = m.quoted && m.quoted.mtype === 'imageMessage' ? m.quoted : m;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';

    if (!/image/.test(mime)) {
      reply(
        `ʀᴇᴘʟʏ *ғᴏᴛᴏ*-ɴʏᴀ ᴅᴇɴɢᴀɴ ᴄᴀᴘᴛɪᴏɴ *${usedPrefix + command}*\n\n` +
        `• *${usedPrefix}enhance* / *${usedPrefix}hd* → perbaiki kualitas/wajah\n` +
        `• *${usedPrefix}enlarger* / *${usedPrefix}upscale* → perbesar resolusi`
      );
      return false;
    }

    const toolType = ['enlarger', 'upscale'].includes(command.toLowerCase()) ? 'enlarger' : 'enhancer';

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil gambarnya, coba reply ulang.');
        return false;
      }

      const result = await enhanceImage(buffer, toolType, 'image.jpg');

      const caption =
        `✨ Tool: ${result.tool === 'enlarger' ? 'Enlarger (Upscale)' : 'Enhancer'}\n` +
        `🧠 Model: ${result.model}\n` +
        `💾 Ukuran hasil: ${result.sizeMB} MB`;

      await Shoyu.sendMessage(m.chat, { image: result.buffer, caption }, { quoted: m });
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[ENHANCE] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal proses gambarnya.\n\n' + err.message);
      return false;
    }
  },
};
