import { getPlayerInfo } from '../../src/scrape/stalkerml.js';

export default {
  command: ['stalkml', 'stalkerml', 'idml'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴜsᴇʀ ɪᴅ ᴅᴀɴ ᴢᴏɴᴇ ɪᴅ ᴀᴋᴜɴ ᴍᴏʙɪʟᴇ ʟᴇɢᴇɴᴅs ᴋᴀᴍᴜ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 123456789 12345`
      );
      return false;
    }

    const [roleId, zoneId] = text.trim().split(/\s+/);

    if (!roleId || !zoneId) {
      reply(`Format salah.\n\nContoh:\n${usedPrefix + command} 123456789 12345`);
      return false;
    }

    try {
      const info = await getPlayerInfo(roleId, zoneId);

      if (!info.success) {
        reply(`❌ ${info.message}`);
        return false;
      }

      const teks =
        `╭─✦ 𝗦𝗧𝗔𝗟𝗞𝗘𝗥 𝗠𝗟\n` +
        `│⟡ ᴜsᴇʀɴᴀᴍᴇ : *${info.username}${info.squadTag ? ` (${info.squadTag})` : ''}*\n` +
        `│⟡ ᴜsᴇʀ ɪᴅ : *${info.roleId}*\n` +
        `│⟡ ᴢᴏɴᴇ ɪᴅ : *${info.zoneId}*\n` +
        `│⟡ ʀᴇɢɪᴏɴ : *${info.region}*\n` +
        `│⟡ ᴜᴍᴜʀ ᴀᴋᴜɴ : *${info.estimatedAge}*\n` +
        `│⟡ sᴛᴀᴛᴜs : *${info.accountStatus}*\n` +
        `╰──────────✦`;

      reply(teks);
    } catch (err) {
      console.error('[CEKML] Error:', err);
      reply('Gagal cek akun ML.\n\n' + (err?.message || JSON.stringify(err)));
      return false;
    }
  },
};