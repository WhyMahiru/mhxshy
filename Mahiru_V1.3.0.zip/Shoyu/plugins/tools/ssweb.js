import { ssweb } from '../../src/scrape/scraper.js';

export default {
  command: ['ssweb', 'screenshot', 'ss web'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ᴡᴇʙsɪᴛᴇ ʏᴀɴɢ ᴍᴀᴜ ᴅɪ-sᴄʀᴇᴇɴsʜᴏᴛ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} https://google.com\n\n` +
        `*ᴀᴛᴜʀ ᴅᴇᴠɪᴄᴇ (ᴏᴘsɪᴏɴᴀʟ):*\n${usedPrefix + command} https://google.com,mobile\n\n` +
        `ᴅᴇᴠɪᴄᴇ: desktop / mobile / tablet`
      );
      return false;
    }

    const [rawUrl, rawDevice] = text.split(',').map((v) => v?.trim());

    const isUrl = /^https?:\/\/.+/i.test(rawUrl || '');
    if (!isUrl) {
      reply('Link tidak valid, pastikan diawali dengan http:// atau https://');
      return false;
    }

    const allowedDevices = ['desktop', 'mobile', 'tablet'];
    const device = allowedDevices.includes((rawDevice || '').toLowerCase())
      ? rawDevice.toLowerCase()
      : 'desktop';

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { result } = await ssweb(rawUrl, device);

      const body =
        `╭─✦ 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁 𝗪𝗲𝗯\n` +
        `│⟡ Url : ${rawUrl}\n` +
        `│⟡ Device : ${device}\n` +
        `│⟡ Status : Berhasil diambil\n` +
        `╰──────────✦`;

      await Shoyu.sendMessage(
        m.chat,
        { image: result, caption: body },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[SSWEB] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mengambil screenshot website.\n\n' + (err?.message || JSON.stringify(err)));
      return false;
    }
  },
};
