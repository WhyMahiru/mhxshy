import { transcribeAudio } from '../../src/scrape/transcribe.js';

export default {
  command: ['totext', 'transcribe', 'audiototext'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {
    const isAudio = m.mtype === 'audioMessage' || m.mtype === 'voiceMessage';
    const hasQuotedAudio =
      m.quoted && (m.quoted.mtype === 'audioMessage' || m.quoted.mtype === 'voiceMessage');

    if (!isAudio && !hasQuotedAudio) {
      reply('⚠️ Kirim atau reply audio / voice note untuk ditranskripsi jadi teks.');
      return false;
    }

    const target = hasQuotedAudio ? m.quoted : m;

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const buffer = await target.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil audionya, coba reply ulang.');
        return false;
      }

      const result = await transcribeAudio(buffer, `audio_${Date.now()}.mp3`);

      await Shoyu.sendMessage(
        m.chat,
        {
          text:
            `✅ Transkripsi Selesai\n\n` +
            `📝 Teks:\n${result.text || '-'}\n\n` +
            `🌐 Bahasa: ${result.language || '-'}`,
        },
        { quoted: m }
      );
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[totext]', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mentranskripsi audionya.\n\n' + err.message);
      return false;
    }
  },
};