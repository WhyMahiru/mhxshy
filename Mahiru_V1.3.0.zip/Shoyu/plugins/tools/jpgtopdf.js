import fs from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import { jpgToPdf } from '../../src/scrape/scraper.js';

global.pdfSessions = global.pdfSessions || {};

function tmpImgPath(ext = 'jpg') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.${ext}`);
}

export default {
  command: ['jpgtopdf', 'jpg2pdf', 'img2pdf'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { reply, Shoyu, args, command }) {
    const prefix = global.prefix || '.';
    const cmd = prefix + command;
    const sub = (args[0] || '').toLowerCase();
    const sessionKey = m.sender;
    if (!global.pdfSessions[sessionKey]) global.pdfSessions[sessionKey] = [];
    const session = global.pdfSessions[sessionKey];

    const helpText =
      `📄 *${command.toUpperCase()}*\n` +
      `Gabungin beberapa gambar jadi 1 file PDF\n\n` +
      `*Cara pakai:*\n` +
      `1️⃣ Reply gambar, ketik \`${cmd} add\`\n` +
      `2️⃣ Ulangi buat tiap gambar berikutnya\n` +
      `3️⃣ Udah semua? Ketik \`${cmd} done\`\n\n` +
      `*Command lain:*\n` +
      `• \`${cmd} list\` — cek jumlah gambar di antrian\n` +
      `• \`${cmd} clear\` — kosongin antrian`;

    if (sub !== 'add' && sub !== 'done' && sub !== 'list' && sub !== 'clear') {
      reply(helpText);
      return false;
    }

    if (sub === 'add') {
      if (!m.quoted || m.quoted.mtype !== 'imageMessage') {
        reply(
          `❌ Belum ada gambar yang di-reply.\n\n` +
          `Reply gambar (JPG/PNG) dulu, baru ketik \`${cmd} add\`.`
        );
        return false;
      }

      try {
        const buffer = await m.quoted.download();
        const ext = m.quoted.mimetype?.includes('png') ? 'png' : 'jpg';
        const filePath = tmpImgPath(ext);
        fs.writeFileSync(filePath, buffer);

        session.push(filePath);

        reply(
          `✅ *Gambar ditambahin*\n\n` +
          `Total di antrian: *${session.length}*\n\n` +
          `Reply gambar lain buat nambah lagi, atau ketik \`${cmd} done\` kalau udah selesai.`
        );
        return false;
      } catch (e) {
        reply(`❌ Gagal download gambar:\n${e.message}`);
        return false;
      }
    }

    if (sub === 'list') {
      if (!session.length) {
        reply(`📋 Antrian kamu masih kosong.`);
        return false;
      }
      reply(`📋 Ada *${session.length}* gambar di antrian kamu.`);
      return false;
    }

    if (sub === 'clear') {
      const total = session.length;

      for (const f of session) {
        try { fs.unlinkSync(f); } catch {}
      }
      global.pdfSessions[sessionKey] = [];

      if (!total) {
        reply(`🗑️ Antrian emang udah kosong dari awal, gak ada yang dihapus.`);
      } else {
        reply(
          `🗑️ *Antrian dibersihkan*\n\n` +
          `${total} gambar berhasil dihapus.\n\n` +
          `Mau mulai lagi dari nol? Reply gambar, ketik \`${cmd} add\`.`
        );
      }
      return false;
    }

    if (sub === 'done') {
      if (!session.length) {
        reply(
          `📭 Antrian masih kosong.\n\n` +
          `Reply gambar dulu, ketik \`${cmd} add\`.`
        );
        return false;
      }

      try {
        await reply(`⏳ Lagi gabungin *${session.length}* gambar jadi 1 PDF...`);

        const { buffer } = await jpgToPdf(session);
        const total = session.length;

        await Shoyu.sendMessage(
          m.chat,
          {
            document: buffer,
            mimetype: 'application/pdf',
            fileName: `${command}-${Date.now()}.pdf`,
          },
          { quoted: m }
        );

        reply(
          `✅ *PDF berhasil dibuat!*\n\n` +
          `Total gambar: *${total}*\n\n` +
          `Antrian masih tersimpan, kalau ada yang ketinggalan:\n` +
          `• \`${cmd} add\` — tambah gambar lagi\n` +
          `• \`${cmd} done\` — buat ulang PDF-nya\n\n` +
          `Udah beres semua? Ketik \`${cmd} clear\`.`
        );


      } catch (e) {
        reply(`❌ Gagal gabungin jadi PDF:\n${e.message}`);
        return false;
      }
    }
  },
};