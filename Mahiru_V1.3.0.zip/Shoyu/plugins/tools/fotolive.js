import fs from 'fs';
import os from 'os';
import path from 'path';
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg';
import ff from 'fluent-ffmpeg';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

ff.setFfmpegPath(ffmpegInstaller.path);

export default {
  command: ['fotolive', 'livephoto', 'livepic'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {
    const quoted = m.quoted ? m.quoted : m;
    const mime = quoted.mimetype || '';

    if (!mime.includes('video')) {
       reply('Balas/reply video yang valid buat dijadiin Live Photo ya kak~');
       return false;
    }

    const tmpVideo = path.join(os.tmpdir(), `lv_video_${Date.now()}.mp4`);
    const tmpThumb = path.join(os.tmpdir(), `lv_thumb_${Date.now()}.jpg`);

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const videoBuffer = await quoted.download();
      if (!videoBuffer || !videoBuffer.length) {
         reply('Gagal download videonya, coba reply ulang ya kak~');
         return false;
      }

      fs.writeFileSync(tmpVideo, videoBuffer);

      await new Promise((resolve, reject) => {
        ff(tmpVideo)
          .outputOptions(['-vframes 1', '-q:v 2'])
          .output(tmpThumb)
          .on('end', resolve)
          .on('error', reject)
          .run();
      });

      const thumbBuffer = fs.readFileSync(tmpThumb);

      const imageMedia = await prepareWAMessageMedia(
        { image: thumbBuffer },
        { upload: Shoyu.waUploadToServer }
      );
      const videoMedia = await prepareWAMessageMedia(
        { video: videoBuffer },
        { upload: Shoyu.waUploadToServer }
      );

      const photoMsg = await generateWAMessageFromContent(
        m.chat,
        {
          imageMessage: {
            ...imageMedia.imageMessage,
            contextInfo: { pairedMediaType: 5, statusSourceType: 0 },
          },
        },
        { quoted: m, userJid: Shoyu.user.id }
      );

      await Shoyu.relayMessage(m.chat, photoMsg.message, { messageId: photoMsg.key.id });

      await Shoyu.relayMessage(
        m.chat,
        {
          videoMessage: {
            ...videoMedia.videoMessage,
            contextInfo: { pairedMediaType: 6, statusSourceType: 0 },
          },
          messageContextInfo: {
            messageAssociation: { associationType: 12, parentMessageKey: photoMsg.key },
          },
        },
        {}
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
      console.error('[FOTOLIVE] Error:', e);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal bikin foto live-nya kak~ coba lagi nanti ya 🌸');
      return false;
    } finally {
      try { if (fs.existsSync(tmpVideo)) fs.unlinkSync(tmpVideo); } catch {}
      try { if (fs.existsSync(tmpThumb)) fs.unlinkSync(tmpThumb); } catch {}
    }
  },
};
