import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import axios from 'axios';

const BG_URL =
  'https://raw.githubusercontent.com/rzkrohanmedia/cloud-backup/main/uploads/KyzoCDN_1784739409872_undefined.png';
const FONT_FAMILY = 'Patrick Hand';
const FONT_PATH = join(process.cwd(), 'assets', 'fonts', 'Patrick.ttf');
const ASSETS_DIR = join(process.cwd(), 'assets', 'kertas_maker');
const BG_LOCAL = join(ASSETS_DIR, 'bg_kertas.png');

const CURVE = [-4.04475620e-05, 3.84492286e-02, 3.19939613e+02];
function curveY(x) {
  const [a, b, c] = CURVE;
  return a * x * x + b * x + c;
}


const CURVE_CLAMP_X = 950;

const CANVAS_W = 1080;
const CANVAS_H = 1920;
const PITCH = 48;
const REF_X = 150.14;
const MAX_WIDTH = 900;
const BOTTOM_MARGIN = 60; 

const FONT_SIZE_MAX = 36;
const FONT_SIZE_MIN = 24; 
const FONT_SIZE_STEP = 1;


const PAPER_BOTTOM_Y = 1760;

let _fontRegistered = false;
let _assetsReady = false;

async function ensureAssets() {
  if (!_fontRegistered) {
    if (!existsSync(FONT_PATH)) {
      throw new Error(`Font tidak ditemukan di ${FONT_PATH}. Pastikan Patrick.ttf sudah ditaruh di assets/fonts/`);
    }
    GlobalFonts.registerFromPath(FONT_PATH, FONT_FAMILY);
    _fontRegistered = true;
  }
  if (_assetsReady) return;
  await mkdir(ASSETS_DIR, { recursive: true });
  if (!existsSync(BG_LOCAL)) {
    const res = await axios.get(BG_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    await writeFile(BG_LOCAL, Buffer.from(res.data));
  }
  _assetsReady = true;
}

function computeMaxLines(rowStartY) {
  return Math.max(1, Math.floor((PAPER_BOTTOM_Y - BOTTOM_MARGIN - rowStartY) / PITCH) + 1);
}

function wrapToLines(ctx, text, maxWidth) {
  const lines = [];
  const paragraphs = String(text).split('\n');
  for (const paragraph of paragraphs) {
    const words = paragraph.split(' ').filter(Boolean);
    if (!words.length) {
      lines.push('');
      continue;
    }
    let line = '';
    for (const word of words) {
      const testLine = line + word + ' ';
      if (ctx.measureText(testLine).width > maxWidth && line !== '') {
        lines.push(line.trim());
        line = word + ' ';
      } else {
        line = testLine;
      }
    }
    if (line) lines.push(line.trim());
  }
  return lines;
}

function renderLineCurved(ctx, lineText, startX, baseY, baseCurveY) {
  let cursorX = startX;
  const words = lineText.split(' ');
  for (const word of words) {
    const offsetY = curveY(Math.min(cursorX, CURVE_CLAMP_X)) - baseCurveY;
    ctx.fillText(word, cursorX, baseY + offsetY);
    cursorX += ctx.measureText(word + ' ').width;
  }
}

function drawLines(ctx, lines, x, startY, baseCurveY) {
  lines.forEach((lineText, i) => {
    if (!lineText) return;
    renderLineCurved(ctx, lineText, x, startY + i * PITCH, baseCurveY);
  });
}


function fitFontSize(ctx, text, maxLines) {
  for (let size = FONT_SIZE_MAX; size >= FONT_SIZE_MIN; size -= FONT_SIZE_STEP) {
    ctx.font = `${size}px '${FONT_FAMILY}'`;
    const lines = wrapToLines(ctx, text, MAX_WIDTH);
    if (lines.length <= maxLines) {
      return { fontSize: size, lines };
    }
  }

  ctx.font = `${FONT_SIZE_MIN}px '${FONT_FAMILY}'`;
  return { fontSize: FONT_SIZE_MIN, lines: wrapToLines(ctx, text, MAX_WIDTH) };
}

function paginateText(ctx, text, maxLines) {
  ctx.font = `${FONT_SIZE_MIN}px '${FONT_FAMILY}'`;
  const words = String(text).replace(/\n/g, ' \n ').split(' ').filter((w) => w !== '');

  const pages = [];
  let current = [];

  const fitsAsLines = (tokens) => {
    const joined = tokens.join(' ').replace(/ \n /g, '\n');
    return wrapToLines(ctx, joined, MAX_WIDTH).length <= maxLines;
  };

  for (const word of words) {
    const attempt = [...current, word];
    if (current.length > 0 && !fitsAsLines(attempt)) {
      pages.push(current.join(' ').replace(/ \n /g, '\n').trim());
      current = [word];
    } else {
      current = attempt;
    }
  }
  if (current.length) pages.push(current.join(' ').replace(/ \n /g, '\n').trim());

  return pages.length ? pages : [text];
}

async function renderPage(text, fontSize, lines) {
  const bg = await loadImage(BG_LOCAL);
  const canvas = createCanvas(CANVAS_W, CANVAS_H);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bg, 0, 0, CANVAS_W, CANVAS_H);
  ctx.font = `${fontSize}px '${FONT_FAMILY}'`;
  ctx.fillStyle = '#444444';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';

  const baseCurveY = curveY(REF_X);
  const row0Center = baseCurveY - PITCH / 2;
  drawLines(ctx, lines, REF_X, row0Center, baseCurveY);

  return canvas.encode('png');
}


async function generateKertas(text) {
  await ensureAssets();

  const measureCanvas = createCanvas(CANVAS_W, CANVAS_H);
  const measureCtx = measureCanvas.getContext('2d');

  const row0Center = curveY(REF_X) - PITCH / 2;
  const maxLines = computeMaxLines(row0Center);

  const { fontSize, lines } = fitFontSize(measureCtx, text, maxLines);

  if (lines.length <= maxLines) {

    const buf = await renderPage(text, fontSize, lines);
    return [buf];
  }

  const pages = paginateText(measureCtx, text, maxLines);
  const buffers = [];
  for (const pageText of pages) {
    measureCtx.font = `${FONT_SIZE_MIN}px '${FONT_FAMILY}'`;
    const pageLines = wrapToLines(measureCtx, pageText, MAX_WIDTH);
    buffers.push(await renderPage(pageText, FONT_SIZE_MIN, pageLines));
  }
  return buffers;
}

export default {
  command: ['nulis', 'buku', 'kertas'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text || !text.trim()) {
      reply(
        `Masukkan teksnya ya.\n\nContoh: ${usedPrefix + command} perkenalkan nama saya Ilham saya dari kamboja.\nBisa pakai enter buat ganti paragraf.`
      );
      return false;
    }

    try {
      const pages = await generateKertas(text.trim());

      for (let i = 0; i < pages.length; i++) {
        await Shoyu.sendMessage(
          m.chat,
          {
            image: pages[i],
            caption: pages.length > 1 ? `Halaman ${i + 1}/${pages.length}` : 'Done.',
          },
          { quoted: m }
        );
      }
    } catch (err) {
      console.error('[KERTAS] Error:', err);
      reply('Gagal bikin gambarnya, coba lagi ya.\n\n' + err.message);
      return false;
    }
  },
};