import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import unzipper from 'unzipper';
import { pdfToJpg } from '../../src/scrape/scraper.js';

export default {
  command: ['pdftojpg'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const quoted = m.quoted && m.quoted.mtype === 'documentMessage' ? m.quoted : m;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';
    const fileName = quoted?.msg?.fileName || quoted?.fileName || '';

    const isPdf = /application\/pdf/i.test(mime) || /\.pdf$/i.test(fileName);

    if (!isPdf) {
      reply(
        `ʀᴇᴘʟʏ *ғɪʟᴇ ᴘᴅғ* ᴅᴇɴɢᴀɴ ᴄᴀᴘᴛɪᴏɴ *${usedPrefix + command}*\n\n` +
        `*ᴀᴛᴜʀ ᴅᴘɪ (ᴏᴘsɪᴏɴᴀʟ):*\n${usedPrefix + command} 200`
      );
      return false;
    }

    const dpi = /^\d+$/.test((text || '').trim()) ? text.trim() : '150';

    let tmpPdf = null;
    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil file PDF-nya, coba reply ulang.');
        return false;
      }

      tmpPdf = path.join(
        os.tmpdir(),
        `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.pdf`
      );
      fs.writeFileSync(tmpPdf, buffer);

      const { buffer: result } = await pdfToJpg(tmpPdf, { mode: 'pages', dpi });

      const isZip = result.slice(0, 2).toString('hex') === '504b';

      if (isZip) {
        const directory = await unzipper.Open.buffer(result);
        const images = directory.files.filter((f) => /\.(jpe?g)$/i.test(f.path));

        if (!images.length) throw new Error('Tidak ada gambar hasil konversi di dalam zip.');

        for (const file of images) {
          const imgBuffer = await file.buffer();
          await Shoyu.sendMessage(
            m.chat,
            { image: imgBuffer, caption: file.path },
            { quoted: m }
          );
        }
      } else {
        await Shoyu.sendMessage(
          m.chat,
          { image: result, caption: fileName.replace(/\.pdf$/i, '.jpg') || 'result.jpg' },
          { quoted: m }
        );
      }

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[PDF2JPG] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal convert PDF ke JPG.\n\n' + err.message);
      return false;
    } finally {
      if (tmpPdf && fs.existsSync(tmpPdf)) {
        fs.unlink(tmpPdf, () => {});
      }
    }
  },
};
