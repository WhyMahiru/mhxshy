import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { getDetailDongworld } from '../../src/scrape/dongworld.js';

export default {
  command: ['donghuainfo', 'infodonghua', 'donghuadetail'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const slug = text?.trim();

    if (!slug) {
      reply(
        `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
          `> \`${usedPrefix + command} <slug>\`\n\n` +
          `> Slug bisa didapat dari hasil \`${usedPrefix}donghua <judul>\`\n\n` +
          `> Contoh:\n` +
          `> \`${usedPrefix + command} swallowed-star\``
      );
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '🕕', key: m.key } });

    try {
      const detail = await getDetailDongworld(slug);

      if (detail.status !== 'success' || !detail.data.episodes.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ Donghua dengan slug \`${slug}\` tidak ditemukan atau belum ada episode.`);
        return false;
      }

      const item = detail.data;

      // biar list-nya gak keputus, semua episode dimasukin & dikelompokin per 30 jadi beberapa section
      // (WA tetep punya batas wajar per pesan, jadi di-cap longgar di 300 episode buat jaga-jaga)
      const MAX_EPISODES = 300;
      const CHUNK_SIZE = 30;
      const episodesToShow = item.episodes.slice(0, MAX_EPISODES);

      const sections = [];
      for (let i = 0; i < episodesToShow.length; i += CHUNK_SIZE) {
        const chunk = episodesToShow.slice(i, i + CHUNK_SIZE);
        const from = chunk[0].episode_number;
        const to = chunk[chunk.length - 1].episode_number;
        sections.push({
          title: `Episode ${from}–${to}`,
          rows: chunk.map((ep) => ({
            header: `Episode ${ep.episode_number}`,
            title: item.title,
            description: 'Ketuk untuk ambil link stream',
            id: `${usedPrefix}nonton ${ep.slug}`,
          })),
        });
      }

      const more = item.episodes.length > MAX_EPISODES
        ? `\n(nampilin ${MAX_EPISODES} dari ${item.episodes.length} episode)`
        : '';

      const body =
        `╭─✦ *Detail Donghua*\n` +
        `│ ✦ Status  : ${item.status}\n` +
        `│ ✦ Episode : ${item.total_episodes}\n` +
        (item.description ? `│ ✦ Sinopsis: ${item.description}\n` : '') +
        `╰──────────✦${more}`;

      const media = item.thumbnail
        ? await generateWAMessageContent({ image: { url: item.thumbnail } }, { upload: Shoyu.waUploadToServer })
        : null;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: item.title,
                  subtitle: `by ${global.namaBot}`,
                  hasMediaAttachment: !!media,
                  ...(media ? { imageMessage: media.imageMessage } : {}),
                },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'single_select',
                      buttonParamsJson: JSON.stringify({
                        title: 'Pilih Episode',
                        sections,
                        icon: 'DEFAULT',
                      }),
                    },
                  ],
                  messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                      in_thread_buttons_limit: 1,
                      list_title: 'Pilih Episode',
                      button_title: ' ✦ Lihat Episode ✦ ',
                    },
                  }),
                },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[DONGHUAINFO] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`❌ ${err.message || 'Gagal mengambil detail donghua.'}`);
      return false;
    }
  },
};