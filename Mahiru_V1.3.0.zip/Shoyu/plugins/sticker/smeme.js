import sharp from 'sharp';
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { imageToWebp, addExif } from '../../src/lib/webp.js';

GlobalFonts.registerFromPath('./assets/fonts/arialnarrow.ttf', 'ArialNarrow');

const FONT_FAMILY = 'ArialNarrow, sans-serif';
const CANVAS_SIZE = 512;
const MARGIN = 20;

function wrapLines(ctx, text, maxWidth) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines = [];
  let current = '';

  for (const word of words) {
    const test = current ? `${current} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = test;
    }
  }
  if (current) lines.push(current);
  return lines;
}

function fitFontSize(ctx, text, maxWidth, maxHeight, startSize) {
  let size = startSize;
  while (size > 18) {
    ctx.font = `bold ${size}px ${FONT_FAMILY}`;
    const lines = wrapLines(ctx, text, maxWidth);
    const lineHeight = size * 1.15;
    if (lines.length * lineHeight <= maxHeight) return { size, lines, lineHeight };
    size -= 2;
  }
  ctx.font = `bold ${size}px ${FONT_FAMILY}`;
  return { size, lines: wrapLines(ctx, text, maxWidth), lineHeight: size * 1.15 };
}

function drawMemeText(ctx, text, maxWidth, startY, lineHeight, size, fromTop) {
  ctx.textAlign = 'center';
  ctx.textBaseline = fromTop ? 'top' : 'bottom';
  ctx.lineWidth = Math.max(4, Math.round(size / 8));
  ctx.strokeStyle = '#000000';
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${size}px ${FONT_FAMILY}`;

  const lines = wrapLines(ctx, text, maxWidth);
  lines.forEach((line, i) => {
    const y = fromTop ? startY + i * lineHeight : startY - (lines.length - 1 - i) * lineHeight;
    ctx.strokeText(line, CANVAS_SIZE / 2, y);
    ctx.fillText(line, CANVAS_SIZE / 2, y);
  });
}

export default {
  command: ['smeme'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const quoted = m.quoted && ['imageMessage', 'stickerMessage'].includes(m.quoted.mtype) ? m.quoted : m;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';

    if (!/image/.test(mime)) {
      reply(
        `*𝗦𝗧𝗜𝗖𝗞𝗘𝗥 𝗠𝗘𝗠𝗘*\n\n` +
        `ᴋɪʀɪᴍ *ғᴏᴛᴏ/sᴛɪᴄᴋᴇʀ* ᴅᴇɴɢᴀɴ ᴄᴀᴘᴛɪᴏɴ *${usedPrefix + command}*, ᴀᴛᴀᴜ ʀᴇᴘʟʏ ғᴏᴛᴏ/sᴛɪᴄᴋᴇʀ ᴅᴇɴɢᴀɴ ᴄᴀᴘᴛɪᴏɴ ɪᴛᴜ.\n\n` +
        `Format teks:\n` +
        `• ᴛᴇᴋs ᴀᴛᴀs ᴀᴊᴀ: ${usedPrefix + command} teks atas\n` +
        `• ᴛᴇᴋs ʙᴀᴡᴀʜ ᴀᴊᴀ: ${usedPrefix + command} |teks bawah\n\n` +
        `• ᴛᴇᴋs ᴀᴛᴀs & ʙᴀᴡᴀʜ: ${usedPrefix + command} teks atas|teks bawah\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} pas senin pagi|langsung ditagih deadline`
      );
      return false;
    }

    if (!text || !text.trim()) {
      reply(
        `𝗧𝗲𝗸𝘀𝗻𝘆𝗮 𝗯𝗲𝗹𝘂𝗺 𝗱𝗶𝗶𝘀𝗶.\n\n` +
        `𝗙𝗼𝗿𝗺𝗮𝘁 𝘁𝗲𝗸𝘀:\n` +
        `• ᴛᴇᴋs ᴀᴛᴀs ᴀᴊᴀ: ${usedPrefix + command} teks atas\n` +
        `• ᴛᴇᴋs ᴀᴛᴀs & ʙᴀᴡᴀʜ: ${usedPrefix + command} teks atas|teks bawah\n` +
        `• ᴛᴇᴋs ʙᴀᴡᴀʜ ᴀᴊᴀ: ${usedPrefix + command} |teks bawah`
      );
      return false;
    }

    const [top, bottom] = text.split('|').map((v) => (v || '').trim().toUpperCase());

    try {
      const rawBuffer = await quoted.download();
      if (!rawBuffer || !rawBuffer.length) {
        reply('Gagal ambil medianya, coba reply ulang.');
        return false;
      }

      const pngBuffer = await sharp(rawBuffer)
        .resize(CANVAS_SIZE, CANVAS_SIZE, { fit: 'cover' })
        .png()
        .toBuffer();

      const image = await loadImage(pngBuffer);
      const canvas = createCanvas(CANVAS_SIZE, CANVAS_SIZE);
      const ctx = canvas.getContext('2d');

      ctx.drawImage(image, 0, 0, CANVAS_SIZE, CANVAS_SIZE);

      const maxTextWidth = CANVAS_SIZE - MARGIN * 2;
      const maxTextHeight = CANVAS_SIZE * 0.3;

      if (top) {
        const { size, lines, lineHeight } = fitFontSize(ctx, top, maxTextWidth, maxTextHeight, 60);
        drawMemeText(ctx, top, maxTextWidth, MARGIN, lineHeight, size, true);
      }

      if (bottom) {
        const { size, lines, lineHeight } = fitFontSize(ctx, bottom, maxTextWidth, maxTextHeight, 60);
        const startY = CANVAS_SIZE - MARGIN;
        drawMemeText(ctx, bottom, maxTextWidth, startY, lineHeight, size, false);
      }

      const finalPng = await canvas.encode('png');
      const webpBuffer = await imageToWebp(finalPng);
      const stickerBuffer = await addExif(webpBuffer, global.namaBot, global.footer || '');

      await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
    } catch (err) {
      reply('Gagal bikin sticker meme-nya. Coba lagi atau pakai media lain.');
      return false;
    }
  },
};