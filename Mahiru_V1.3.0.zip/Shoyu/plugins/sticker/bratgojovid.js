import { videoToWebp, addExif } from '../../src/lib/webp.js';
import { createBratVideo } from '../../src/canvas/gojoBratVideo.js';

export default {
  command: ['bratgojovid'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text || !text.trim()) {
      reply(`Masukkan teksnya ya.\n\nContoh: ${usedPrefix + command} halo semuanya`);
      return false;
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const mp4Buffer = await createBratVideo(text.trim());
      const webpBuffer = await videoToWebp(mp4Buffer, {
        quality: 16,
        compressionLevel: 6,
      });
      const stickerBuffer = await addExif(webpBuffer, global.namaBot, global.footer || '');

      await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[BRATGOJOVID] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal bikin video gojo-nya. Coba lagi ya.');
      return false;
    }
  },
};
