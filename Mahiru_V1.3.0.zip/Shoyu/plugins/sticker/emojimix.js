import { emojiKitchen, fetchEmojiImage } from '../../src/scrape/emojikitchen.js';
import { imageToWebp, addExif } from '../../src/lib/webp.js';

const EMOJI_REGEX = /\p{Extended_Pictographic}\uFE0F?/gu;

export default {
	command: ['emojimix', 'mixemoji'],
	group: false,
	limit: true,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,

	async run(m, { Shoyu, text, usedPrefix, command, reply }) {
		const input = text?.trim();

		if (!input) {
			 reply(
				`ᴍᴀsᴜᴋᴋᴀɴ ᴅᴜᴀ ᴇᴍᴏᴊɪ ʏᴀɴɢ ᴍᴀᴜ ᴅɪɢᴀʙᴜɴɢ.\n\n` +
					`ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 😂❤️`
			);
			return false;
		}

		const emojis = input.match(EMOJI_REGEX);
		if (!emojis || emojis.length < 2) {
			 reply(
				`ғᴏʀᴍᴀᴛ sᴀʟᴀʜ, ᴍᴀsᴜᴋᴋᴀɴ ᴛᴇᴘᴀᴛ 2 ᴇᴍᴏᴊɪ.\n\n` +
					`ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 😂❤️`
			);
			return false;
		}

		const [emoji1, emoji2] = emojis;

		try {
			await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

			const result = await emojiKitchen(emoji1, emoji2);

			if (!result.success || !result.image) {
				await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
				 reply(`ɢᴀɢᴀʟ ᴍᴇɴɢɢᴀʙᴜɴɢ ᴇᴍᴏᴊɪ.\n\n${result.error || 'ᴋᴏᴍʙɪɴᴀsɪ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ, ᴄᴏʙᴀ ᴋᴏᴍʙɪɴᴀsɪ ʟᴀɪɴ.'}`);
				 return false;
			}

			const imageBuffer = await fetchEmojiImage(result.image);

			const webpBuffer = await imageToWebp(imageBuffer);
			const stickerBuffer = await addExif(webpBuffer, global.namaBot, global.footer || '');

			await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
			await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
		} catch (err) {
			console.error('[EMOJIMIX] Error:', err);
			await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
			 reply('ɢᴀɢᴀʟ ᴍᴇɴɢɢᴀʙᴜɴɢ ᴇᴍᴏᴊɪ. ᴄᴏʙᴀ ʟᴀɢɪ ʏᴀ.');
			 return false;
		}
	},
};