import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { searchPacks, getTrending, getRandomPack } from '../../src/scrape/sigstick.js';

const MAX_RESULTS = 30;
const MAX_STICKERS = Infinity;

const truncate = (str = '', max = 40) => (str.length > max ? str.slice(0, max - 3) + '...' : str);

const packCache = new Map();

function cachePack(pack) {
  const id = String(pack?.id ?? '').trim();
  if (!id) return null;

  packCache.set(id, pack);

  if (packCache.size > 300) {
    const oldest = packCache.keys().next().value;
    packCache.delete(oldest);
  }

  return id;
}

async function processAndSendPack(Shoyu, m, pack, reply) {
  await Shoyu.sendMessage(m.chat, { react: { text: '🧵', key: m.key } });
  reply(`sᴇᴅᴀɴɢ ᴍᴇᴍᴘʀᴏsᴇs ᴘᴀᴋᴇᴛ sᴛɪᴄᴋᴇʀᴘᴀᴄᴋ ᴍɪʟɪᴋ "*${pack.title}*" sɪʟᴀʜᴋᴀɴ ᴛᴜɴɢɢᴜ ᴘʀᴏsᴇs ᴍᴜɴɢᴋɪɴ sᴇᴅɪᴋɪᴛ ʟᴀᴍᴀ (:`);

  const stickers = Array.isArray(pack.stickers) ? pack.stickers : [];
  if (!stickers.length) {
    await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    reply('Pack ini kosong, gak ada stickernya.');
    return;
  }

  const batch = stickers.slice(0, MAX_STICKERS);

  try {
    const msg = await Shoyu.sendStickerPackFromUrls(
      m.chat,
      batch,
      {
        name: pack.title || global.namaBot,
        publisher: pack.author || global.footer || global.namaBot,
        description: `Diambil dari Sigstick via ${global.namaBot}`,
      },
      { quoted: m }
    );

    await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    const { sent = batch.length, attempted = batch.length } = msg.stickerPackStats || {};
    const failed = attempted - sent;
    const note = failed > 0 ? ` (${failed} gagal didownload, jadi ${sent} dari ${attempted})` : '';
    reply(`ᴘᴀᴋᴇᴛ sᴛɪᴄᴋᴇʀ sᴜᴅᴀʜ ᴅɪ ʙᴜᴀᴛ, ᴛᴏᴛᴀʟ *${sent}* sᴛɪᴄᴋᴇʀ${note}. ᴛᴀᴘ ᴀᴅᴅ ᴜɴᴛᴜᴋ ᴍᴇɴʏɪᴍᴘᴀɴ (:`);
  } catch (err) {
    console.error('[SIGSTICK] Gagal kirim sticker pack:', err);
    await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    reply(`Gagal kirim sticker pack.\n${err.message}`);
  }
}

async function sendPackPicker(Shoyu, m, { title, subtitle, packs, usedPrefix }) {
  const list = packs.slice(0, MAX_RESULTS).filter((p) => cachePack(p));

  const rows = list.map((pack) => ({
    header: truncate(pack.title || 'Tanpa judul'),
    title: `${pack.author || 'Unknown'} • ${pack.stickers?.length || 0} sticker${pack.isNsfw ? ' • NSFW' : ''}`,
    description: `${pack.download || 0} download`,
    id: `${usedPrefix}sigstick get ${pack.id}`,
  }));

  const cover = list.find((p) => p.cover?.url)?.cover?.url;
  const media = cover
    ? await generateWAMessageContent({ image: { url: cover } }, { upload: Shoyu.waUploadToServer })
    : null;

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title,
              subtitle: subtitle || `by ${global.namaBot}`,
              hasMediaAttachment: !!media,
              ...(media ? { imageMessage: media.imageMessage } : {}),
            },
            body: { text: `ᴋᴇᴛᴇᴍᴜ ${packs.length} ᴘᴀᴄᴋ, ɪɴɪ ${list.length} ᴛᴇʀᴀᴛᴀs. ᴘɪʟɪʜ sᴀʟᴀʜ sᴀᴛᴜ.` },
            footer: { text: global.namaBot || '𝗦𝗜𝗚𝗦𝗧𝗜𝗖𝗞' },
            nativeFlowMessage: {
              buttons: [
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    title: 'Pilih Pack',
                    sections: [{ title: 'Hasil', rows }],
                    icon: 'DEFAULT',
                  }),
                },
              ],
              messageParamsJson: JSON.stringify({
                bottom_sheet: {
                  in_thread_buttons_limit: 1,
                  list_title: 'Pilih Pack',
                  button_title: 'Lihat Hasil',
                },
              }),
            },
          },
        },
      },
    },
    { userJid: Shoyu.user.id, quoted: m }
  );

  await Shoyu.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id,
    additionalNodes: [
      {
        tag: 'biz',
        attrs: {},
        content: [
          {
            tag: 'interactive',
            attrs: { type: 'native_flow', v: '1' },
            content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
          },
        ],
      },
    ],
  });
}

export default {
  command: ['sigstick', 'sigsticker'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const raw = text?.trim() || '';
    const [subRaw, ...rest] = raw.split(' ');
    const knownSub = subRaw?.toLowerCase();
    const isKnown = ['search', 'trending', 'random', 'get'].includes(knownSub);

    const help =
      `*Sigstick*\n\n` +
      `${usedPrefix + command} <query> \`cari sticker pack\`\n` +
      `${usedPrefix + command} trending \`lihat yang lagi rame\`\n` +
      `${usedPrefix + command} random \`ambil 1 pack acak\`\n` +
      `${usedPrefix + command} get <id> \`ambil pack dari id\`\n\n` +
      `> cpontoh: ${usedPrefix + command} \`meme spongebob\``;

    if (!raw) {
      reply(help);
      return false;
    }

    const sub = isKnown ? knownSub : 'search';
    const arg = isKnown ? rest.join(' ').trim() : raw;

    try {
      // ── search ──────────────────────────────
      if (sub === 'search') {
        if (!arg) {
          reply(`Keywordnya mana? Contoh: ${usedPrefix + command} kucing lucu`);
          return false;
        }

        await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        const packs = await searchPacks(arg);

        if (!packs.length) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          reply(`Gak ada pack buat "${arg}".`);
          return false;
        }

        await sendPackPicker(Shoyu, m, {
          title: 'Sigstick',
          subtitle: arg,
          packs,
          usedPrefix,
        });
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }

      // ── trending ────────────────────────────
      if (sub === 'trending') {
        await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        const packs = await getTrending();

        if (!packs.length) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          reply('Gagal ambil trending, coba lagi nanti.');
          return false;
        }

        await sendPackPicker(Shoyu, m, {
          title: 'Sigstick Trending',
          subtitle: 'Lagi rame',
          packs,
          usedPrefix,
        });
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }

      // ── random ──────────────────────────────
      if (sub === 'random') {
        const pack = await getRandomPack();
        cachePack(pack);
        await processAndSendPack(Shoyu, m, pack, reply);
        return;
      }

      // ── get ─────────────────────────────────
      if (sub === 'get') {
        const id = arg;
        if (!id) {
          reply(`Idnya mana? Biasanya ini kepencet otomatis dari tombol hasil search/trending.`);
          return false;
        }

        const pack = packCache.get(id);
        if (!pack) {
          reply('Id ini udah gak kesimpen (bot mungkin restart). Search ulang ya.');
          return false;
        }

        await processAndSendPack(Shoyu, m, pack, reply);
        return;
      }
    } catch (err) {
      console.error('[SIGSTICK] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Error: ${err.message}`);
      return false;
    }
  },
};