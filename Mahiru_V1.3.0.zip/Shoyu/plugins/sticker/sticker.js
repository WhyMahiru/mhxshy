import { imageToWebp, videoToWebp, addExif } from '../../src/lib/webp.js';

export default {
  command: ['s', 'sticker', 'stiker'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const quoted = m.quoted && ['imageMessage', 'videoMessage'].includes(m.quoted.mtype) ? m.quoted : m;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';

    if (!/image|video/.test(mime)) {
      reply(
        `ʀᴇᴘʟʏ *ғᴏᴛᴏ* ᴀᴛᴀᴜ *ᴠɪᴅᴇᴏ/ɢɪғ* (ᴍᴀx 5 ᴅᴇᴛɪᴋ) ᴅᴇɴɢᴀɴ ᴄᴀᴘᴛɪᴏɴ *${usedPrefix + command}*\n\n` +
        `*ᴄᴜsᴛᴏᴍ ᴘᴀᴄᴋɴᴀᴍᴇ/ᴀᴜᴛʜᴏʀ:*\n${usedPrefix + command} ᴘᴀᴄᴋɴᴀᴍᴇ|ᴀᴜᴛʜᴏʀ`
      );
      return false;
    }

    if (/video/.test(mime) && quoted.seconds && quoted.seconds > 5) {
      reply('Video/gif kepanjangan, maksimal *5 detik* ya.');
      return false;
    }

    const [packname, author] = (text || '').split('|').map((v) => v.trim());

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Gagal ambil medianya, coba reply ulang.');
        return false;
      }

      const webpBuffer = /video/.test(mime) ? await videoToWebp(buffer) : await imageToWebp(buffer);

      const stickerBuffer = await addExif(
        webpBuffer,
        packname || global.namaBot,
        author || global.footer || ''
      );

      await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[STICKER] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal bikin stikernya. Coba lagi atau pakai media lain.');
      return false;
    }
  },
};