import { imageToWebp, addExif } from '../../src/lib/webp.js';
import { createBratImage } from '../../src/canvas/vermeilBrat.js';

export default {
  command: ['bratvermeil'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text || !text.trim()) {
      reply(`Masukkan teksnya ya.\n\nContoh: ${usedPrefix + command} halo semuanya`);
      return false;
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const pngBuffer = await createBratImage(text.trim());
      const webpBuffer = await imageToWebp(pngBuffer);
      const stickerBuffer = await addExif(webpBuffer, global.namaBot, global.footer || '');

      await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[BRATVERMEIL] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal bikin sticker vermeil-nya. Coba lagi ya.');
      return false;
    }
  },
};
