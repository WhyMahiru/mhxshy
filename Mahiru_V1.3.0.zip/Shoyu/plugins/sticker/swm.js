import { addExif } from '../../src/lib/webp.js';

export default {
  command: ['swm', 'wm'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const quoted = m.quoted;

    if (!quoted || quoted.mtype !== 'stickerMessage') {
      reply(
        `Reply *sticker* dengan caption *${usedPrefix + command} packname|author*\n\n` +
        `Contoh:\n${usedPrefix + command} Shoyu Bot|Shoyu`
      );
      return false;
    }

    if (quoted.mimetype !== 'image/webp') {
      reply('Sticker ini bukan format WEBP biasa, tidak bisa diubah wm-nya.');
      return false;
    }

    if (!text) {
      reply(
        `Masukkan packname/author baru ya.\n\n` +
        `Contoh:\n${usedPrefix + command} Shoyu Bot|Shoyu`
      );
      return false;
    }

    const [packname, author] = text.split('|').map((v) => v.trim());

    try {
      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        reply('Gagal ambil stickernya, coba reply ulang.');
        return false;
      }

      const stickerBuffer = await addExif(
        buffer,
        packname || global.namaBot,
        author || ''
      );

      await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
    } catch (err) {
      console.error('[SWM] Error:', err);
      reply('Gagal ganti wm sticker. Coba lagi atau pakai sticker lain.');
      return false;
    }
  },
};