import { videoToWebp, addExif } from '../../src/lib/webp.js';

let _bratVid = null;
async function getBratVid() {
  if (_bratVid) return _bratVid;
  const origLog = console.log;
  console.log = () => {}; 
  try {
    ({ bratVid: _bratVid } = await import('brat-canvas/video'));
  } finally {
    console.log = origLog;
  }
  return _bratVid;
}

export default {
  command: ['bratvid'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text || !text.trim()) {
      reply(`Masukkan teksnya ya.\n\nContoh: ${usedPrefix + command} halo semua`);
      return false;
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const bratVid = await getBratVid();
      const gifBuffer = await bratVid(text.trim(), { outputFormat: 'gif' });
      const webpBuffer = await videoToWebp(gifBuffer);
      const stickerBuffer = await addExif(webpBuffer, global.namaBot, global.footer || '');

      await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[BRATVID] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal bikin sticker bratvid-nya. Coba lagi ya.');
      return false;
    }
  },
};
