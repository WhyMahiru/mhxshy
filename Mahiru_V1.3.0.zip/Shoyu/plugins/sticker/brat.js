import { imageToWebp, videoToWebp, addExif } from '../../src/lib/webp.js';
import { createGojoImage } from '../../src/canvas/gojoBrat.js';
import { createBratVideo as createGojoVideo } from '../../src/canvas/gojoBratVideo.js';
import { createBratImage as createVermeilImage } from '../../src/canvas/vermeilBrat.js';
import { createBratVideo as createVermeilVideo } from '../../src/canvas/vermeilBratVideo.js';

let _bratGen = null;
async function getBratGen() {
  if (_bratGen) return _bratGen;
  const origLog = console.log;
  console.log = () => {};
  try {
    ({ bratGen: _bratGen } = await import('brat-canvas'));
  } finally {
    console.log = origLog;
  }
  return _bratGen;
}

let _bratVid = null;
async function getBratVid() {
  if (_bratVid) return _bratVid;
  const origLog = console.log;
  console.log = () => {};
  try {
    ({ bratVid: _bratVid } = await import('brat-canvas/video'));
  } finally {
    console.log = origLog;
  }
  return _bratVid;
}

const VARIANTS = {
  classic:    { title: '𝗕𝗿𝗮𝘁 𝗖𝗹𝗮𝘀𝘀𝗶𝗰 🖼️',        description: 'sᴛɪᴄᴋᴇʀ ʙʀᴀᴛ ᴏʀɢɪɴᴀʟ' },
  classicvid: { title: '𝗕𝗿𝗮𝘁 𝗖𝗹𝗮𝘀𝘀𝗶𝗰 🎥', description: 'sᴛɪᴄᴋᴇʀ ʙʀᴀᴛ ᴏʀɢɪɴᴀʟ ɢᴇʀᴀᴋ' },
  gojo:       { title: '𝗕𝗿𝗮𝘁 𝗚𝗼𝗷𝗼 🖼️',            description: 'sᴛɪᴄᴋᴇʀ ʙʀᴀᴛ ɢᴏᴊᴏ ᴏʀɢɪɴᴀʟ' },
  gojovid:    { title: '𝗕𝗿𝗮𝘁 𝗚𝗼𝗷𝗼 🎥',     description: 'sᴛɪᴄᴋᴇʀ ʙʀᴀᴛ ɢᴏᴊᴏ ɢᴇʀᴀᴋ' },
  vermeil:    { title: '𝗕𝗿𝗮𝘁 𝗩𝗲𝗿𝗺𝗲𝗶𝗹 🖼️',         description: 'sᴛᴄɪᴋᴇʀ ʙʀᴀᴛ ᴠᴇʀᴍᴇɪʟ ᴏʀɢɪɴᴀʟ' },
  vermeilvid: { title: '𝗕𝗿𝗮𝘁 𝗩𝗲𝗿𝗺𝗲𝗶𝗹 🎥',  description: 'sᴛᴄɪᴋᴇʀ ʙʀᴀᴛ ᴠᴇʀᴍᴇɪʟ ɢᴇʀᴀᴋ' },
};

async function generateBratSticker(variant, text) {
  let buffer;
  let isVideo = false;

  switch (variant) {
    case 'classic': {
      const bratGen = await getBratGen();
      buffer = await bratGen(text);
      break;
    }
    case 'classicvid': {
      const bratVid = await getBratVid();
      buffer = await bratVid(text, { outputFormat: 'gif' });
      isVideo = true;
      break;
    }
    case 'gojo':
      buffer = await createGojoImage(text);
      break;
    case 'gojovid':
      buffer = await createGojoVideo(text);
      isVideo = true;
      break;
    case 'vermeil':
      buffer = await createVermeilImage(text);
      break;
    case 'vermeilvid':
      buffer = await createVermeilVideo(text);
      isVideo = true;
      break;
    default:
      throw new Error('Varian brat gak dikenal.');
  }

  const webpBuffer = isVideo
    ? await videoToWebp(buffer, { quality: 16, compressionLevel: 6 })
    : await imageToWebp(buffer);

  return addExif(webpBuffer, global.namaBot, global.footer || '');
}

export default {
  command: ['brat'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text || !text.trim()) {
     return reply(`Masukkan teksnya ya.\n\nContoh: ${usedPrefix + command} halo semua`);
      
    }

    const raw = text.trim();


    if (raw.startsWith('pick|')) {
      const [, variant, encodedText] = raw.split('|');
      const content = decodeURIComponent(encodedText || '');

      if (!VARIANTS[variant] || !content) {
        return reply(`Data gak valid, coba \`${usedPrefix}brat <teks>\` lagi ya.`);
      }

      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      try {
        const stickerBuffer = await generateBratSticker(variant, content);
        await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      } catch (err) {
        console.error('[BRAT] Error:', err);
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('Gagal bikin sticker brat-nya. Coba lagi ya.');
        
      }
      return;
    }

    const content = raw;

    const rows = Object.entries(VARIANTS).map(([key, v]) => ({
      title: v.title,
      description: v.description,
      id: `${usedPrefix}${command} pick|${key}|${encodeURIComponent(content)}`,
    }));

    await Shoyu.sendList(
      m.chat,
      {
        text: `Silahkan pilih gaya brat yang ingin kamu gunakan untuk teks:\n"*${content}*"`,
        footer: global.namaBot,
        title: '𝗕𝗿𝗮𝘁 𝗦𝘁𝗶𝗰𝗸𝗲𝗿 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗼𝗿',
        buttonText: 'Pilih Gaya',
        image: { url: 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/mahiru.jpeg' },
        sections: [{ title: 'Varian tersedia', rows }],
      },
      { quoted: m }
    );
  },
};