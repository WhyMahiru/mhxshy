export default {
  command: ['addai'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {
    try {
      const groupJid = m.chat;

      if (!groupJid.endsWith('@g.us')) {
        return reply('ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ɢʀᴜᴘ.');
      }

      const botMeta = '867051314767696@bot';

      await Shoyu.groupParticipantsUpdate(
        groupJid,
        [botMeta],
        'add'
      );

      reply('sᴜᴋsᴇs ᴀᴅᴅ ᴍᴇᴛᴀ ᴀɪ ᴋᴇ ɢʀᴜᴘ ✅');
    } catch (e) {
      console.error(e);
      reply(String(e?.message || e));
    }
  }
};