export default {
  command: ['hapusfotogrup', 'delppgrup', 'delppgc'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {

    try {
      await Shoyu.profilePictureUrl(m.chat, 'image');
    } catch {
      return reply('Grup ini belum punya foto profil, jadi gak ada yang perlu dihapus.');
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      await Shoyu.removeProfilePicture(m.chat);

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return reply('Berhasil hapus foto profil grup!');
    } catch (err) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return reply('Gagal hapus foto profil grup! Pastikan bot adalah admin.');
    }
  }
};
