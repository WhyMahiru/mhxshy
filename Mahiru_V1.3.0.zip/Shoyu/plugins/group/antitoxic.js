export default {
  command: ['antitoxic'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { args, command, usedPrefix, updateData, reply }) {

    const text = args[0] ? args[0].toLowerCase() : '';

    if (text === 'on') {
      await updateData('groups', m.chat, 'antitoxic', 1);
      return reply(`[✓] Fitur *Anti Toxic* berhasil diaktifkan!\nPesan yang mengandung kata kasar/toxic dari member (bukan admin) bakal otomatis dihapus.`);
    }

    if (text === 'off') {
      await updateData('groups', m.chat, 'antitoxic', 0);
      return reply(`[✓] Fitur *Anti Toxic* dimatikan.`);
    }

    return reply(`*Mode Switch Anti Toxic*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);
  }
};
