import { getGroup } from '../../src/lib/database.js';

export default {
  command: ['promote'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  
  async run(m, { Shoyu, text, command, reply, usedPrefix }) {

  	let targets = [];

  	if (m.mentionedJid?.length) targets = m.mentionedJid;
  	else if (m.quoted?.sender) targets = [m.quoted.sender];
  	else if (text) {
  		let clean = text.replace(/[^0-9]/g, '');
  		if (clean.length < 5) return reply('Nomor tidak valid!');
  		targets = [clean + '@s.whatsapp.net'];
  	}

  	if (!targets.length) return reply(`Contoh: ${usedPrefix + command} ᴛᴀɢ/ʀᴇᴘʟʏ/ɴᴏᴍᴏʀ`);

  	try {
  		await Shoyu.groupParticipantsUpdate(m.chat, targets, 'promote');

  		const groupData = await getGroup(m.chat);
  		if (groupData.welcome !== 1) {
  			const tags = targets.map(t => `@${t.split('@')[0]}`).join(' ');
  			await reply(`✅ ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴊᴀᴅɪᴋᴀɴ ${tags} sᴇʙᴀɢᴀɪ ᴀᴅᴍɪɴ!`, { mentions: targets });
  		}
  	} catch (err) {
  		reply('ɢᴀɢᴀʟ ᴍᴇɴᴊᴀᴅɪᴋᴀɴ ᴀᴅᴍɪɴ! ᴘᴀsᴛɪᴋᴀɴ ʙᴏᴛ ᴀᴅᴀʟᴀʜ ᴀᴅᴍɪɴ ᴅᴀɴ ᴀɴɢɢᴏᴛᴀ ᴛᴇʀsᴇʙᴜᴛ ᴀᴅᴀ ᴅɪ ɢʀᴜᴘ.');
  	}

  }
};