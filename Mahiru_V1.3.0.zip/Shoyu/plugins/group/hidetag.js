// plugins/grup/hidetag.js

export default {
  command: ['hidetag', 'ht', 'h'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: true,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  
  async run(m, { Shoyu, reply, text, usedPrefix, example, command }) {
  
  	if (!text) return reply(example(`pesan`));
  
  	try {
  		const metadata = await Shoyu.groupMetadata(m.chat);
  		const members = metadata.participants.map((m) => m.id);
  
  		await Shoyu.sendMessage(
  			m.chat,
  			{
  				text: text,
  				mentions: members,
  			},
  			{ quoted: m }
  		);
  	} catch (e) {
  		console.error(e);
  		reply('Gagal mengirim pesan hidetag.');
  	}
  
  }
};
