export default {
  command: ['poll', 'polling', 'jajak'],
  group: true,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {

    if (!text || !text.includes('|')) {
      return reply(
        `Contoh:\n${usedPrefix + command} Makan apa hari ini?|𝗡𝗮𝘀𝗶 𝗚𝗼𝗿𝗲𝗻𝗴|𝗠𝗶𝗲 𝗔𝘆𝗮𝗺|𝗕𝗮𝗸𝘀𝗼\n\n` +
        `ᴊɪᴋᴀ ɪɴɢɪɴ ᴍᴜʟᴛɪ sᴇʟᴇᴄᴛ ᴛᴀᴍʙᴀʜɪɴ ɪɴɪ ᴅɪ ᴀᴋʜɪʀ *|multi*:\n` +
        `${usedPrefix + command} Warna favorit?|Merah|Biru|Hijau|multi`
      );
    }

    let parts = text.split('|').map((v) => v.trim()).filter((v) => v);

    let selectableCount = 1;
    if (parts[parts.length - 1]?.toLowerCase() === 'multi') {
      selectableCount = 0;
      parts = parts.slice(0, -1);
    }

    const title = parts[0];
    const options = parts.slice(1);

    if (!title || options.length < 2) {
      return reply('Minimal harus ada judul dan 2 pilihan ya.\nFormat: judul|opsi1|opsi2|dst');
    }

    if (options.length > 12) {
      return reply('Maksimal 12 pilihan ya (batasan WhatsApp).');
    }

    try {
      await Shoyu.sendPoll(m.chat, {
        title,
        options,
        selectableCount
      }, { quoted: m });
    } catch (err) {
      reply('Gagal bikin polling.');
    }
  }
};
