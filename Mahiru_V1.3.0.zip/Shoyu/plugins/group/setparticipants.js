export default {
  command: ['setparticipants', 'participants', 'approvejoin', 'setujuianggota'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {

    const sub = (text || '').trim().toLowerCase();

    if (!sub) {
      return reply(
        `*Mode approval join grup*\n` +
        `Kalau di-ON-in, member baru yang mau masuk lewat link harus di-approve dulu sama admin.\n\n` +
        `${usedPrefix + command} on\n` +
        `${usedPrefix + command} off\n` +
        `${usedPrefix + command} list\n` +
        `${usedPrefix + command} approve`
      );
    }

    try {
      if (sub === 'on' || sub === 'off') {
        await Shoyu.groupJoinApprovalMode(m.chat, sub);
        return reply(`Mode approval join grup berhasil di-*${sub.toUpperCase()}*-in.`);
      }

      if (sub === 'list') {
        const pending = await Shoyu.groupRequestParticipantsList(m.chat);

        if (!pending?.length) return reply('Gak ada request join yang nunggu approval saat ini.');

        const listText = pending
          .map((p, i) => `${i + 1}. @${p.jid.split('@')[0]}`)
          .join('\n');

        return await Shoyu.sendMessage(
          m.chat,
          { text: `*Pending join request:*\n\n${listText}`, mentions: pending.map((p) => p.jid) },
          { quoted: m }
        );
      }

      if (sub === 'approve') {
        const pending = await Shoyu.groupRequestParticipantsList(m.chat);

        if (!pending?.length) return reply('Gak ada request join yang nunggu approval saat ini.');

        const targets = pending.map((p) => p.jid);
        await Shoyu.groupRequestParticipantsUpdate(m.chat, targets, 'approve');

        return await Shoyu.sendMessage(
          m.chat,
          { text: `Berhasil approve ${targets.length} member yang minta join!`, mentions: targets },
          { quoted: m }
        );
      }

      return reply(`Sub perintah tidak dikenali. Gunakan: on / off / list / approve`);
    } catch (err) {
      return reply('Gagal proses permintaan! Pastikan bot adalah admin.');
    }
  }
};