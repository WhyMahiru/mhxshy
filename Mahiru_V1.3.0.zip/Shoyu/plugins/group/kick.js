// plugins/grup/kick.js
import fs from 'fs';

export default {
  command: ['kick', 'dor'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  
  async run(m, { Shoyu, text, command, reply, usedPrefix }) {

  	let target;

  	if (m.mentionedJid?.[0]) target = m.mentionedJid[0];
  	else if (m.quoted?.sender) target = m.quoted.sender;
  	else if (text) {
  		let clean = text.replace(/[^0-9]/g, '');
  		if (clean.length < 5) return reply('Nomor tidak valid!');
  		target = clean + '@s.whatsapp.net';
  	}

  	if (!target) return reply(`Contoh: ${usedPrefix + command} tag/reply/nomor`);

  	try {
  		await Shoyu.groupParticipantsUpdate(m.chat, [target], 'remove');

  		const stickerBuffer = fs.readFileSync('./assets/sticker/kick.webp');
  		await Shoyu.sendMessage(m.chat, { sticker: stickerBuffer });

  	} catch (err) {
  		console.error(err);
  		reply('Gagal mengeluarkan anggota!');
  	}

  }
};