export default {
  command: ['setppgrup', 'setgrouppic', 'setppgc'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, usedPrefix, command, reply }) {

    const quoted = m.quoted && ['imageMessage'].includes(m.quoted.mtype) ? m.quoted : (m.mtype === 'imageMessage' ? m : null);
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || '';

    if (!quoted || !/image/i.test(mime)) {
      return reply(
        `Kirim/reply *foto* dengan caption *${usedPrefix + command}* untuk mengganti foto profil grup ini.`
      );
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const buffer = await quoted.download();
      if (!buffer || !buffer.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('Gagal ambil fotonya, coba reply/kirim ulang.');
      }

      await Shoyu.updateProfilePicture(m.chat, buffer);

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return reply('Berhasil ganti foto profil grup!');
    } catch (err) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return reply('Gagal ganti foto profil grup! Pastikan bot adalah admin dan foto yang dikirim valid (format jpg/png, tidak corrupt).');
    }
  }
};{}