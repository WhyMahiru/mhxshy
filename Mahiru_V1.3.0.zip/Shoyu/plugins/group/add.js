// plugins/grup/add.js

export default {
  command: ['add'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, command, reply, usedPrefix, fdoc }) {
  
  	let nomor = text?.replace(/[^0-9]/g, '');
  
  	if (m.mentionedJid?.[0]) nomor = m.mentionedJid[0].split('@')[0];
  	else if (m.quoted?.sender) nomor = m.quoted.sender.split('@')[0];
  
  	if (!nomor) return reply(`Contoh: ${usedPrefix}${command} 628xxxx`);
  	if (nomor.length < 8) return reply('Nomor tidak valid!');
  
  	const target = nomor + '@s.whatsapp.net';
  
  	try {
  		await Shoyu.groupParticipantsUpdate(m.chat, [target], 'add');
  		await Shoyu.sendMessage(
  			m.chat,
  			{
  				text: `Berhasil menambahkan @${nomor}`,
  				mentions: [target],
  			},
  			{ quoted: fdoc }
  		);
  	} catch (err) {
  		console.error(err);
  		reply('Gagal menambahkan. Nomor mungkin privat / tidak aktif / sudah di grup.');
  	}
  
  }
};
