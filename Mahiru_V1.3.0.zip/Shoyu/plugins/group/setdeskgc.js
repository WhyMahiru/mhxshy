export default {
  command: ['setdeskripsi', 'setdesc', 'setdeskgc', 'setdeksgc', 'setgcbio', 'setbiogc'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {

    if (!text) return reply(`Contoh: ${usedPrefix + command} Deskripsi grup kece`);

    try {
      await Shoyu.groupUpdateDescription(m.chat, text);
      return reply('Berhasil ganti deskripsi grup!');
    } catch (err) {
      return reply('Gagal ganti deskripsi grup! Pastikan bot adalah admin.');
    }
  }
};
