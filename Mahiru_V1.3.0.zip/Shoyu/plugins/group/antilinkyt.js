export default {
  command: ['antilinkyt', 'antilinkyoutube', 'antiyt'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  async run(m, { args, command, usedPrefix, updateData }) {

  	const text = args[0] ? args[0].toLowerCase() : '';

  	if (text === 'on') {
  		await updateData('groups', m.chat, 'antiyt', 1);
  		return m.reply(`[✓] Fitur *Anti YouTube* berhasil diaktifkan!`);
  	}

  	if (text === 'off') {
  		await updateData('groups', m.chat, 'antiyt', 0);
  		return m.reply(`[✓] Fitur *Anti YouTube* dimatikan.`);
  	}

  	return m.reply(`*Mode Switch Anti YouTube*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);

  }
};
