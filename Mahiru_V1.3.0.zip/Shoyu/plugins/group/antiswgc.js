export default {
  command: ['antiswgc'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { args, command, usedPrefix, updateData, reply }) {

    const text = args[0] ? args[0].toLowerCase() : '';

    if (text === 'on') {
      await updateData('groups', m.chat, 'antiswgc', 1);
      return reply(`[✓] Fitur *Anti Tag Status ke Grup* berhasil diaktifkan!\nMember yang nge-tag/nyebut grup ini di status/story bakal otomatis dihapus pesannya & di-warn.`);
    }

    if (text === 'off') {
      await updateData('groups', m.chat, 'antiswgc', 0);
      return reply(`[✓] Fitur *Anti Tag Status ke Grup* dimatikan.`);
    }

    return reply(`*Mode Switch Anti Tag Status ke Grup*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);
  }
};
