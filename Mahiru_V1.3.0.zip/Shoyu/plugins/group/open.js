export default {
  command: ['open', 'buka'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply, command }) {
    if (command === 'open' || command === 'buka') {
      await Shoyu.groupSettingUpdate(m.chat, 'not_announcement');
      return reply('*𝗚𝗥𝗢𝗨𝗣 𝗢𝗣𝗘𝗡* sᴇᴍᴜᴀ ᴍᴇᴍʙᴇʀ sᴇᴋᴀʀᴀɴɢ ʙɪsᴀ ᴋɪʀɪᴍ ᴘᴇsᴀɴ!');
    }
  }
};