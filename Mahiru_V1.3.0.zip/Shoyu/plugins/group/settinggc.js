import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { getThumbnailBuffer } from '../../src/lib/thumb.js';

// Kategori 1: Anti Link (link-link medsos/eksternal)
const LINK_TYPES = [
	{ label: 'Grup WhatsApp', cmd: 'antilinkgc', column: 'antilink' },
	{ label: 'Channel WhatsApp', cmd: 'antilinkch', column: 'antich' },
	{ label: 'Discord', cmd: 'antilinkdc', column: 'antidc' },
	{ label: 'Facebook', cmd: 'antilinkfb', column: 'antifb' },
	{ label: 'Instagram', cmd: 'antilinkig', column: 'antiig' },
	{ label: 'X (Twitter)', cmd: 'antilinkx', column: 'antix' },
	{ label: 'YouTube', cmd: 'antilinkyt', column: 'antiyt' },
	{ label: 'TikTok', cmd: 'antilinktiktok', column: 'antitiktok' },
	{ label: 'Telegram', cmd: 'antilinktele', column: 'antitele' },
	{ label: 'Semua Link (All)', cmd: 'antilinkall', column: 'antiall' },
];

const PROTECTION_TYPES = [
	{ label: 'AntiSwGc', cmd: 'antiswgc', column: 'antiswgc' },
    { label: 'AntiSticker', cmd: 'antisticker', column: 'antisticker' },
    { label: 'AntiToxic', cmd: 'antitoxic', column: 'antitoxic' },
];

const ALL_TYPES = [...LINK_TYPES, ...PROTECTION_TYPES];

const BOLD_SANS_MAP = (() => {
	const map = {};
	for (let i = 0; i < 26; i++) {
		map[String.fromCharCode(65 + i)] = String.fromCodePoint(0x1d5d4 + i); 
		map[String.fromCharCode(97 + i)] = String.fromCodePoint(0x1d5ee + i); 
	}
	for (let i = 0; i < 10; i++) {
		map[String(i)] = String.fromCodePoint(0x1d7ec + i); 
	}
	return map;
})();

const SMALLCAPS_MAP = {
	a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ',
	i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ',
	q: 'q', r: 'ʀ', s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x',
	y: 'ʏ', z: 'ᴢ',
};

const toBoldSans = (str = '') =>
	String(str)
		.split('')
		.map((ch) => BOLD_SANS_MAP[ch] || ch)
		.join('');

const toSmallCaps = (str = '') =>
	String(str)
		.split('')
		.map((ch) => SMALLCAPS_MAP[ch.toLowerCase()] || ch)
		.join('');

const buildStatusBlock = (title, types, chatDb) => {
	const rows = types
		.map((t) => `│  ${chatDb[t.column] === 1 ? 'ᴏɴ ' : 'ᴏғғ'}  ✧${toSmallCaps(t.label)}`)
		.join('\n');
	return `╭─〔 ✦${toBoldSans(title)}✦ 〕\n│\n${rows}\n╰─✦`;
};

const buildRows = (types, usedPrefix, chatDb) =>
	types.map((t) => {
		const isOn = chatDb[t.column] === 1;
		return {
			title: toBoldSans(t.label),
			description: toSmallCaps(isOn ? 'aktif - tekan untuk matikan' : 'nonaktif - tekan untuk aktifkan'),
			id: `${usedPrefix}${t.cmd} ${isOn ? 'off' : 'on'}`,
		};
	});

export default {
	command: ['gcsetting', 'settinggc', 'settinggroupchat', 'settinggrup', 'settinggroup'],
	group: true,
	limit: false,
	premium: false,
	admin: true,
	owner: false,
	botAdmin: true,
	privates: false,
	noJadiBot: false,

	async run(m, { Shoyu, usedPrefix, args, getGroup, updateData, ftroli }) {
		const sub = (args[0] || '').toLowerCase();

		let notice = '';
		if (sub === 'allon' || sub === 'alloff') {
			const value = sub === 'allon' ? 1 : 0;
			for (const t of ALL_TYPES) {
				await updateData('groups', m.chat, t.column, value);
			}
			notice = sub === 'allon'
				? `[✓] ${toSmallCaps('semua fitur protection berhasil diaktifkan!')}\n\n`
				: `[✓] ${toSmallCaps('semua fitur protection berhasil dimatikan.')}\n\n`;
		}

		const chatDb = (await getGroup(m.chat)) || {};

		const linkBlock = buildStatusBlock('LIST ANTILINK', LINK_TYPES, chatDb);
		const protectionBlock = buildStatusBlock('LIST PROTECT', PROTECTION_TYPES, chatDb);

		const teks =
`${notice}${toSmallCaps('lindungi grup kamu dari spam link & gangguan lainnya. pilih tombol di bawah untuk mengatur satu per satu, atau pakai aksi cepat buat nyalain/matiin semuanya sekaligus.')}

${linkBlock}

${protectionBlock}

_${toSmallCaps('pilih protection = atur satu per satu')}_
_${toSmallCaps('aksi cepat = atur semua sekaligus')}_`;

		const linkRows = buildRows(LINK_TYPES, usedPrefix, chatDb);
		const protectionRows = buildRows(PROTECTION_TYPES, usedPrefix, chatDb);

		const quickRows = [
			{
				title: toBoldSans('Aktifkan Semua'),
				description: toSmallCaps('nyalain semua fitur protection sekaligus'),
				id: `${usedPrefix}settinggc allon`,
			},
			{
				title: toBoldSans('Matikan Semua'),
				description: toSmallCaps('matiin semua fitur protection sekaligus'),
				id: `${usedPrefix}settinggc alloff`,
			},
		];

		const pp = await getThumbnailBuffer();
		const media = await generateWAMessageContent(
			{ image: pp },
			{ upload: Shoyu.waUploadToServer }
		);

		const msg = generateWAMessageFromContent(
			m.chat,
			{
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: toBoldSans('Protection System'),
								subtitle: toSmallCaps('sistem keamanan grup'),
								hasMediaAttachment: true,
								imageMessage: media.imageMessage,
							},
							body: { text: teks },
							footer: { text: `${global.namaBot}  •  ${toSmallCaps('protection manager')}` },
							nativeFlowMessage: {
								buttons: [
									{
										name: 'single_select',
										buttonParamsJson: JSON.stringify({
											title: toSmallCaps('pilih protection'),
											sections: [
												{ title: 'Daftar Anti Link', rows: linkRows },
												{ title: 'Daftar Protection', rows: protectionRows },
											],
											icon: 'DEFAULT',
										}),
									},
									{
										name: 'single_select',
										buttonParamsJson: JSON.stringify({
											title: toSmallCaps('aksi cepat'),
											sections: [
												{ title: 'Aksi Cepat', rows: quickRows },
											],
											icon: 'REVIEW',
										}),
									},
								],
								messageParamsJson: JSON.stringify({
									bottom_sheet: {
										in_thread_buttons_limit: 1,
										divider_indices: [1, 2],
										list_title: 'Pengaturan Protection',
										button_title: ` ❰ ${toBoldSans('PILIH PROTECTION')} ❱ `,
									},
								}),
							},
						},
					},
				},
			},
			{ userJid: Shoyu.user.id, quoted: ftroli }
		);

		await Shoyu.relayMessage(m.chat, msg.message, {
			messageId: msg.key.id,
			additionalNodes: [
				{
					tag: 'biz',
					attrs: {},
					content: [{
						tag: 'interactive',
						attrs: { type: 'native_flow', v: '1' },
						content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
					}],
				},
			],
		});
	},
};