export default {
  command: ['antilinkig', 'antiig', 'antilinkinstagram'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  async run(m, { args, command, usedPrefix, updateData }) {

  	const text = args[0] ? args[0].toLowerCase() : '';

  	if (text === 'on') {
  		await updateData('groups', m.chat, 'antiig', 1);
  		return m.reply(`[✓] Fitur *Anti Instagram* berhasil diaktifkan!`);
  	}

  	if (text === 'off') {
  		await updateData('groups', m.chat, 'antiig', 0);
  		return m.reply(`[✓] Fitur *Anti Instagram* dimatikan.`);
  	}

  	return m.reply(`*Mode Switch Anti Instagram*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);

  }
};
