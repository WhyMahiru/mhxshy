export default {
  command: ['antilinkgc', 'antigroup', 'antigc'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  async run(m, { args, command, usedPrefix, updateData }) {

  	const text = args[0] ? args[0].toLowerCase() : '';

  	if (text === 'on') {
  		await updateData('groups', m.chat, 'antilink', 1);
  		return m.reply(`[✓] Fitur *Anti Link Grup* berhasil diaktifkan!`);
  	}

  	if (text === 'off') {
  		await updateData('groups', m.chat, 'antilink', 0);
  		return m.reply(`[✓] Fitur *Anti Link Grup* dimatikan.`);
  	}

  	return m.reply(`*Mode Switch Anti Link Grup*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);

  }
};
