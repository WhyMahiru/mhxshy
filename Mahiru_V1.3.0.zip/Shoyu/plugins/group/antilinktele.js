export default {
  command: ['antilinktele', 'antitele'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  async run(m, { args, command, usedPrefix, updateData }) {

  	const text = args[0] ? args[0].toLowerCase() : '';

  	if (text === 'on') {
  		await updateData('groups', m.chat, 'antitele', 1);
  		return m.reply(`[✓] Fitur *Anti Telegram* berhasil diaktifkan!`);
  	}

  	if (text === 'off') {
  		await updateData('groups', m.chat, 'antitele', 0);
  		return m.reply(`[✓] Fitur *Anti Telegram* dimatikan.`);
  	}

  	return m.reply(`*Mode Switch Anti Telegram*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);

  }
};
