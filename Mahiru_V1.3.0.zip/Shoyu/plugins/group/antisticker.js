export default {
  command: ['antisticker'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { args, command, usedPrefix, updateData, reply }) {

    const text = args[0] ? args[0].toLowerCase() : '';

    if (text === 'on') {
      await updateData('groups', m.chat, 'antisticker', 1);
      return reply(`[✓] Fitur *Anti Sticker* berhasil diaktifkan!\nSticker yang dikirim member (bukan admin) bakal otomatis dihapus.`);
    }

    if (text === 'off') {
      await updateData('groups', m.chat, 'antisticker', 0);
      return reply(`[✓] Fitur *Anti Sticker* dimatikan.`);
    }

    return reply(`*Mode Switch Anti Sticker*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);
  }
};
