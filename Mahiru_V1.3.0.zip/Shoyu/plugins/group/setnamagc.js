export default {
  command: ['setnamagrup', 'setnamagc', 'setgcname'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {

    if (!text) return reply(`Contoh: ${usedPrefix + command} Nama Grup Baru`);

    if (text.length > 25) return reply('Nama grup maksimal 25 karakter ya (batasan WhatsApp).');

    try {
      await Shoyu.groupUpdateSubject(m.chat, text);
      return reply('Berhasil ganti nama grup!');
    } catch (err) {
      return reply('Gagal ganti nama grup! Pastikan bot adalah admin.');
    }
  }
};
