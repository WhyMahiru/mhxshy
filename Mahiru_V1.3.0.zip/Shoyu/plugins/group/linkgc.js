export default {
  command: ['linkgc', 'linkgrup', 'groupklink'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {

    try {
      const code = await Shoyu.groupInviteCode(m.chat);
      return reply(`https://chat.whatsapp.com/${code}`);
    } catch (err) {
      return reply('Gagal ambil link grup! Pastikan bot adalah admin.');
    }
  }
};
