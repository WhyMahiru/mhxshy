export default {
  command: ['tagall', 'everyone'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, reply }) {

    try {
      const themeemoji = global.themeemoji || '✦';
      const me = m.sender;

      const metadata = await Shoyu.groupMetadata(m.chat);
      const participants = metadata.participants;

      let teks = `╚»˙·٠${themeemoji}●♥ Tag All ♥●${themeemoji}٠·˙«╝\n\n`;
      teks += ` 😶 *Penanda :* @${me.split('@')[0]}\n`;
      teks += ` 🌿 *Isi pesan :* ${text ? text : 'tidak ada pesan'}\n\n`;

      for (let mem of participants) {
        teks += `${themeemoji} @${mem.id.split('@')[0]}\n`;
      }

      await Shoyu.sendMessage(
        m.chat,
        { text: teks, mentions: participants.map((a) => a.id) },
        { quoted: m }
      );
    } catch (err) {
      reply('Gagal tag semua member.');
    }
  }
};