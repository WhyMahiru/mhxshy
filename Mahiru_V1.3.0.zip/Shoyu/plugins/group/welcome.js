export default {
  command: ['welcome'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,
  
  async run(m, { text, reply, updateData, usedPrefix }) {
  
  	if (!text)
  		return reply(`Contoh pengguna:
  
  ${usedPrefix}welcome on
  ${usedPrefix}welcome off
  `);
  
  	text = text.toLowerCase();
  
  	if (text === 'on') {
  		await updateData('groups', m.chat, 'welcome', 1);
  		await updateData('groups', m.chat, 'goodbye', 1);
  
  		return reply('Welcome aktif');
  	}
  
  	if (text === 'off') {
  		await updateData('groups', m.chat, 'welcome', 0);
  		await updateData('groups', m.chat, 'goodbye', 0);
  
  		return reply('Welcome dimatikan');
  	}
  
  	reply('Gunakan on / off');
  
  }
};
