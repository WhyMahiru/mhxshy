export default {
  command: ['close', 'tutup'],
  group: true,
  limit: false,
  premium: false,
  admin: true,
  owner: false,
  botAdmin: true,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply, command }) {
    if (command === 'close' || command === 'tutup') {
      await Shoyu.groupSettingUpdate(m.chat, 'announcement');
      return reply('*𝗚𝗥𝗢𝗨𝗣 𝗖𝗟𝗢𝗦𝗘* ʜᴀɴʏᴀ ᴀᴅᴍɪɴ ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɪʀɪᴍ ᴘᴇsᴀɴ!');
    }
  }
};