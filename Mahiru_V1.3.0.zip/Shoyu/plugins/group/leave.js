export default {
  command: ['leave', 'keluargrup'],
  group: true,
  limit: false,
  premium: false,
  admin: false,
  owner: true,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {

    try {
      await reply('Oke, bot keluar dari grup ini. Bye! 👋');
      await Shoyu.groupLeave(m.chat);
    } catch (err) {
      return reply('Gagal keluar dari grup!');
    }
  }
};
