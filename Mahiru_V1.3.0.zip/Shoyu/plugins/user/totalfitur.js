export default {
  command: ['totalfitur', 'fitur'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { getPluginStats }) {

  const info = getPluginStats();

  const teks = `✦ 𝐓𝐎𝐓𝐀𝐋 𝐅𝐈𝐓𝐔𝐑 ${global.namaBot} ✦

  › ᴛᴏᴛᴀʟ ᴄᴀᴛᴇɢᴏʀʏ : ${info.totalCategory} ᴄᴀᴛᴇɢᴏʀʏ
  › ᴛᴏᴛᴀʟ ᴘʟᴜɢɪɴ : ${info.totalFiles} ғɪᴛᴜʀ
  › ᴛᴏᴛᴀʟ ᴄᴏᴍᴍᴀɴᴅ : ${info.totalCommands} ᴄᴍᴅ`;
  m.reply(teks);
}};