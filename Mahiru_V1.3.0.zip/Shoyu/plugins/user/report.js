const COOLDOWN_MS = 60 * 1000; // 1 menit antar laporan per user, biar gak dispam
const _cooldownMap = new Map();

function isOnCooldown(userId) {
  if (!_cooldownMap.has(userId)) return false;
  return Date.now() - _cooldownMap.get(userId) < COOLDOWN_MS;
}

function getRemainingCooldown(userId) {
  const last = _cooldownMap.get(userId) || 0;
  const sisaMs = COOLDOWN_MS - (Date.now() - last);
  return Math.max(1, Math.ceil(sisaMs / 1000));
}

function setCooldown(userId) {
  _cooldownMap.set(userId, Date.now());
}

function formatWaktu() {
  return new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

export default {
  command: ['repot', 'report', 'laporbug', 'bugreport', 'lapor'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴋᴇᴛɪᴋ ʟᴀᴘᴏʀᴀɴ ʙᴜɢ/ᴋᴇɴᴅᴀʟᴀ ᴋᴀᴍᴜ sᴇᴛᴇʟᴀʜ ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} fitur spotify error pas download lagu`
      );
      return;
    }

    const senderId = m.sender;

    if (isOnCooldown(senderId)) {
      reply(`Tunggu sebentar ya sebelum kirim laporan lagi (sisa ${getRemainingCooldown(senderId)} detik).`);
      return;
    }

    const ownerJids = (global.owner || []).map((v) => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');
    if (!ownerJids.length) {
      reply('Nomor owner belum diatur di *global.owner* (settings/setting.js).');
      return;
    }

    const nomor = senderId.split('@')[0];
    const pushName = m.pushName || 'Tanpa Nama';

    let asalChat = 'Private';
    if (m.isGroup) {
      try {
        const metadata = await Shoyu.groupMetadata(m.chat);
        asalChat = metadata?.subject || m.chat;
      } catch {
        asalChat = m.chat;
      }
    }

    let quotedInfo = '';
    if (m.quoted?.text) {
      const cuplikan = m.quoted.text.length > 200 ? m.quoted.text.slice(0, 200) + '...' : m.quoted.text;
      quotedInfo = `\n│⟡ Reply ke : "${cuplikan}"`;
    }

    const caption =
      `╭─✦ 𝗟𝗔𝗣𝗢𝗥𝗔𝗡 𝗕𝗨𝗚/𝗞𝗘𝗡𝗗𝗔𝗟𝗔\n` +
      `│⟡ ᴘᴇɴɢɪʀɪᴍ : *${pushName}*\n` +
      `│⟡ ɴᴏᴍᴏʀ : *${nomor}*\n` +
      `│⟡ ᴀsᴀʟ : *${asalChat}*\n` +
      `│⟡ ᴡᴀᴋᴛᴜ : *${formatWaktu()}${quotedInfo}*\n` +
      `│⟡ ᴘᴇsᴀɴ : *${text.trim()}*\n` +
      `╰──────────✦`;

    try {
      for (const jid of ownerJids) {
        await Shoyu.sendMessage(jid, { text: caption });
      }

      setCooldown(senderId);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      reply('Laporan kamu berhasil dikirim ke owner. Makasih udah bantu laporin! 🙏');
    } catch (err) {
      console.error('[REPORT] Error:', err);
      reply('Gagal ngirim laporan ke owner.\n\n' + (err?.message || JSON.stringify(err)));
      return;
    }
  },
};