function formatUptime(seconds) {
  const d = Math.floor(seconds / (24 * 3600));
  seconds %= 24 * 3600;
  const h = Math.floor(seconds / 3600);
  seconds %= 3600;
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${d}h ${h}j ${m}m ${s}d`;
}

export default {
  command: ['sc', 'script'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, getPluginStats, ftroli }) {
    const info = getPluginStats();

    await Shoyu.createAIRich()
      .addText(
        `👋 ʜᴀɪ *${m.pushName}*, ᴋᴇɴᴀʟɪɴ ɴɪʜ *${global.namaBot}* — ` +
        `sᴄʀɪᴘᴛ ᴡʜᴀᴛsᴀᴘᴘ ʙᴏᴛ ʙᴇʀʙᴀsɪs *ᴄᴀsᴇ x ᴘʟᴜɢɪɴs* ʏᴀɴɢ ʀɪɴɢᴀɴ, ᴄᴇᴘᴀᴛ, ᴅᴀɴ ɢᴀᴍᴘᴀɴɢ ᴅɪᴋᴇᴍʙᴀɴɢɪɴ.`
      )

      .addTable([
        ['sᴘᴇsɪғɪᴋᴀsɪ', 'ᴅᴇᴛᴀɪʟ'],
        ['📦 ɴᴀᴍᴀ sᴄʀɪᴘᴛ', global.namaBot],
        ['👤 ᴄʀᴇᴀᴛᴏʀ', global.namaOwner],
        ['🏷️ ᴠᴇʀsɪᴏɴ', `ᴠ${global.versi}`],
        ['🧩 ᴛᴏᴛᴀʟ ᴘʟᴜɢɪɴ', `${info.totalFiles} ғɪᴛᴜʀ / ${info.totalCategory} ᴋᴀᴛᴇɢᴏʀɪ`],
        ['🕒 ᴜᴘᴛɪᴍᴇ', formatUptime(process.uptime())],
        ['📁 ᴍᴏᴅᴜʟᴇs', 'ᴇsᴍ'],
        ['🗄️ ᴅᴀᴛᴀʙᴀsᴇ', 'sǫʟ ᴍᴏᴅᴇ'],
        ['📚 ʟɪʙʀᴀʀʏ', 'ʙᴀɪʟᴇʏs (ᴏʀɪɢɪɴᴀʟ ʙᴀɪʟs)'],
        ['💻 ʙᴀʜᴀsᴀ', 'ᴊᴀᴠᴀsᴄʀɪᴘᴛ'],
        ['🔒 sᴏᴜʀᴄᴇ', 'ᴘᴀɪᴅ / ɴᴏɴ-ғʀᴇᴇ'],
      ])

      .addTip('💡 sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ ɪɴɪ ɢᴀᴋ ᴅɪᴊᴜᴀʟ ʙᴇʙᴀs — ᴄᴜᴍᴀ ʙᴜᴀᴛ ʏᴀɴɢ ɴɪᴀᴛ sᴇʀɪᴜs ᴘᴜɴʏᴀ ʙᴏᴛ sᴇɴᴅɪʀɪ.')

      .addProduct({
        title: `sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ ${global.namaBot}`,
        brand: `${global.footer}`,
        price: 'Rp 50.000',
        sale_price: 'Rp 20.000',
        url: 'https://whatsapp.com/channel/0029VacjeqLGU3BDdC07uz34',
        image: global.thumbnail,
        icon: global.thumbnail
      })

      .addSuggest(['script', 'owner', 'donasi'])
      .send(m.chat, { quoted: ftroli });
  }
};