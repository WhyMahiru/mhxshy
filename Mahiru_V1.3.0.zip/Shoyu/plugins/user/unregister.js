import { removeRegisteredUser, deleteUserDatabase } from '../../src/lib/database.js';
import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';

export default {
	command: ['unregister', 'unreg'],
	group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	async run(m, { Shoyu, reply, isRegistered, usedPrefix, isOwner, fdoc }) {

		const text = (m.text || '').trim().toLowerCase();
		const isFromButton = m.message?.interactiveResponseMessage || 
		                     m.message?.buttonsResponseMessage ||
		                     m.contextInfo?.quotedMessage ||
		                     (m.text && (m.text.includes('unreg confirm') || m.text.includes('unreg cancel')));

		if (text === 'confirm' || (isFromButton && text.includes('confirm'))) {
			removeRegisteredUser(m.sender);
			deleteUserDatabase(m.sender);
			await reply(`✅ ᴅᴀᴛᴀʙᴀsᴇ ʙᴇʀʜᴀsɪʟ ᴅɪʜᴀᴘᴜs.\nᴅᴀᴛᴀʙᴀsᴇ ᴋᴀᴍᴜ sᴜᴅᴀʜ ʙᴇʀsɪʜ ᴅᴀʀɪ sɪsᴛᴇᴍ.\nᴍᴀᴜ ᴅᴀғᴛᴀʀ ʟᴀɢɪ? ᴋᴇᴛɪᴋ *${usedPrefix}register*`);
			return;
		}
		if (text === 'cancel' || (isFromButton && text.includes('cancel'))) {
			await reply('👌 ᴅᴀᴛᴀʙᴀsᴇ ᴛɪᴅᴀᴋ ʙᴇʀʜᴀsɪʟ ᴅɪ ʜᴀᴘᴜs sᴇᴍᴜᴀ sɪsᴛᴇᴍ ᴀᴍᴀɴ.');
			return;
		}

		if (m.contextInfo?.quotedMessage?.interactiveMessage) {
			return;
		}
		
		const media = await generateWAMessageContent({
			image: { url: 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/unreg.jpg' }
		}, {
			upload: Shoyu.waUploadToServer
		});

		const msg = generateWAMessageFromContent(m.chat, {
			viewOnceMessage: {
				message: {
					interactiveMessage: {
						header: {
							title: '⚠️ 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙐𝙉𝙍𝙀𝙂𝙄𝙎𝙏𝙀𝙍',
							subtitle: '𝙋𝙀𝙍𝙄𝙉𝙂𝘼𝙏𝘼𝙉 𝙋𝙀𝙉𝙏𝙄𝙉𝙂',
							hasMediaAttachment: true,
							imageMessage: media.imageMessage
						},
						body: {
							text: 'ᴋᴀᴍᴜ ʏᴀᴋɪɴ ᴍᴀᴜ ʜᴀᴘᴜs ᴅᴀᴛᴀʙᴀsᴇ sᴇᴘᴇɴᴜʜɴʏᴀ\n\n⚠️ *𝗘𝗙𝗘𝗞 𝗬𝗔𝗡𝗚 𝗔𝗞𝗔𝗡 𝗧𝗘𝗥𝗝𝗔𝗗𝗜:*\n• sᴇᴍᴜᴀ ᴘʀᴏɢʀᴇs ᴀᴋᴀɴ ᴛᴇʀʜᴀᴘᴜs ᴛᴏᴛᴀʟ\n• ᴅᴀᴛᴀ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴋᴇᴍʙᴀʟɪᴋᴀɴ\n• ᴘᴇʀʟᴜ ᴅᴀғᴛᴀʀ ᴜʟᴀɴɢ ᴜɴᴛᴜᴋ ᴘᴀᴋᴀɪ ʙᴏᴛ'
						},
						footer: {
							text: global.namaBot || '© Bot WhatsApp'
						},
						nativeFlowMessage: {
							buttons: [
								{
									name: "single_select",
									buttonParamsJson: JSON.stringify({
										title: "Pilih tindakan",
										sections: [
											{
												title: "Konfirmasi",
												rows: [
													{
														title: "✅ Ya, Hapus Akun Saya",
														description: "Hapus semua data dan progres",
														id: `${usedPrefix}unreg confirm`
													},
													{
														title: "❌ Tidak, Batalkan",
														description: "Kembali dan batalkan penghapusan",
														id: `${usedPrefix}unreg cancel`
													}
												]
											}
										],
										icon: "DEFAULT"
									})
								}
							],
							messageParamsJson: JSON.stringify({
								bottom_sheet: {
									in_thread_buttons_limit: 1,
									divider_indices: [0],
									list_title: 'Konfirmasi Hapus Akun',
									button_title: 'Pilih'
								}
							})
						}
					}
				}
			}
		}, {
			userJid: Shoyu.user.id,
			quoted: fdoc
		});

		await Shoyu.relayMessage(m.chat, msg.message, {
			messageId: msg.key.id,
			additionalNodes: [
				{
					tag: 'biz',
					attrs: {},
					content: [
						{
							tag: 'interactive',
							attrs: {
								type: 'native_flow',
								v: '1'
							},
							content: [
								{
									tag: 'native_flow',
									attrs: {
										v: '9',
										name: 'mixed'
									}
								}
							]
						}
					]
				}
			]
		});
	},
};