import { getUserProfile, delMoney, addUserLimit } from '../../src/lib/database.js';

const PRICE_PER_LIMIT = 250; //g ush di ubah 

export default {
	command: ['buylimit', 'belilimit'],
	group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,
	
	async run(m, { args, reply, example, usedPrefix}) {
		const jumlah = parseInt(args[0]);

		if (!jumlah || isNaN(jumlah) || jumlah <= 0) {
			return reply(
				example(`<jumlah>\nContoh: .buylimit 10`) +
				`\n\n💰 Harga: *${formatMoney(PRICE_PER_LIMIT)}* money / limit`
			);
		}

		const user = getUserProfile(m.sender);
		if (!user) return reply(`❌ Kamu belum terdaftar Ketik *${usedPrefix}daftar* dulu!`);

		const totalHarga = jumlah * PRICE_PER_LIMIT;

		if (user.money < totalHarga) {
			return reply(
				`❌ *ᴍᴏɴᴇʏ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ᴄᴜᴋᴜᴘ!*\n\n` +
				`💰 ᴍᴏɴᴇʏ ᴋᴀᴍᴜ : *${formatMoney(user.money)}*\n` +
				`💵 ᴅɪʙᴜᴛᴜʜᴋᴀɴ : *${formatMoney(totalHarga)}*\n` +
				`📉 ᴋᴜʀᴀɴɢ     : *${formatMoney(totalHarga - user.money)}*`
			);
		}

		delMoney(m.sender, totalHarga);
		addUserLimit(m.sender, jumlah);

		return reply(
			`✅ *𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗠𝗘𝗠𝗕𝗘𝗟𝗜 𝗟𝗜𝗠𝗜𝗧!*\n\n` +
			`🎯 ʟɪᴍɪᴛ ᴅɪʙᴇʟɪ : *${formatMoney(jumlah)}*\n` +
			`💵 ᴛᴏᴛᴀʟ ʙᴀʏᴀʀ : *${formatMoney(totalHarga)}*\n` +
			`💰 sɪsᴀ ᴍᴏɴᴇʏ : *${formatMoney(user.money - totalHarga)}*`
		);
	}
};