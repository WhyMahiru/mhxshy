import { renderSystemInfo } from '../../src/canvas/system-info.js';

export default {
  command: ['ping', 'systeminfo', 'os', 'bot'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, floc }) {
    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

      const { buffer, data, formatBytes, formatUptime } = await renderSystemInfo({
        skipSpeedTest: false,
      });

      const memStatus = data.mem.usedPercent < 60 ? '🟢' : data.mem.usedPercent < 85 ? '🟡' : '🔴';
      const diskStatus = data.disk
        ? (data.disk.usedPercent < 60 ? '🟢' : data.disk.usedPercent < 85 ? '🟡' : '🔴')
        : '⚪';
      const loadStatus = (data.cpu.loadavg[0] / data.cpu.cores) < 0.6
        ? '🟢'
        : (data.cpu.loadavg[0] / data.cpu.cores) < 0.85 ? '🟡' : '🔴';

      await Shoyu.sendMessage(m.chat, {
        image: buffer,
        caption:
`✦ 𝗦𝗬𝗦𝗧𝗘𝗠 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ✦

ᴘʟᴀᴛғᴏʀᴍ : ${data.platform} ${data.arch}
ᴜᴘᴛɪᴍᴇ : ${formatUptime(data.uptime)}
ᴄᴘᴜ : ${data.cpu.cores} cores ${loadStatus} (load ${data.cpu.loadavg[0].toFixed(2)})
ʀᴀᴍ : ${formatBytes(data.mem.used)} / ${formatBytes(data.mem.total)} (${data.mem.usedPercent.toFixed(1)}%) ${memStatus}
ᴅɪsᴋ : ${data.disk ? `${formatBytes(data.disk.available)} free / ${formatBytes(data.disk.total)} total (${data.disk.usedPercent.toFixed(0)}%)` : 'n/a'} ${diskStatus}
sᴘᴇᴇᴅ : ${data.speed.download ? `${data.speed.download.mbps.toFixed(1)} Mbps ↓` : 'n/a'} / ${data.speed.upload ? `${data.speed.upload.mbps.toFixed(1)} Mbps ↑` : 'n/a'}
ʜᴏsᴛ : ${data.hostname}`
      }, { quoted: floc });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
      console.error('Sysinfo canvas error:', e);
      m.reply(`❌ Error: ${e.message}`);
    }
  }
};