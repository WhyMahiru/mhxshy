import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import axios from 'axios';

const BG_URL = 'https://raw.githubusercontent.com/ryyntwx/allimagerin/refs/heads/main/wdws.png';
const FONT_URL =
  'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2';
const FONT_FAMILY = 'InterBoldMeme';

const ASSETS_DIR = join(process.cwd(), 'assets', 'chace', 'qwindows');
const FONT_PATH = join(ASSETS_DIR, 'Inter-Bold.ttf');
const BG_LOCAL = join(ASSETS_DIR, 'qwindows.png');

let _assetsReady = false;

async function ensureAssets() {
  if (_assetsReady) return;

  await mkdir(ASSETS_DIR, { recursive: true });

  if (!existsSync(FONT_PATH)) {
    const fRes = await axios.get(FONT_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    await writeFile(FONT_PATH, Buffer.from(fRes.data));
  }
  GlobalFonts.registerFromPath(FONT_PATH, FONT_FAMILY);

  if (!existsSync(BG_LOCAL)) {
    const bRes = await axios.get(BG_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    await writeFile(BG_LOCAL, Buffer.from(bRes.data));
  }

  _assetsReady = true;
}

function getWrappedLines(ctx, textStr, maxWidth) {
  const words = textStr.split(/\s+/);
  const resLines = [];
  let currentLine = '';

  for (let i = 0; i < words.length; i++) {
    if (!words[i]) continue;
    const testLine = currentLine + words[i] + ' ';
    const metrics = ctx.measureText(testLine.trim());

    if (metrics.width > maxWidth && i > 0) {
      resLines.push(currentLine.trim());
      currentLine = words[i] + ' ';
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine.trim()) resLines.push(currentLine.trim());
  return resLines;
}

async function generateWdws(rawText) {
  await ensureAssets();

  const bgImg = await loadImage(BG_LOCAL);
  const canvas = createCanvas(bgImg.width, bgImg.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

  const x = 127;
  const y = 406;
  const w = 450;
  const h = 601;
  const lHeight = 1.3;
  let fSize = 150;

  ctx.fillStyle = '#1c1d21';
  ctx.textBaseline = 'top';
  ctx.font = `700 ${fSize}px ${FONT_FAMILY}`;

  let lines = getWrappedLines(ctx, rawText, w);
  let totalTextHeight = lines.length * (fSize * lHeight);

  while (totalTextHeight > h && fSize > 24) {
    fSize -= 4;
    ctx.font = `700 ${fSize}px ${FONT_FAMILY}`;
    lines = getWrappedLines(ctx, rawText, w);
    totalTextHeight = lines.length * (fSize * lHeight);
  }

  let startY = y;
  if (totalTextHeight < h) startY = y + (h - totalTextHeight) / 2;

  const wordCount = rawText.split(/\s+/).filter((ww) => ww.length > 0).length;

  lines.forEach((line, index) => {
    const currentY = startY + index * (fSize * lHeight);
    if (currentY + fSize <= y + h) {
      if (wordCount === 1) {
        ctx.textAlign = 'center';
        ctx.fillText(line, x + w / 2, currentY);
      } else {
        ctx.textAlign = 'left';
        ctx.fillText(line, x, currentY);
      }
    }
  });

  return canvas.encode('png');
}

export default {
  command: ['qwindows', 'qw'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text || !text.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴛᴇᴋsɴʏᴀ ɴʏᴀ.\n\nᴄᴏɴᴛᴏʜ : ${usedPrefix + command} just friend kok manggil sayang dan cemburu`
      );
      return false;
    }

    const teks = text.trim();

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const pngBuffer = await generateWdws(teks);

      await Shoyu.sendMessage(
        m.chat,
        {
          image: pngBuffer,
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[WQ] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal bikin gambarnya, coba lagi ya.\n\n' + err.message);
      return false;
    }
  },
};