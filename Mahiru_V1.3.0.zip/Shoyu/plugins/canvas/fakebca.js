import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir, unlink } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import axios from 'axios';

const BG_URL = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/fakebca.png';

const FONT_CONFIGS = [
  { url: 'https://fonts.gstatic.com/s/poppins/v23/pxiByp8kv8JHgFVrLEj6Z1xlFQ.woff2', name: 'Poppins-SemiBold.ttf', family: 'PoppinsBca' },
  { url: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fAZ9hiJ-Ek-_EeA.woff2', name: 'Inter-Medium.ttf', family: 'InterMediumBca' },
  { url: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2', name: 'Inter-Bold.ttf', family: 'InterBoldBca' },
];

async function downloadIfMissing(path, url) {
  if (existsSync(path)) return;
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { 'User-Agent': 'Mozilla/5.0' },
  });
  await writeFile(path, Buffer.from(res.data));
}

async function ensureAssets() {
  const ASSETS_DIR = join(process.cwd(), 'assets', 'chace', 'fakebca');
  const FONTS_DIR = join(ASSETS_DIR, 'fonts');
  const BG_LOCAL = join(ASSETS_DIR, 'template_f1.png');
  const TMP_DIR = join(process.cwd(), 'assets', 'chace', 'tmp');

  await mkdir(FONTS_DIR, { recursive: true });
  await mkdir(TMP_DIR, { recursive: true });

  for (const f of FONT_CONFIGS) {
    const fPath = join(FONTS_DIR, f.name);
    await downloadIfMissing(fPath, f.url);
    GlobalFonts.registerFromPath(fPath, f.family);
  }

  await downloadIfMissing(BG_LOCAL, BG_URL);

  return { BG_LOCAL, TMP_DIR };
}

export default {
  command: ['fakebca', 'fbca'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `*𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!!*\n\n` +
        `ᴋᴇᴛᴇʀᴀɴɢᴀɴ:\n` +
        `ɴᴀᴍᴀ : MHD SUPRIADI\n` +
        `ɴᴏ.ʀᴇᴋ : 111 - 222 - 3333\n` +
        `sᴀʟᴅᴏ : 666,666,666\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} SUPRIADI|111 - 222 - 3333|1,000,000`
      );
      return false;
    }

    const [namaPayload, rekPayload, saldoPayload] = text.split('|');
    if (!namaPayload || !rekPayload || !saldoPayload) {
      reply(
        `*𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!*\n\n` +
        `ᴘᴀsᴛɪᴋᴀɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴘᴇᴍɪsᴀʜ ᴛᴀɴᴅᴀ ɢᴀʀɪs (|)\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} SUPRIADI|111 - 222 - 3333|1,000,000`
      );
      return false;
    }

    const txtNama = namaPayload.trim().toUpperCase();
    const txtRek = rekPayload.trim();
    const txtSaldo = saldoPayload.trim();

    const rekDigits = txtRek.replace(/\D/g, '');
    if (rekDigits.length < 10) {
      reply(
        `*𝗡𝗢 𝗥𝗘𝗞𝗘𝗡𝗜𝗡𝗚 𝗧𝗜𝗗𝗔𝗞 𝗩𝗔𝗟𝗜𝗗!*\n\n` +
        `ʀᴇᴋɪɴɢ ʜᴀʀᴜs 10 ᴅɪɢɪᴛ ᴅᴀɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ sᴘᴀsɪ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} SUPRIADI|111 - 222 - 3333|1,000,000`
      );
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const { BG_LOCAL, TMP_DIR } = await ensureAssets();

      const bgImg = await loadImage(BG_LOCAL);
      const canvas = createCanvas(bgImg.width, bgImg.height);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

      ctx.save();
      ctx.globalAlpha = 0.003;
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '700 24px InterBoldBca';
      ctx.rotate((-25 * Math.PI) / 180);
      for (let y = -200; y < 1200; y += 280) {
        for (let x = -300; x < 1200; x += 400) {
          ctx.fillText(Buffer.from('Unlubk1k', 'base64').toString(), x, y);
        }
      }
      ctx.restore();

      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '600 27px PoppinsBca';
      ctx.fillText(txtNama, 127, 56);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '500 28px InterMediumBca';
      ctx.fillText(txtRek, 211, 219);

      ctx.fillStyle = '#4F4F4F';
      ctx.font = '700 43px InterBoldBca';
      ctx.fillText(txtSaldo, 156, 361);

      const outPath = join(TMP_DIR, `fakebca-${Date.now()}.png`);
      await writeFile(outPath, await canvas.encode('png'));

      await Shoyu.sendMessage(
        m.chat,
        {
          image: { url: outPath },
        },
        { quoted: m }
      );

      if (existsSync(outPath)) await unlink(outPath);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
      console.error('[FAKEBCA] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal membuat gambar Fake BCA.\n\n' + err.message);
      return false;
    }
  },
};