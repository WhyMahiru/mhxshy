import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir, unlink } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import axios from 'axios';

const CANVAS_SIZE = { width: 1200, height: 1200 };

const FONTS = [
  { family: 'ARIAL', url: 'https://cdn.jsdelivr.net/gh/wolfsonliu/web_typography/fonts/arial.ttf', localName: 'arial.ttf' },
];

const BG_URL = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/drakememe.jpg';

async function downloadIfMissing(path, url) {
  if (existsSync(path)) return;
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { 'User-Agent': 'Mozilla/5.0' },
  });
  await writeFile(path, Buffer.from(res.data));
}

async function ensureAssets() {
  const ASSETS_DIR = join(process.cwd(), 'assets', 'chace', 'drakememe');
  const FONTS_DIR = join(ASSETS_DIR, 'fonts');
  const BG_LOCAL = join(ASSETS_DIR, 'drakememe.jpg');
  const TMP_DIR = join(process.cwd(), 'assets', 'chace', 'tmp');

  await mkdir(FONTS_DIR, { recursive: true });
  await mkdir(TMP_DIR, { recursive: true });

  for (const font of FONTS) {
    const fontLocal = join(FONTS_DIR, font.localName);
    await downloadIfMissing(fontLocal, font.url);
    GlobalFonts.registerFromPath(fontLocal, font.family);
  }

  await downloadIfMissing(BG_LOCAL, BG_URL);

  return { BG_LOCAL, TMP_DIR };
}

function drawTextInSafeZone(ctx, text, zone, initialFontSize, fontFamily, align) {
  let fontSize = initialFontSize;
  let lh = fontSize * 1.2;
  let out = [];
  const minSize = 10;

  while (fontSize >= minSize) {
    ctx.font = `400 ${fontSize}px ${fontFamily}`;
    lh = fontSize * 1.2;
    out = [];
    let fitsWidth = true;

    text.split('\n').forEach((p) => {
      let cur = '';
      p.split(' ').forEach((w) => {
        const t = cur ? cur + ' ' + w : w;
        if (ctx.measureText(t).width > zone.w && cur) {
          out.push(cur);
          cur = w;
        } else {
          cur = t;
        }
      });
      out.push(cur);
    });

    for (const line of out) {
      if (ctx.measureText(line).width > zone.w) {
        fitsWidth = false;
        break;
      }
    }

    if (fitsWidth && out.length * lh <= zone.h) break;
    fontSize -= 2;
  }

  if (fontSize < minSize) {
    fontSize = minSize;
    ctx.font = `400 ${fontSize}px ${fontFamily}`;
    lh = fontSize * 1.2;
  }

  const drawX = align === 'center' ? zone.x + zone.w / 2 : align === 'right' ? zone.x + zone.w : zone.x;

  ctx.save();
  ctx.beginPath();
  ctx.rect(zone.x, zone.y, zone.w, zone.h);
  ctx.clip();

  const startY = zone.y + zone.h / 2 - (out.length * lh) / 2 + lh / 2;
  out.forEach((l, i) => {
    ctx.fillText(l, drawX, startY + i * lh);
  });
  ctx.restore();
}

async function drawScene({ teks1, teks2 }, bgLocal) {
  const canvas = createCanvas(CANVAS_SIZE.width, CANVAS_SIZE.height);
  const ctx = canvas.getContext('2d');

  const bgImg = await loadImage(bgLocal);
  ctx.drawImage(bgImg, 0, 0, CANVAS_SIZE.width, CANVAS_SIZE.height);

  ctx.save();
  const safeZone_el1 = { x: 615, y: 22, w: 571, h: 564 };
  ctx.fillStyle = '#111111';
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  drawTextInSafeZone(ctx, teks1, safeZone_el1, 110, 'ARIAL, sans-serif', 'center');
  ctx.restore();

  ctx.save();
  const safeZone_el2 = { x: 615, y: 623, w: 571, h: 561 };
  ctx.fillStyle = '#111111';
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  drawTextInSafeZone(ctx, teks2, safeZone_el2, 110, 'ARIAL, sans-serif', 'center');
  ctx.restore();

  return canvas.encode('png');
}

export default {
  command: ['drakememe', 'memedrake', 'drake'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `*𝗗𝗥𝗔𝗞𝗘 𝗠𝗘𝗠𝗘*\n\n` +
        `ᴛʏᴘᴇ :\n` +
        `ᴛᴇᴋs ᴀᴛᴀs | ᴛᴇᴋs ʙᴀᴡᴀʜ\n\n` +
        `ᴄᴏɴᴛᴏʜ :\n${usedPrefix + command} Femboy|Tomboy`
      );
      return false;
    }

    const [teks1Raw, teks2Raw] = text.split('|');
    if (!teks1Raw || !teks2Raw) {
      reply(
        `*𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!*\n\n` +
        `ᴘᴀsᴛɪᴋᴀɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴘᴇᴍɪsᴀʜ ᴛᴀɴᴅᴀ ɢᴀʀɪs (|)\n` +
        `ᴄᴏɴᴛᴏʜ :\n${usedPrefix + command} Femboy|Tomboy`
      );
      return false;
    }

    const teks1 = teks1Raw.trim();
    const teks2 = teks2Raw.trim();

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { BG_LOCAL, TMP_DIR } = await ensureAssets();
      const pngBuffer = await drawScene({ teks1, teks2 }, BG_LOCAL);

      const outPath = join(TMP_DIR, `drakememe-${Date.now()}.png`);
      await writeFile(outPath, pngBuffer);

      await Shoyu.sendMessage(
        m.chat,
        {
          image: { url: outPath },
        },
        { quoted: m }
      );

      if (existsSync(outPath)) await unlink(outPath);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[DRAKEMEME] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal membuat gambar Drake Meme.\n\n' + err.message);
      return false;
    }
  },
};