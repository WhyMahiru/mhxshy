import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir, unlink } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import axios from 'axios';

const CANVAS_SIZE = { width: 600, height: 908 };

const FONTS = [
  { family: 'ARIAL', url: 'https://cdn.jsdelivr.net/gh/wolfsonliu/web_typography/fonts/arial.ttf', localName: 'arial.ttf' },
  { family: 'impact', url: 'https://cdn.jsdelivr.net/gh/wolfsonliu/web_typography/fonts/impact.ttf', localName: 'impact.ttf' },
];

const BG_URL = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/Two-Buttons.jpg';

async function downloadIfMissing(path, url) {
  if (existsSync(path)) return;
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { 'User-Agent': 'Mozilla/5.0' },
  });
  await writeFile(path, Buffer.from(res.data));
}

async function ensureAssets() {
  const ASSETS_DIR = join(process.cwd(), 'assets', 'chace', 'twobuttons');
  const FONTS_DIR = join(ASSETS_DIR, 'fonts');
  const BG_LOCAL = join(ASSETS_DIR, 'Two-Buttons.jpg');
  const TMP_DIR = join(process.cwd(), 'assets', 'chace', 'tmp');

  await mkdir(FONTS_DIR, { recursive: true });
  await mkdir(TMP_DIR, { recursive: true });

  for (const font of FONTS) {
    const fontLocal = join(FONTS_DIR, font.localName);
    await downloadIfMissing(fontLocal, font.url);
    GlobalFonts.registerFromPath(fontLocal, font.family);
  }

  await downloadIfMissing(BG_LOCAL, BG_URL);

  return { BG_LOCAL, TMP_DIR };
}

function drawTextInSafeZone(ctx, text, zone, initialFontSize, fontFamily, align, outlineColor, outlineWidth) {
  let fontSize = initialFontSize;
  let lh = fontSize * 1.2;
  let out = [];
  const minSize = 10;

  while (fontSize >= minSize) {
    ctx.font = `400 ${fontSize}px ${fontFamily}`;
    lh = fontSize * 1.2;
    out = [];
    let fitsWidth = true;

    text.split('\n').forEach((p) => {
      let cur = '';
      p.split(' ').forEach((w) => {
        const t = cur ? cur + ' ' + w : w;
        if (ctx.measureText(t).width > zone.w && cur) {
          out.push(cur);
          cur = w;
        } else {
          cur = t;
        }
      });
      out.push(cur);
    });

    for (const line of out) {
      if (ctx.measureText(line).width > zone.w) {
        fitsWidth = false;
        break;
      }
    }

    if (fitsWidth && out.length * lh <= zone.h) break;
    fontSize -= 2;
  }

  if (fontSize < minSize) {
    fontSize = minSize;
    ctx.font = `400 ${fontSize}px ${fontFamily}`;
    lh = fontSize * 1.2;
  }

  const drawX = align === 'center' ? zone.x + zone.w / 2 : align === 'right' ? zone.x + zone.w : zone.x;

  ctx.save();
  ctx.beginPath();
  ctx.rect(zone.x, zone.y, zone.w, zone.h);
  ctx.clip();

  const startY = zone.y + zone.h / 2 - (out.length * lh) / 2 + lh / 2;
  out.forEach((l, i) => {
    if (outlineColor) {
      ctx.strokeStyle = outlineColor;
      ctx.lineWidth = outlineWidth * (fontSize / initialFontSize);
      ctx.strokeText(l, drawX, startY + i * lh);
    }
    ctx.fillText(l, drawX, startY + i * lh);
  });
  ctx.restore();
}

async function drawScene({ teks1, teks2, teks3 }, bgLocal) {
  const canvas = createCanvas(CANVAS_SIZE.width, CANVAS_SIZE.height);
  const ctx = canvas.getContext('2d');

  const bgImg = await loadImage(bgLocal);
  ctx.drawImage(bgImg, 0, 0, CANVAS_SIZE.width, CANVAS_SIZE.height);

  ctx.save();
  ctx.translate(153, 135);
  ctx.rotate(-0.261799);
  ctx.translate(-153, -135);
  const safeZone_el1 = { x: 69, y: 108, w: 168, h: 54 };
  ctx.fillStyle = '#111111';
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  drawTextInSafeZone(ctx, teks1, safeZone_el1, 60, 'ARIAL, sans-serif', 'center');
  ctx.restore();

  ctx.save();
  ctx.translate(348, 97.5);
  ctx.rotate(-0.191986);
  ctx.translate(-348, -97.5);
  const safeZone_el2 = { x: 275, y: 76, w: 146, h: 43 };
  ctx.fillStyle = '#111111';
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  drawTextInSafeZone(ctx, teks2, safeZone_el2, 50, 'ARIAL, sans-serif', 'center');
  ctx.restore();

  ctx.save();
  const safeZone_el3 = { x: 28, y: 796, w: 542, h: 66 };
  ctx.fillStyle = '#ffffff';
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  drawTextInSafeZone(ctx, teks3, safeZone_el3, 60, 'impact, sans-serif', 'center', '#000000', 8);
  ctx.restore();

  return canvas.encode('png');
}

export default {
  command: ['twobuttons', 'tb', '2button'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `*𝗧𝗪𝗢 𝗕𝗨𝗧𝗧𝗢𝗡𝗦 𝗠𝗘𝗠𝗘*\n\n` +
        `ᴛʏᴘᴇ :\n` + 
        `ᴛᴏᴍʙᴏʟ 1 | ᴛᴏᴍʙᴏʟ 2 | ᴋᴇᴛᴇʀᴀɴɢᴀɴ ʙᴀᴡᴀʜ\n\n` +
        `ᴄᴏɴᴛᴏʜ :\n${usedPrefix + command} Tidur|Begadang|Gua tiap malem`
      );
      return false;
    }

    const [teks1Raw, teks2Raw, teks3Raw] = text.split('|');
    if (!teks1Raw || !teks2Raw || !teks3Raw) {
      reply(
        `*𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!*\n\n` +
        `ᴘᴀsᴛɪᴋᴀɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴘᴇᴍɪsᴀʜ ᴛᴀɴᴅᴀ ɢᴀʀɪs (|)\n` +
        `ᴄᴏɴᴛᴏʜ :\n${usedPrefix + command} Tidur|Begadang|Gua tiap malem`
      );
      return false;
    }

    const teks1 = teks1Raw.trim();
    const teks2 = teks2Raw.trim();
    const teks3 = teks3Raw.trim();

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { BG_LOCAL, TMP_DIR } = await ensureAssets();
      const pngBuffer = await drawScene({ teks1, teks2, teks3 }, BG_LOCAL);

      const outPath = join(TMP_DIR, `twobuttons-${Date.now()}.png`);
      await writeFile(outPath, pngBuffer);

      await Shoyu.sendMessage(
        m.chat,
        {
          image: { url: outPath },
        },
        { quoted: m }
      );

      if (existsSync(outPath)) await unlink(outPath);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[TWOBUTTONS] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal membuat gambar Two Buttons.\n\n' + err.message);
      return false;
    }
  },
};
