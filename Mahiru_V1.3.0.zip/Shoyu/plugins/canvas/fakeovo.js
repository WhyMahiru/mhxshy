import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

const IMAGE_URL = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/fakeovo.jpeg';
const WIDTH = 841;
const HEIGHT = 1870;
const FIXED_RP = Object.freeze({ text: 'Rp', x: 61, y: 368, size: 20, weight: 800 });
const AMOUNT_STYLE = { x: 94, y: 371, size: 28, weight: 800, color: '#FFFFFF' };

function isValidAmount(input) {
  return /^\d{1,3}(\.\d{3})*$/.test(input);
}

async function ensureAssets() {
  const assetsDir = join(process.cwd(), 'assets', 'chace', 'ovorp');
  await mkdir(assetsDir, { recursive: true });

  const fontPath = join(process.cwd(), 'assets', 'fonts', 'sb.ttf');
  if (!existsSync(fontPath)) throw new Error('Font sb.ttf tidak ketemu di assets/fonts/');
  GlobalFonts.registerFromPath(fontPath, 'sb');

  const bgPath = join(assetsDir, 'ovo-template.png');
  if (!existsSync(bgPath)) {
    const res = await fetch(IMAGE_URL, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    await writeFile(bgPath, Buffer.from(await res.arrayBuffer()));
  }

  return { bgPath };
}

export default {
  command: ['fakeovo', 'fovo'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const inputSaldo = text?.trim();

    if (!inputSaldo) {
      reply(
        `*𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!*\n\n` +
        `ᴄᴏɴᴛᴏʜ : ${usedPrefix + command} 20.000.000`
      );
      return false;
    }

    if (!isValidAmount(inputSaldo)) {
      reply(
        `*𝗡𝗢𝗠𝗜𝗡𝗔𝗟 𝗧𝗜𝗗𝗔𝗞 𝗩𝗔𝗟𝗜𝗗!*\n\n` +
        `ʜᴀʀᴀᴘ ɢᴜɴᴀᴋᴀɴ ᴛᴀɴᴅᴀ (.).\n` +
        `ᴄᴏɴᴛᴏʜ : ${usedPrefix + command} 20.000.000`
      );
      return false;
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { bgPath } = await ensureAssets();
      const image = await loadImage(bgPath);
      const canvas = createCanvas(WIDTH, HEIGHT);
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(image, 0, 0, WIDTH, HEIGHT);

      ctx.fillStyle = AMOUNT_STYLE.color;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';

      ctx.font = `${FIXED_RP.weight} ${FIXED_RP.size}px "sb"`;
      ctx.fillText(FIXED_RP.text, FIXED_RP.x, FIXED_RP.y);

      const amountText = inputSaldo;
      ctx.font = `${AMOUNT_STYLE.weight} ${AMOUNT_STYLE.size}px "sb"`;
      ctx.fillText(amountText, AMOUNT_STYLE.x, AMOUNT_STYLE.y);

      const buffer = await canvas.encode('png');

      await Shoyu.sendMessage(m.chat, {
        image: buffer,
      }, { quoted: m });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[OVO-RP] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal membuat fake OVO.\n\n' + err.message);
      return false;
    }
  },
};