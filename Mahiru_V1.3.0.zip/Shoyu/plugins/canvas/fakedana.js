import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync, unlinkSync } from 'node:fs';
import { join } from 'node:path';
import axios from 'axios';

function isValidAmount(input) {
  return /^\d{1,3}(\.\d{3})*$/.test(input);
}

async function ensureAssets() {
  const ASSETS_DIR = join(process.cwd(), 'assets', 'chace', 'fakedana');
  const FONTS_DIR = join(ASSETS_DIR, 'fonts');
  const FONT_PATH = join(FONTS_DIR, 'PlusJakartaSans-SemiBold.ttf');
  const BG_LOCAL = join(ASSETS_DIR, 'fkedana.png');
  const EYE_LOCAL = join(ASSETS_DIR, 'eye_icon.jpg');
  const TMP_DIR = join(process.cwd(), 'assets', 'chace', 'tmp');

  const TTF_URL = 'https://cdn.jsdelivr.net/fontsource/fonts/plus-jakarta-sans@latest/latin-600-normal.ttf';
  const BG_URL = 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/fkedana.png';
  const EYE_URL = 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/IMG-20260726-WA1031.jpg';

  await mkdir(FONTS_DIR, { recursive: true });
  await mkdir(TMP_DIR, { recursive: true });

  if (!existsSync(FONT_PATH)) {
    const fontRes = await axios.get(TTF_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    await writeFile(FONT_PATH, Buffer.from(fontRes.data));
  }
  GlobalFonts.registerFromPath(FONT_PATH, 'DANA');

  if (!existsSync(BG_LOCAL)) {
    const bgRes = await axios.get(BG_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    await writeFile(BG_LOCAL, Buffer.from(bgRes.data));
  }

  if (!existsSync(EYE_LOCAL)) {
    const eyeRes = await axios.get(EYE_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    await writeFile(EYE_LOCAL, Buffer.from(eyeRes.data));
  }

  return { BG_LOCAL, EYE_LOCAL, TMP_DIR };
}

export default {
  command: ['fakedana', 'fdana'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

 async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const inputSaldo = text?.trim();
    if (!inputSaldo) {
      reply(
        `*𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!*\n\n` +
        `ᴄᴏɴᴛᴏʜ: ${usedPrefix + command} 20.000.000`
      );
      return false;
    }

    if (!isValidAmount(inputSaldo)) {
      reply(
        `*𝗡𝗢𝗠𝗜𝗡𝗔𝗟 𝗧𝗜𝗗𝗔𝗞 𝗩𝗔𝗟𝗜𝗗!*\n\n` +
        `ʜᴀʀᴀᴘ ɢᴜɴᴀᴋᴀɴ ᴛᴀɴᴅᴀ (.)\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} 20.000.000`
      );
      return false;
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { BG_LOCAL, EYE_LOCAL, TMP_DIR } = await ensureAssets();

      const bgImg = await loadImage(BG_LOCAL);
      const eyeImg = await loadImage(EYE_LOCAL);

      const canvas = createCanvas(bgImg.width, bgImg.height);
      const ctx = canvas.getContext('2d');

      ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

      const valX = 138;
      const valY = 52;
      const maxFontSize = 37;
      const eyeGap = 7;
      const eyeScale = 1.3;
      const maxAllowedWidth = canvas.width - valX - 100;

      let currentFontSize = maxFontSize;

      ctx.font = `600 ${currentFontSize}px DANA`;
      let textWidth = ctx.measureText(inputSaldo).width;

      while (textWidth > maxAllowedWidth && currentFontSize > 16) {
        currentFontSize -= 2;
        ctx.font = `600 ${currentFontSize}px DANA`;
        textWidth = ctx.measureText(inputSaldo).width;
      }

      ctx.fillStyle = '#FFFFFF';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(inputSaldo, valX, valY);

      const eyeHeight = currentFontSize * eyeScale;
      const eyeWidth = (eyeImg.width / eyeImg.height) * eyeHeight;
      const eyeX = valX + textWidth + eyeGap;
      const eyeY = valY + (currentFontSize - eyeHeight) / 2;

      ctx.drawImage(eyeImg, eyeX, eyeY, eyeWidth, eyeHeight);

      const outPath = join(TMP_DIR, `fakedana-${Date.now()}.png`);
      await writeFile(outPath, await canvas.encode('png'));

      await Shoyu.sendMessage(
        m.chat,
        {
          image: { url: outPath },
        },
        { quoted: m }
      );

      if (existsSync(outPath)) unlinkSync(outPath);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
      console.error('[FAKEDANA] Error:', e);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal membuat canvas Fake DANA\n\n${e.message}`);
      return false;
    }
  }
};