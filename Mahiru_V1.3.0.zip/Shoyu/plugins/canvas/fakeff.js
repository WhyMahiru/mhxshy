import generateFF from 'fake-ff';
import { readFile, rm } from 'node:fs/promises';
import { join } from 'node:path';

export default {
  command: ['fakeff', 'ff'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text) {
      reply(
        `*𝗙𝗔𝗞𝗘 𝗙𝗙*\n\n` +
        `ᴋɪʀɪᴍ ᴘᴇʀɪɴᴛᴀʜ ᴅᴇɴɢᴀɴ ғᴏʀᴍᴀᴛ ʙᴇʀɪᴋᴜᴛ:\n\n` +
        `*${usedPrefix + command} ᴜsᴇʀɴᴀᴍᴇ* — ʟᴏʙʙʏ ᴀᴄᴀᴋ\n` +
        `*${usedPrefix + command} ᴜsᴇʀɴᴀᴍᴇ|5* — ʟᴏʙʙʏ 1-30`
      );
      return false;
    }

    const [username, lobbyRaw] = text.split('|').map(v => v.trim());
    const lobby = lobbyRaw ? parseInt(lobbyRaw) : undefined;

    if (lobby !== undefined && (isNaN(lobby) || lobby < 1 || lobby > 30)) {
      reply('Lobby harus angka 1–30 ya.');
      return false;
    }

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const outputDir = join(process.cwd(), 'assets', 'chace');
      const result = await generateFF({ username, ...(lobby ? { lobby } : {}), outputDir });
      const img = await readFile(result.result);

      await Shoyu.sendMessage(m.chat, {
        image: img,
      }, { quoted: m });

      await rm(result.result, { force: true });
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[FAKEFF] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal generate fake FF. Coba lagi.');
      return false;
    }
  },
};