import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir, unlink } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import axios from 'axios';

const CANVAS_SIZE = { width: 735, height: 678 };

const FONTS = [
  {
    family: 'ARIALBD',
    url: 'https://cdn.jsdelivr.net/gh/adrienverge/copr-some-nice-fonts@master/ArialBd.ttf',
    localName: 'ArialBd.ttf',
  },
];

const BG_URL = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/jarvismeme.png';

async function downloadIfMissing(path, url) {
  if (existsSync(path)) return;
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { 'User-Agent': 'Mozilla/5.0' },
  });
  await writeFile(path, Buffer.from(res.data));
}

async function ensureAssets() {
  const ASSETS_DIR = join(process.cwd(), 'assets', 'chace', 'jarvismeme');
  const BG_LOCAL = join(ASSETS_DIR, 'jarvismeme.png');
  const TMP_DIR = join(process.cwd(), 'assets', 'chace', 'tmp');

  await mkdir(ASSETS_DIR, { recursive: true });
  await mkdir(TMP_DIR, { recursive: true });

  for (const font of FONTS) {
    const fontLocal = join(ASSETS_DIR, font.localName);
    await downloadIfMissing(fontLocal, font.url);
    GlobalFonts.registerFromPath(fontLocal, font.family);
  }

  await downloadIfMissing(BG_LOCAL, BG_URL);

  return { BG_LOCAL, TMP_DIR };
}

function drawTextInSafeZone(ctx, text, zone, initialFontSize, align) {
  let fontSize = initialFontSize;
  let lines = [];
  let lh = fontSize * 1.2;

  while (fontSize > 10) {
    lh = fontSize * 1.2;
    ctx.font = `500 ${fontSize}px ARIALBD, sans-serif`;
    lines = [];
    let fits = true;

    const paragraphs = text.split('\n');
    for (const p of paragraphs) {
      let cur = '';
      const words = p.split(' ');

      for (const w of words) {
        const t = cur ? cur + ' ' + w : w;
        if (ctx.measureText(t).width > zone.w) {
          if (cur) {
            lines.push(cur);
            cur = w;
            if (ctx.measureText(w).width > zone.w) {
              fits = false;
              break;
            }
          } else {
            fits = false;
            break;
          }
        } else {
          cur = t;
        }
      }
      if (!fits) break;
      lines.push(cur);
    }

    if (fits && lines.length * lh <= zone.h) break;

    fontSize -= 2;
  }

  ctx.font = `500 ${fontSize}px ARIALBD, sans-serif`;
  ctx.fillStyle = '#111111';
  ctx.textBaseline = 'middle';
  ctx.textAlign = align;

  const drawX = align === 'center' ? zone.x + zone.w / 2 : align === 'right' ? zone.x + zone.w : zone.x;

  ctx.save();
  ctx.beginPath();
  ctx.rect(zone.x, zone.y, zone.w, zone.h);
  ctx.clip();

  const startY = zone.y + zone.h / 2 - (lines.length * lh) / 2 + lh / 2;
  lines.forEach((l, i) => ctx.fillText(l, drawX, startY + i * lh));
  ctx.restore();
}

async function drawScene({ text }, bgLocal) {
  const canvas = createCanvas(CANVAS_SIZE.width, CANVAS_SIZE.height);
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, CANVAS_SIZE.width, CANVAS_SIZE.height);

  const bgImg = await loadImage(bgLocal);
  ctx.drawImage(bgImg, 0, 0, CANVAS_SIZE.width, CANVAS_SIZE.height);

  ctx.save();
  const safeZone_el1 = { x: 20, y: 3, w: 695, h: 237 };
  drawTextInSafeZone(ctx, text, safeZone_el1, 100, 'center');
  ctx.restore();

  return canvas.encode('png');
}

export default {
  command: ['jarvismeme', 'jarvis'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `*𝗝𝗔𝗥𝗩𝗜𝗦 𝗠𝗘𝗠𝗘*\n\n` +
        `ᴛʏᴘᴇ :\n` +
        `ᴛᴇᴋs ᴏɴʟʏ\n\n` +
        `ᴄᴏɴᴛᴏʜ :\n${usedPrefix + command} Jarvis, tolong diapakan dulu apa itu biar ga apa kali`
      );
      return false;
    }

    const teks = text.trim();

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { BG_LOCAL, TMP_DIR } = await ensureAssets();
      const pngBuffer = await drawScene({ text: teks }, BG_LOCAL);

      const outPath = join(TMP_DIR, `jarvismeme-${Date.now()}.png`);
      await writeFile(outPath, pngBuffer);

      await Shoyu.sendMessage(
        m.chat,
        {
          image: { url: outPath },
        },
        { quoted: m }
      );

      if (existsSync(outPath)) await unlink(outPath);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[JARVISMEME] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal membuat gambar Jarvis Meme.\n\n' + err.message);
      return false;
    }
  },
};