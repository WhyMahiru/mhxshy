import axios from 'axios';
import FormData from 'form-data';
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

const BG_URL = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/fmeme.jpg';

const FONTS = [
  {
    family: 'MemeInterBold',
    url: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2',
    localName: 'Inter-Bold.ttf',
  },
];

async function downloadIfMissing(path, url) {
  if (existsSync(path)) return;
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { 'User-Agent': 'Mozilla/5.0' },
  });
  await writeFile(path, Buffer.from(res.data));
}

async function ensureAssets() {
  const ASSETS_DIR = join(process.cwd(), 'assets', 'chace', 'polisimeme');
  const FONTS_DIR = join(ASSETS_DIR, 'fonts');
  const BG_LOCAL = join(ASSETS_DIR, 'template_polisi.png');

  await mkdir(FONTS_DIR, { recursive: true });

  for (const font of FONTS) {
    const fontLocal = join(FONTS_DIR, font.localName);
    await downloadIfMissing(fontLocal, font.url);
    GlobalFonts.registerFromPath(fontLocal, font.family);
  }

  await downloadIfMissing(BG_LOCAL, BG_URL);

  return { BG_LOCAL };
}

async function uploadUguu(buffer) {
  const form = new FormData();
  form.append('files[]', buffer, 'image.png');

  const { data } = await axios.post('https://uguu.se/upload.php', form, {
    headers: form.getHeaders(),
  });

  return data.files[0].url;
}

async function drawScene({ txtUsername, txtMeme }, bgLocal) {
  const bgImg = await loadImage(bgLocal);
  const canvas = createCanvas(bgImg.width, bgImg.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

  const paperX = 404;
  const paperY = 324;
  const paperW = 53;
  const paperH = 120;

  let fontSize = 23;
  let lineHeight = 31;

  const senderSize = 15;
  const senderOffset = 0;

  const words = txtMeme.split(/\s+/);
  const lines = [];
  for (let i = 0; i < words.length; i += 2) {
    const pair = words.slice(i, i + 2).join(' ');
    if (pair) lines.push(pair);
  }

  const safetyMargin = senderSize + senderOffset + 10;
  const maxTextHeight = paperH - safetyMargin;

  while (fontSize > 8) {
    const totalHeight = lines.length * lineHeight;
    if (totalHeight <= maxTextHeight) break;
    fontSize -= 1;
    lineHeight -= 1.2;
  }

  const centerX = paperX + paperW / 2;

  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  ctx.fillStyle = '#262626';
  ctx.font = `bold ${senderSize}px MemeInterBold`;
  ctx.fillText(txtUsername, centerX, paperY + paperH - senderOffset);

  const totalTextHeight = lines.length * lineHeight;
  let startY = paperY + (maxTextHeight - totalTextHeight) / 2;
  if (startY < paperY) startY = paperY;

  ctx.textBaseline = 'top';
  ctx.font = `bold ${fontSize}px MemeInterBold`;

  lines.forEach((line, index) => {
    const currentY = startY + index * lineHeight;
    if (currentY + fontSize <= paperY + maxTextHeight) {
      ctx.fillText(line, centerX, currentY);
    }
  });

  return canvas.encode('png');
}

export default {
  command: ['fmeme'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `*𝗙𝗠𝗘𝗠𝗘*\n\n` +
        `ᴛʏᴘᴇ:\n` +
        `ɴᴀᴍᴀ | ᴛᴇᴋs\n\n` +
        `ᴄᴏɴᴛᴏʜ :\n${usedPrefix + command} mahiru|Katanya just friend kok manggil sayang`
      );
      return false;
    }

    const [userPayload, textPayload] = text.split('|');
    if (!userPayload || !textPayload) {
      reply(
        `*𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!*\n\n` +
        `ᴘᴀsᴛɪᴋᴀɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴘᴇᴍɪsᴀʜ ᴛᴀɴᴅᴀ ɢᴀʀɪs (|)\n` +
        `ᴄᴏɴᴛᴏʜ :\n${usedPrefix + command} mahiru|Katanya just friend kok manggil sayang`
      );
      return false;
    }

    const rawUser = userPayload.trim();
    const txtUsername = rawUser.startsWith('~') ? rawUser : `~ ${rawUser}`;
    const txtMeme = textPayload.trim();

    try {
      await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const { BG_LOCAL } = await ensureAssets();
      const pngBuffer = await drawScene({ txtUsername, txtMeme }, BG_LOCAL);
      const url = await uploadUguu(pngBuffer);

      await Shoyu.sendMessage(
        m.chat,
        {
          image: { url },
        },
        { quoted: m }
      );

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[FMEME] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal memproses gambar fmeme.\n\n' + err.message);
      return false;
    }
  },
};