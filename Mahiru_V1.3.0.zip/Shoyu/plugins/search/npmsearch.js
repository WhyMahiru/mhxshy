export default {
  command: ['npm', 'npmsearch', 'npmjs', 'npmfind'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const query = text?.trim();

    if (!query) {
      reply(
        `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
          `> \`${usedPrefix + command} <query>\`\n\n` +
          `> Contoh:\n` +
          `> \`${usedPrefix + command} axios\``
      );
      return;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '🕕', key: m.key } });

    try {
      const res = await fetch(
        `https://registry.npmjs.com/-/v1/search?text=${encodeURIComponent(query)}&size=10`
      );
      const data = await res.json();

      if (!data.objects || data.objects.length === 0) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ *ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ*\n\n> Package "${query}" tidak ditemukan`);
        return;
      }

      let out = `📦 *ɴᴘᴍ sᴇᴀʀᴄʜ*\n\n`;
      out += `> Query: \`${query}\`\n`;
      out += `> Found: ${data.total} packages\n\n`;

      data.objects.slice(0, 8).forEach((item, i) => {
        const pkg = item.package;
        const score = Math.round((item.score?.final || 0) * 100);
        out += `${i + 1}. *${pkg.name}*\n`;
        out += `> 📌 v${pkg.version}\n`;
        if (pkg.description) {
          out += `> 📝 ${pkg.description.slice(0, 50)}${pkg.description.length > 50 ? '...' : ''}\n`;
        }
        out += `> 🔗 ${pkg.links?.npm || '-'}\n`;
        if (pkg.author?.name) {
          out += `> 👤 ${pkg.author.name}\n`;
        }
        out += `> ⭐ Score: ${score}%\n\n`;
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      reply(out.trim());
    } catch (err) {
      console.error('[NPM] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '☢️', key: m.key } });
      reply('Gagal mengambil data dari NPM registry. Coba lagi ya.');
      return;
    }
  },
};
