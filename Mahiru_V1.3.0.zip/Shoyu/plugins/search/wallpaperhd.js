import { proto, prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import axios from 'axios';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function fetchWallpaperHD() {
  const url = 'https://wallpaperhd.com/discover/latest?_rsc=e56lx';

  const response = await axios.get(url, {
    headers: {
      Rsc: '1',
      'User-Agent': UA,
    },
    timeout: 20000,
  });

  const rawData = response.data;
  const regex = /"src":"(https:\/\/cdn1\.wallpaperhd\.com\/images\/walls\/[^"]+)","alt":"([^"]+)"/g;

  const wallpapers = [];
  let match;
  while ((match = regex.exec(rawData)) !== null) {
    wallpapers.push({
      url: match[1],
      title: match[2],
    });
  }

  if (!wallpapers.length) {
    throw new Error(
      'Format data WallpaperHD sepertinya berubah (payload RSC tidak cocok dengan pola regex). ' +
      'Endpoint ini bukan API resmi, jadi kemungkinan struktur halamannya berubah setelah update.'
    );
  }

  return wallpapers;
}

export default {
  command: ['wallpaperhd', 'walphd'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, reply }) {
    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const wallpapers = await fetchWallpaperHD();
      const results = wallpapers.slice(0, 10);

      const cards = [];
      for (let i = 0; i < results.length; i++) {
        const item = results[i];

        const media = await prepareWAMessageMedia(
          { image: { url: item.url } },
          { upload: Shoyu.waUploadToServer }
        );

        cards.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `🖼️ Wallpaper ${i + 1} dari ${results.length}`,
            hasMediaAttachment: true,
            ...media,
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: 'Buka gambar full',
                  url: item.url,
                }),
              },
            ],
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: `📝 ${item.title || 'Tanpa judul'}`,
          }),
        });
      }

      const msg = await generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: `🔎 𝗪𝗮𝗹𝗹𝗽𝗮𝗽𝗲𝗿 𝘁𝗲𝗿𝗯𝗮𝗿𝘂\n📦 ${results.length} gambar ditemukan • geser buat liat semua`,
                }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                  cards,
                }),
              }),
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[WALLPAPERHD] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal mengambil wallpaper.\n\n${err.message}`);
      return false;
    }
  },
};