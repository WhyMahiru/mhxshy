import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { cariresep } from '../../src/scrape/scraper.js';

const BOLD_SANS_MAP = {};
for (let i = 0; i < 26; i++) {
  BOLD_SANS_MAP[String.fromCharCode(65 + i)] = String.fromCodePoint(0x1d5d4 + i); // A-Z
  BOLD_SANS_MAP[String.fromCharCode(97 + i)] = String.fromCodePoint(0x1d5ee + i); // a-z
}
for (let i = 0; i < 10; i++) {
  BOLD_SANS_MAP[String.fromCharCode(48 + i)] = String.fromCodePoint(0x1d7ec + i); // 0-9
}
const toBoldSans = (str) => str.split('').map((c) => BOLD_SANS_MAP[c] || c).join('');

const SMALLCAPS_MAP = {
  a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
  j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
  s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ',
};
const toSmallCaps = (str) => str.toLowerCase().split('').map((c) => SMALLCAPS_MAP[c] || c).join('');

const truncate = (str, max = 37) => (str.length > max ? str.slice(0, max - 3) + '...' : str);

export default {
  command: ['cariresep', 'resep', 'searchresep'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ɴᴀᴍᴀ ᴍᴀsᴀᴋᴀɴ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} ayam goreng`
      );
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const query = text.trim();
      const result = await cariresep(query);
      const results = result?.data || [];

      if (!results.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply('Resep tidak ditemukan.');
        return false;
      }

      const rows = results.map((r) => ({
        header: toBoldSans(truncate(r.judul || 'Tanpa Judul')),
        title: toSmallCaps('resepkoki.id'),
        description: toSmallCaps('ketuk untuk lihat bahan & langkah'),
        id: `${usedPrefix}bacaresep ${r.link}`,
      }));

      const body =
        `╭─❀ ${toBoldSans('Cari Resep')}\n` +
        `│ ✦ ǫᴜᴇʀʏ : "${query}"\n` +
        `│ ✦ ᴅɪᴛᴇᴍᴜᴋᴀɴ : ${rows.length} ʀᴇsᴇᴘ\n` +
        `╰──────────✦\n\n` +
        `_ᴛᴀᴘ sᴀʟᴀʜ sᴀᴛᴜ ʀᴇsᴇᴘ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ʙᴀʜᴀɴ ᴅᴀɴ ʟᴀɴɢᴋᴀʜɴʏᴀ ✦_`;

      const cover = results[0]?.thumb;
      const media = cover
        ? await generateWAMessageContent(
            { image: { url: cover } },
            { upload: Shoyu.waUploadToServer }
          )
        : null;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: toBoldSans('Cari Resep'),
                  subtitle: `by ${global.namaBot}`,
                  hasMediaAttachment: !!media,
                  ...(media ? { imageMessage: media.imageMessage } : {}),
                },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'single_select',
                      buttonParamsJson: JSON.stringify({
                        title: toBoldSans('Pilih Resep'),
                        sections: [{ title: toSmallCaps('Hasil Pencarian'), rows }],
                        icon: 'DEFAULT',
                      }),
                    },
                  ],
                  messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                      in_thread_buttons_limit: 1,
                      list_title: toBoldSans('Pilih Resep'),
                      button_title: ' ✦ Lihat Hasil ✦ ',
                    },
                  }),
                },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[CARIRESEP] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mencari resepnya.\n\n' + err.message);
    }
  },
};