import { generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { sfileSearch } from '../../src/scrape/sfile.js';

const truncate = (str, max = 24) => (str.length > max ? str.slice(0, max - 3) + '...' : str);

export default {
  command: ['sfilesearch', 'sfilesrc', 'sfs'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴋᴀᴛᴀ ᴋᴜɴᴄɪ ғɪʟᴇ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} avengers`
      );
      return false;
    }

    const raw = text.trim();
    const pageMatch = raw.match(/\|page:(\d+)$/i);
    const page = pageMatch ? parseInt(pageMatch[1], 10) : 1;
    const query = pageMatch ? raw.slice(0, pageMatch.index).trim() : raw;

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const results = await sfileSearch(query, page);

      if (!results?.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(
          page > 1
            ? `Halaman ${page} kosong, kemungkinan udah sampai halaman terakhir.`
            : 'File tidak ditemukan.'
        );
        return false;
      }

      const rows = results.map((r) => ({
        title: truncate(r.title || '-'),
        description: `Size: ${r.size || '-'}`,
        id: `${usedPrefix}sfiledown ${r.link}`,
      }));

      const navRows = [];
      if (page > 1) {
        navRows.push({
          title: '⬅️ Halaman Sebelumnya',
          description: `Kembali ke halaman ${page - 1}`,
          id: `${usedPrefix}${command} ${query}|page:${page - 1}`,
        });
      }
      navRows.push({
        title: '➡️ Halaman Berikutnya',
        description: `Lanjut ke halaman ${page + 1}`,
        id: `${usedPrefix}${command} ${query}|page:${page + 1}`,
      });

      const sections = [{ title: 'Hasil Pencarian', rows }];
      if (navRows.length) sections.push({ title: 'Navigasi', rows: navRows });

      const body =
        `╭─✦ 𝗦𝗙𝗶𝗹𝗲 𝗦𝗲𝗮𝗿𝗰𝗵\n` +
        `│⟡ ǫᴜᴇʀʏ : ${query}\n` +
        `│⟡ ʜᴀʟᴀᴍᴀɴ : ${page}\n` +
        `│⟡ ᴛᴏᴛᴀʟ : ${rows.length} file ditemukan\n` +
        `│⟡ sᴛᴀᴛᴜs : sɪᴀᴘ ᴅɪᴜɴᴅᴜʜ\n` +
        `│⟡ ᴘɪʟɪʜ ғɪʟᴇ ᴅɪ ʙᴀᴡᴀʜ\n` +
        `╰──────────✦`;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: { hasMediaAttachment: false },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'single_select',
                      buttonParamsJson: JSON.stringify({
                        title: 'Pilih File',
                        sections,
                        icon: 'DEFAULT',
                      }),
                    },
                  ],
                  messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                      in_thread_buttons_limit: 1,
                      list_title: 'Pilih File',
                      button_title: ' ✦ Lihat Hasil ✦ ',
                    },
                  }),
                },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[SFILESEARCH] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mencari file.\n\n' + (err?.message || JSON.stringify(err)));
      return false;
    }
  },
};