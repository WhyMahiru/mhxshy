import { jadwalTv } from '../../src/scrape/scraper.js';

export default {
  command: ['jadwaltv', 'tvguide'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const channel = text?.trim();

    if (!channel) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ɴᴀᴍᴀ ᴄʜᴀɴɴᴇʟ-ɴʏᴀ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} antv\n${usedPrefix + command} rcti\n${usedPrefix + command} trans7`
      );
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const { channel: name, total, jadwal } = await jadwalTv(channel);

      const list = jadwal.map((it) => `${it.jam} — ${it.acara}`).join('\n');
      const teks =
        `📺 *JADWAL ${name}*\n` +
        `${'─'.repeat(21)}\n` +
        `${list}\n` +
        `${'─'.repeat(21)}\n` +
        `✅ Total: ${total} acara`;

      reply(teks);
      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal ambil jadwal.\n\n${err.message}`);
      return false;
    }
  },
};
