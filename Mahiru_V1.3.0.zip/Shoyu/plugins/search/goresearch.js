import { searchVideos } from '../../src/scrape/seegore.js';

export default {
  command: ['searchgore', 'goresearch', 'carigore'],
  group: false,
  limit: false,
  premium: true,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const input = text?.trim();
    if (!input) {
      return reply(`ᴍᴀsᴜᴋᴋᴀɴ ᴋᴀᴛᴀ ᴋᴜɴᴄɪ ᴘᴇɴᴄᴀʀɪᴀɴ.\n\nᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} beheading`);
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const { results } = await searchVideos(input, 1);

    if (!results?.length) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return reply(`ʜᴀsɪʟ ᴘᴇɴᴄᴀʀɪᴀɴ ᴜɴᴛᴜᴋ "${input}" ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ.`);
    }

    let msg = `*🔍 𝗛𝗔𝗦𝗜𝗟 𝗣𝗘𝗡𝗖𝗔𝗥𝗜𝗔𝗡: "${input}"*\n*📋 𝗝𝗨𝗠𝗟𝗔𝗛: ${results.length} video*\n\n`;

    results.forEach((v, i) => {
      msg += `${i + 1}. ${v.title}\n`;
      msg += `   👁 ${v.views || 0}  •  👍 ${v.upvotes || 0}\n`;
      msg += `   🔗 ${v.url}\n\n`;
    });

    msg += `_ᴋᴇᴛɪᴋ .goredownload <ʟɪɴᴋ> ᴜɴᴛᴜᴋ ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏɴʏᴀ._`;

    await reply(msg.trim());
    await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  },
};