import { proto, prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { wallpapercaveSearch, wallpapercaveCategory } from '../../src/scrape/scraper.js';

const CARD_CHUNK = 10; 

async function sendWallpaperCarousel(Shoyu, m, query, images) {
  for (let start = 0; start < images.length; start += CARD_CHUNK) {
    const chunk = images.slice(start, start + CARD_CHUNK);
    const cards = [];

    for (let i = 0; i < chunk.length; i++) {
      const imageUrl = chunk[i];
      const media = await prepareWAMessageMedia(
        { image: { url: imageUrl } },
        { upload: Shoyu.waUploadToServer }
      );

      cards.push({
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: `🖼️ Wallpaper ${start + i + 1} dari ${images.length}`,
          hasMediaAttachment: true,
          ...media,
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({ display_text: 'Buka gambar full', url: imageUrl }),
            },
          ],
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({ text: '🔗 WallpaperCave' }),
      });
    }

    const bodyText =
      start === 0
        ? `🔎 𝗛𝗮𝘀𝗶𝗹 𝘂𝗻𝘁𝘂𝗸 "${query}"\n📦 ${images.length} wallpaper ditemukan • geser buat liat semua`
        : `📦 Lanjutan (${start + 1}–${Math.min(start + CARD_CHUNK, images.length)} dari ${images.length})`;

    const msg = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({ text: bodyText }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
            }),
          },
        },
      },
      { userJid: Shoyu.user.id, quoted: start === 0 ? m : undefined }
    );

    await Shoyu.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id,
      additionalNodes: [
        {
          tag: 'biz',
          attrs: {},
          content: [
            {
              tag: 'interactive',
              attrs: { type: 'native_flow', v: '1' },
              content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
            },
          ],
        },
      ],
    });
  }
}

export default {
  command: ['wallpapercave'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴋᴀᴛᴀ ᴋᴜɴᴄɪ ᴡᴀʟʟᴘᴀᴘᴇʀ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} naruto`
      );
      return false;
    }

    const raw = text.trim();

    if (raw.startsWith('cat|')) {
      const [, encodedUrl, encodedTitle] = raw.split('|');
      const categoryUrl = decodeURIComponent(encodedUrl || '');
      const categoryTitle = decodeURIComponent(encodedTitle || '');

      if (!categoryUrl) {
        reply('Kategori gak valid, coba search ulang ya.');
        return false;
      }

      await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

      try {
        const images = await wallpapercaveCategory(categoryUrl);
        if (!images.length) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          reply(`Gagal ambil wallpaper dari kategori "${categoryTitle}".`);
          return false;
        }

        await sendWallpaperCarousel(Shoyu, m, categoryTitle, images);
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      } catch (err) {
        console.error('[WALLPAPERCAVE] Error (category):', err);
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`Gagal ambil wallpaper dari kategori "${categoryTitle}".\n\n${err.message}`);
        return false;
      }
      return;
    }

    const query = raw;

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const { type, items } = await wallpapercaveSearch(query);

      if (type === 'images') {
        if (!items.length) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          reply(`Wallpaper untuk "${query}" tidak ditemukan.`);
          return false;
        }
        await sendWallpaperCarousel(Shoyu, m, query, items);
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }

      if (!items.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`Wallpaper untuk "${query}" tidak ditemukan.`);
        return false;
      }

      const rows = items.slice(0, 15).map((cat) => ({
        title: cat.title,
        description: `${cat.count.toLocaleString('id-ID')} wallpapers`,
        id: `${usedPrefix}${command} cat|${encodeURIComponent(cat.url)}|${encodeURIComponent(cat.title)}`,
      }));

      await Shoyu.sendList(m.chat, {
        text: `ʙᴇʀɪᴋᴜᴛ ʙᴇʙᴇʀᴀᴘᴀ ᴘɪʟɪʜᴀɴ ᴄᴀᴛᴇɢᴏʀʏ ᴘɪʟɪʜ ᴅɪ ʙᴀᴡᴀʜ`,
        footer: 'WallpaperCave',
        title: `🔎 𝗞𝗮𝘁𝗲𝗴𝗼𝗿𝗶 𝘂𝗻𝘁𝘂𝗸 "${query}"`,
        buttonText: 'Pilih kategori',
        sections: [{ title: 'Kategori tersedia', rows }],
      }, { quoted: m });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[WALLPAPERCAVE] Error (search):', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal mencari wallpaper untuk "${query}".\n\n${err.message}`);
      return false;
    }
  },
};