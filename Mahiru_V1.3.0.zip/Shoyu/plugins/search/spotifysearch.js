import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { searchSpotify } from '../../src/scrape/spotifyall.js';

export default {
  command: ['spotifysearch', 'spotifysrc', 'ss'],
  group: false,
  limit: false,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,
  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
       reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴊᴜᴅᴜʟ ʟᴀɢᴜ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ ʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} imagination`);
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const results = await searchSpotify(text.trim(), 10);

      if (!results?.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
         reply('Lagu tidak ditemukan.');
        return false;
      }

      // ====== ROWS UNTUK LIST BUTTON ======
      const rows = results.map((r) => ({
        title: r.title.length > 24 ? r.title.slice(0, 21) + '...' : r.title,
        description: `${r.artists || '-'} • ${r.duration || '-'}`,
        id: `${usedPrefix}spotify ${r.link}`,
      }));

      const body =
        `╭─✦ 𝗦𝗽𝗼𝘁𝗶𝗳𝘆 𝗦𝗲𝗮𝗿𝗰𝗵\n` +
        `│⟡ ǫᴜᴇʀʏ : ${text.trim()}\n` +
        `│⟡ ᴛᴏᴛᴀʟ : ${results.length} ʟᴀɢᴜ ᴅɪᴛᴇᴍᴜᴋᴀɴ\n` +
        `│⟡ sᴛᴀᴛᴜs : sɪᴀᴘ ᴅɪᴘᴜᴛᴀʀ\n` +
        `│⟡ ᴘɪʟɪʜ ʟᴀɢᴜ ᴅɪ ʙᴀᴡᴀʜ ʏᴀʜ\n` +
        `╰──────────✦`;

      const cover = results[0]?.cover;
      const media = cover
        ? await generateWAMessageContent(
            { image: { url: cover } },
            { upload: Shoyu.waUploadToServer }
          )
        : null;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  hasMediaAttachment: !!media,
                  ...(media ? { imageMessage: media.imageMessage } : {}),
                },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'single_select',
                      buttonParamsJson: JSON.stringify({
                        title: 'Pilih Lagu',
                        sections: [{ title: 'Hasil Pencarian', rows }],
                        icon: 'DEFAULT',
                      }),
                    },
                  ],
                  messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                      in_thread_buttons_limit: 1,
                      list_title: 'Pilih Lagu',
                      button_title: ' ✦ Lihat Hasil ✦ ',
                    },
                  }),
                },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[SPOTIFYSEARCH] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
       reply('Gagal mencari lagunya.\n\n' + err.message);
    }
  },
};