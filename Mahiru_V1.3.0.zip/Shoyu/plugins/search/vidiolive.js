import { getLiveChannels } from '../../src/scrape/vidiolive.js';

const MAX_SCHEDULES_SHOWN = 5;

export default {
  command: ['vidiolive', 'livetv', 'tvlive'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `📺 *Vidio Live TV*\n\n` +
        `› ${usedPrefix + command} <channel>\n` +
        `  Contoh: ${usedPrefix + command} sctv\n\n` +
        `ʙɪsᴀ ᴄᴀʀɪ ʟᴇʙɪʜ ᴅᴀʀɪ 1 ᴄʜᴀɴɴᴇʟ sᴇᴋᴀʟɪɢᴜs, ᴘɪsᴀʜɪɴ ᴘᴀᴋᴀɪ ᴋᴏᴍᴀ:\n` +
        `› ${usedPrefix + command} sctv, indosiar, trans7`
      );
      return false;
    }

    const queries = text.split(',').map((q) => q.trim()).filter(Boolean);

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    let results;
    try {
      results = await getLiveChannels(queries);
    } catch (err) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal ambil data Vidio Live.\n\n${err.message}`);
      return false;
    }

    const blocks = results.map((r) => {
      if (r.status === 'not_found') {
        return `✖ *${r.query}*\n  Channel tidak ditemukan.`;
      }

      const d = r.data;
      const schedules = d.schedules.slice(0, MAX_SCHEDULES_SHOWN);
      const scheduleText = schedules.length
        ? schedules.map((s) => `  › ${s.start_time}-${s.end_time} ${s.title}`).join('\n')
        : '  Belum ada info jadwal.';
      const moreNote = d.total_schedules > MAX_SCHEDULES_SHOWN
        ? `\n  … +${d.total_schedules - MAX_SCHEDULES_SHOWN} jadwal lainnya`
        : '';

      return (
        `▶ *${d.channel_name}*\n` +
        `  Now Playing: ${d.now_playing}\n` +
        `  Stream: ${d.stream_url || 'tidak tersedia'}\n\n` +
        `  *Jadwal:*\n${scheduleText}${moreNote}`
      );
    });

    reply(blocks.join('\n\n'));

    const anySuccess = results.some((r) => r.status === 'success');
    await Shoyu.sendMessage(m.chat, { react: { text: anySuccess ? '✅' : '❌', key: m.key } });
  },
};