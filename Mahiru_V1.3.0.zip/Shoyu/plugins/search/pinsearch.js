import { searchPinterest } from '../../src/scrape/pinterest.js';
import { AIRich } from '../../src/lib/AIRich.js';

export default {
  command: ['pinterest', 'pinsearch', 'pin'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴋᴀᴛᴀ ᴋᴜɴᴄɪ ɢᴀᴍʙᴀʀ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} anime wallpaper`
      );
      return false;
    }

    const query = text.trim();

    const rich = new AIRich(Shoyu)
      .addText(`sᴇᴅᴀɴɢ ᴍᴇɴᴄᴀʀɪ ɢᴀᴍʙᴀʀ ᴘɪɴᴛᴇʀᴇsᴛ ᴜɴᴛᴜᴋ *${query}*`, { id: 'status1' })
      .addImage('', {
        status: 'GENERATING',
        update_text: 'Mencari...',
        insertAt: 'status1',
        id: 'img1',
      });

    await rich.send(m.chat);

    try {
      const results = await searchPinterest(query, 10);

      if (!results.length) throw new Error('Tidak ada hasil ditemukan untuk pencarian ini.');

      rich.addText(`*${query}* ᴅɪ ᴛᴇᴍᴜᴋᴀɴ sᴇᴅᴀɴɢ ᴍᴇɴɢᴜɴᴅᴜʜ ᴍᴇᴅɪᴀ`, { replace: 'status1' });
      await rich.sendEdit();

      const typeLabel = { video: 'Video', gif: 'GIF', image: 'Gambar' };

      const summary =
        `🔎 ᴅɪᴛᴇᴍᴜᴋᴀɴ ʜᴀsɪʟ ᴘᴇɴᴄᴀʀɪᴀɴ ᴜɴᴛᴜᴋ *${query}*`

      rich.addText(summary, { replace: 'status1' });

      const imageUrls = results.map((item) => item.image).filter(Boolean);
      rich.delete('img1');
      if (imageUrls.length) {
        rich.addImage(imageUrls);
      }

      const sources = results.map((item, i) => {
        let author = 'Tidak diketahui';
        if (item.fullname && item.uploader && item.fullname !== item.uploader) {
          author = `${item.fullname} (@${item.uploader})`;
        } else if (item.uploader) {
          author = `@${item.uploader}`;
        } else if (item.fullname) {
          author = item.fullname;
        }

        const tipe = typeLabel[item.type] || 'Gambar';
        const saves = Number(item.saves) || 0;

        const subtitleParts = [author, tipe];
        if (saves > 0) subtitleParts.push(`${saves.toLocaleString('id-ID')}x disimpan`);

        return {
          icon: item.image,
          url: item.source || item.image,
          title: item.title?.trim() || `Pin ${i + 1}`,
          subtitle: subtitleParts.join(' • '),
        };
      });

      rich.addSource(sources);

      await rich.sendEdit();
    } catch (err) {
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal mencari gambar Pinterest untuk "${query}".\n\n${err.message}`);
      return false;
    }
  },
};