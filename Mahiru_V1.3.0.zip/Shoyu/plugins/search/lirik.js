import { generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { lirik } from '../../src/scrape/scraper.js';

const fmtDuration = (sec) => {
  if (!sec && sec !== 0) return '-';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
};

const BOLD_SANS_MAP = {};
for (let i = 0; i < 26; i++) {
  BOLD_SANS_MAP[String.fromCharCode(65 + i)] = String.fromCodePoint(0x1d5d4 + i); // A-Z
  BOLD_SANS_MAP[String.fromCharCode(97 + i)] = String.fromCodePoint(0x1d5ee + i); // a-z
}
for (let i = 0; i < 10; i++) {
  BOLD_SANS_MAP[String.fromCharCode(48 + i)] = String.fromCodePoint(0x1d7ec + i); // 0-9
}
const toBoldSans = (str) => str.split('').map((c) => BOLD_SANS_MAP[c] || c).join('');

const SMALLCAPS_MAP = {
  a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
  j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
  s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ',
};
const toSmallCaps = (str) => str.toLowerCase().split('').map((c) => SMALLCAPS_MAP[c] || c).join('');

export default {
  command: ['lirik', 'lyrics'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴊᴜᴅᴜʟ ʟᴀɢᴜ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ ʟɪʀɪᴋɴʏᴀ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} rewrite the stars`
      );
      return false;
    }

    const raw = text.trim();
    const hashIndex = raw.lastIndexOf('#');
    const hasIndex = hashIndex !== -1 && /^\d+$/.test(raw.slice(hashIndex + 1));
    const query = hasIndex ? raw.slice(0, hashIndex) : raw;
    const pickIndex = hasIndex ? parseInt(raw.slice(hashIndex + 1), 10) : null;

    await Shoyu.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
      const results = await lirik(query);

      if (!Array.isArray(results) || !results.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`Lirik untuk "${query}" tidak ditemukan.`);
        return false;
      }

      if (pickIndex !== null) {
        const track = results[pickIndex];

        if (!track) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          reply(`Lagu nomor ${pickIndex} gak ketemu di hasil pencarian ini.`);
          return false;
        }

        if (track.instrumental || (!track.plainLyrics && !track.syncedLyrics)) {
          await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
          reply(
            `╭─✦ 𝗟𝗶𝗿𝗶𝗸 : ${track.trackName}\n` +
            `│⟡ Artis : ${track.artistName || '-'}\n` +
            `╰──────────✦\n\n` +
            `Lagu ini gak punya lirik (kemungkinan instrumental).`
          );
          return false;
        }

        const lyricsText = track.plainLyrics || track.syncedLyrics;

        const teks =
          `╭─✦ 𝗟𝗶𝗿𝗶𝗸: ${track.trackName}\n` +
          `│⟡ Artis : ${track.artistName || '-'}\n` +
          `│⟡ Album : ${track.albumName || '-'}\n` +
          `│⟡ Durasi : ${fmtDuration(track.duration)}\n` +
          `╰──────────✦\n\n` +
          `${lyricsText.trim()}`;

        reply(teks);
        await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return;
      }


      const rows = results.map((r, i) => {
        const artist = r.artistName || 'Unknown Artist';
        const title = r.trackName || 'Tanpa Judul';
        const info = r.instrumental
          ? 'Instrumental • Tanpa lirik'
          : `${fmtDuration(r.duration)}${r.albumName ? ' • ' + r.albumName : ''}`;

        const headerText = title.length > 37 ? title.slice(0, 34) + '...' : title;
        const titleText = artist.length > 37 ? artist.slice(0, 34) + '...' : artist;
        const descText = info.length > 37 ? info.slice(0, 34) + '...' : info;

        return {
          header: toBoldSans(headerText),
          title: toSmallCaps(titleText),
          description: toSmallCaps(descText),
          id: `${usedPrefix}lirik ${query}#${i}`,
        };
      });

      const body =
        `╭─❀ ${toBoldSans('Cari Lirik')}\n` +
        `│ ✦ ǫᴜᴇʀʏ : "${query}"\n` +
        `│ ✦ ᴅɪᴛᴇᴍᴜᴋᴀɴ : ${rows.length} ʟᴀɢᴜ\n` +
        `╰──────────✦\n\n` +
        `_ᴛᴀᴘ sᴀʟᴀʜ sᴀᴛᴜ ʟᴀɢᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ʟɪʀɪᴋɴʏᴀ ✦_`;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: toBoldSans('Cari Lirik'),
                  subtitle: `by ${global.namaBot}`,
                  hasMediaAttachment: false,
                },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'single_select',
                      buttonParamsJson: JSON.stringify({
                        title: toBoldSans('Pilih Lagu'),
                        sections: [{ title: toSmallCaps('Hasil Pencarian'), rows }],
                        icon: 'DEFAULT',
                      }),
                    },
                  ],
                  messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                      in_thread_buttons_limit: 1,
                      list_title: toBoldSans('Pilih Lagu'),
                      button_title: ' ✦ Lihat Hasil ✦ ',
                    },
                  }),
                },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[LIRIK] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply('Gagal mencari liriknya.\n\n' + err.message);
      return false;
    }
  },
};