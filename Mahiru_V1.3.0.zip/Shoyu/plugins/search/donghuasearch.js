import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys';
import { searchDongworld } from '../../src/scrape/dongworld.js';

const truncate = (str, max = 37) => (str.length > max ? str.slice(0, max - 3) + '...' : str);

export default {
  command: ['donghua', 'searchdonghua', 'donghuasearch'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    const query = text?.trim();

    if (!query) {
      reply(
        `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
          `> \`${usedPrefix + command} <judul donghua>\`\n\n` +
          `> Contoh:\n` +
          `> \`${usedPrefix + command} swallowed star\``
      );
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '🕕', key: m.key } });

    try {
      const result = await searchDongworld(query);
      const items = result?.items || [];

      if (!items.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ Donghua dengan kata kunci "${query}" tidak ditemukan.`);
        return false;
      }

      const rows = items.slice(0, 20).map((item) => ({
        header: truncate(item.title || 'Tanpa Judul'),
        title: 'Dongworld',
        description: 'Ketuk untuk lihat detail & episode',
        id: `${usedPrefix}donghuainfo ${item.slug}`,
      }));

      const body = `🎬 *Cari Donghua*\n\n✦ Query: "${query}"\n✦ Ditemukan: ${items.length} judul`;

      const cover = items[0]?.thumbnail;
      const media = cover
        ? await generateWAMessageContent({ image: { url: cover } }, { upload: Shoyu.waUploadToServer })
        : null;

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: 'Donghua',
                  subtitle: `by ${global.namaBot}`,
                  hasMediaAttachment: !!media,
                  ...(media ? { imageMessage: media.imageMessage } : {}),
                },
                body: { text: body },
                footer: { text: global.namaBot || 'Mahiru' },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'single_select',
                      buttonParamsJson: JSON.stringify({
                        title: 'Pilih Donghua',
                        sections: [{ title: 'Hasil', rows }],
                        icon: 'DEFAULT',
                      }),
                    },
                  ],
                  messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                      in_thread_buttons_limit: 1,
                      list_title: 'Pilih Donghua',
                      button_title: ' ✦ Lihat Hasil ✦ ',
                    },
                  }),
                },
              },
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[DONGHUA] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`❌ ${err.message || 'Gagal mengambil data donghua.'}`);
      return false;
    }
  },
};