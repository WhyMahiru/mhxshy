import { proto, prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { scrapePixiv } from '../../src/scrape/pixiv.js';

// Thumbnail Pixiv di-hotlink-protect, jadi wajib pakai header Referer pixiv
// dan diambil sebagai buffer dulu (link mentahnya gabisa langsung diakses WA).
async function fetchPixivThumbBuffer(url) {
  const res = await fetch(url, {
    headers: {
      Referer: 'https://www.pixiv.net/',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    },
  });
  if (!res.ok) throw new Error(`Gagal fetch thumbnail (${res.status})`);
  return Buffer.from(await res.arrayBuffer());
}

export default {
  command: ['pixiv', 'pixivsearch'],
  group: false,
  limit: true,
  premium: false,
  admin: false,
  owner: false,
  botAdmin: false,
  privates: false,
  noJadiBot: false,

  async run(m, { Shoyu, text, usedPrefix, command, reply }) {
    if (!text?.trim()) {
      reply(
        `ᴍᴀsᴜᴋᴋᴀɴ ᴋᴀᴛᴀ ᴋᴜɴᴄɪ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴄᴀʀɪ.\n\n` +
        `ᴄᴏɴᴛᴏʜ:\n${usedPrefix + command} hatsune miku\n${usedPrefix + command} genshin impact|2 (halaman 2)`
      );
      return false;
    }

    const raw = text.trim();
    let query = raw;
    let page = 1;

    // dukung format "query|page" buat pindah halaman
    const pipeIdx = raw.lastIndexOf('|');
    if (pipeIdx !== -1) {
      const maybePage = parseInt(raw.slice(pipeIdx + 1).trim(), 10);
      if (Number.isFinite(maybePage) && maybePage > 0) {
        query = raw.slice(0, pipeIdx).trim();
        page = maybePage;
      }
    }

    if (!query) {
      reply('Kata kuncinya kosong, coba masukin lagi ya.');
      return false;
    }

    await Shoyu.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const { results, total } = await scrapePixiv(query, page);

      const cards = [];
      for (let i = 0; i < results.length; i++) {
        const item = results[i];

        let media;
        try {
          const buf = await fetchPixivThumbBuffer(item.thumbnail);
          media = await prepareWAMessageMedia(
            { image: buf },
            { upload: Shoyu.waUploadToServer }
          );
        } catch {
          continue;
        }

        const badge = item.isAi ? '🤖' : '🎨';
        const judul = item.title?.trim() || 'Tanpa judul';
        const tagsLine = item.tags?.length ? `🏷️ ${item.tags.slice(0, 5).join(', ')}` : null;

        const footerLines = [
          `👤 Author: ${item.author || 'Tidak diketahui'}`,
          item.pageCount > 1 ? `🖼️ ${item.pageCount} halaman` : null,
          item.isAi ? '🤖 AI-generated' : null,
          tagsLine,
        ].filter(Boolean);

        cards.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `${badge} ${judul}`,
            hasMediaAttachment: true,
            ...media,
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: 'Buka di Pixiv',
                  url: item.url,
                }),
              },
            ],
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: footerLines.join('\n'),
          }),
        });
      }

      if (!cards.length) {
        await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`Gagal ambil thumbnail buat hasil pencarian "${query}".`);
        return false;
      }

      const msg = await generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: `🔎 𝗛𝗮𝘀𝗶𝗹 𝗽𝗲𝗻𝗰𝗮𝗿𝗶𝗮𝗻 𝘂𝗻𝘁𝘂𝗸 "${query}" (halaman ${page})\n📦 ${cards.length} dari ${total} artwork • geser buat liat semua\n💡 ᴋᴇᴛɪᴋ */${command} ${query}|${page + 1}* ʙᴜᴀᴛ ʜᴀʟᴀᴍᴀɴ ʙᴇʀɪᴋᴜᴛɴʏᴀ`,
                }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                  cards,
                }),
              }),
            },
          },
        },
        { userJid: Shoyu.user.id, quoted: m }
      );

      await Shoyu.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id,
        additionalNodes: [
          {
            tag: 'biz',
            attrs: {},
            content: [
              {
                tag: 'interactive',
                attrs: { type: 'native_flow', v: '1' },
                content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              },
            ],
          },
        ],
      });

      await Shoyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
      console.error('[PIXIV] Error:', err);
      await Shoyu.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      reply(`Gagal mencari artwork Pixiv untuk "${query}".\n\n${err.message}`);
      return false;
    }
  },
};
