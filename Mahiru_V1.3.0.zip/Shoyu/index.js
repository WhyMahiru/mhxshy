/*
   * WhatsApp bot base using baileys (@wishkeysocket/baileys)
   * Type plugins | Modules ESM
   * Buy Script? t.me/ShoyuuAvailable90 

*⚠️ Baca file README.md di situ semua sudah lengkap 
   
   ** Copyright © Shoyu 2026 **
*/
process.on('uncaughtException', (err) => {
	console.error('Caught exception:', err);
});

import './src/lib/tmpdir.js';
import './settings/setting.js';
import './settings/mess.js';
import './src/lib/function.js';
import { makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, DisconnectReason, downloadContentFromMessage, jidDecode, Browsers, delay, generateWAMessageFromContent, prepareWAMessageMedia } from '@whiskeysockets/baileys';
import { makeInMemoryStore } from './src/lib/store.js';

import fs from 'fs';
import chalk from 'chalk';
import { fileURLToPath, pathToFileURL } from 'url';
import pino from 'pino';
import { Boom } from '@hapi/boom';
import path from 'path';
import readline from 'readline';
import qrcode from 'qrcode-terminal';
import { fileTypeFromBuffer } from 'file-type';
import NodeCache from 'node-cache';
import os from 'os';
import nou from 'node-os-utils';
import speed from 'performance-now';

const timestamp = speed();
const latensi = speed() - timestamp;
const tio = nou.os.oos();
const tot = await nou.drive.info();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import { handler_cmd } from './src/handler.js';
import { loadPlugins, startWatcher } from './src/plugins.js';
import { resumeJadiBots } from './src/lib/jadibot.js';
import { imageToWebp, videoToWebp, writeExifImg, writeExifVid } from './src/lib/webp.js';
import ConfigBaileys from './src/lib/config.js';
import { initDb, getSettings, scheduleLimitReset, startPremiumSweep } from './src/lib/database.js';
import welcome from './src/lib/welcome.js';
import makeHelper from './src/lib/helper-bails.js'
import axios from 'axios';


async function InputNumber(promptText) {
	const rl = readline.createInterface({
		input: process.stdin,
		output: process.stdout,
	});
	return new Promise((resolve) => {
		rl.question(promptText, (answer) => {
			rl.close();
			resolve(answer);
		});
	});
}

async function verifyKey() {
	try {
		const security = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1doeU1haGlydS9taHhzaHkvcmVmcy9oZWFkcy9tYWluL1NlY3VyaXR5';
		const rawUrl = Buffer.from(security, 'base64').toString('utf8');
		const { data: securityData } = await axios.get(rawUrl, { timeout: 15000 });

		console.log(chalk.magenta.bold('Masukan Key Security Untuk Melanjutkan Proses Berikutnya'));
		const inputKey = await InputNumber(chalk.cyan.bold('› Key: '));

		const isKeyValid = securityData && securityData.key === inputKey.trim();

		if (!isKeyValid) {
			console.log(chalk.red.bold('Key Security Salah Goblok Makanya Jangan Maling Script Orang'));
			process.exit(1);
		}

		console.log(chalk.green.bold('Key Security Benar, Melanjutkan Proses Berikutnya...'));
		await delay(2000);

		const nomorbot = (global.nomorbot || '').replace(/[^0-9]/g, '');
		const numberList = Array.isArray(securityData?.numbers) ? securityData.numbers : [];
		const isNumberValid = numberList.includes(nomorbot);

		if (!isNumberValid) {
			console.log(chalk.red.bold(`Nomor ${nomorbot} Ini Belum Terdaftar Di Database Minta Developer Untuk Nambahin`));
			process.exit(1);
		}

		console.log(chalk.green.bold(`Nomor ${nomorbot} Terdeteksi Di Database, Melanjutkan Proses Berikutnya`));
		await delay(2000);

		console.log(chalk.green.bold('DATABSE DI TEMUKAN SILAHKAN MASUKAN PAIRING CODE'));
	} catch (error) {
		console.log(chalk.red.bold('Waduh, gagal ngecek key-nya:'), error.message);
		process.exit(1);
	}
}

const { state: _authState, saveCreds: _saveCreds } = await useMultiFileAuthState('session');

if (!_authState.creds.registered) {
	await verifyKey();
}

const store = makeInMemoryStore();

const groupCache = new NodeCache({
	stdTTL: 5 * 60,
	useClones: false,
});

await initDb();
startPremiumSweep(5 * 60 * 1000);

const botSet = await getSettings();
global.public = botSet.public === 1;
global.prefix = botSet.prefix;
global.multiprefix = botSet.multiprefix === 1;
if (botSet.autotyping !== undefined) global.autotyping = botSet.autotyping === 1;
if (botSet.autoread !== undefined) global.autoread = botSet.autoread === 1;
if (botSet.autoviewstatus !== undefined) global.autoviewstatus = botSet.autoviewstatus === 1;
if (botSet.anticall !== undefined) global.anticall = botSet.anticall === 1;
global.gconly = botSet.gconly === 1;
global.pconly = botSet.pconly === 1;
global.db = { users: {}, groups: {}, settings: {} };

const pairingCode = true;
async function startBot() {
	const { state, saveCreds } = await useMultiFileAuthState('session');
	const { version: v } = await fetchLatestBaileysVersion();
	
	const Shoyu = makeWASocket({
		printQRInTerminal: !pairingCode,
		auth: state,
		version: v,
		browser: Browsers.ubuntu('Chrome'),
		syncFullHistory: false,

		cachedGroupMetadata: async (jid) => {
			return groupCache.get(jid);
		},

		getMessage: async (key) => {
			if (store) {
				const msg = store.loadMessage(key.remoteJid, key.id);
				return msg?.message || undefined;
			}
			return undefined;
		},

		logger: pino({ level: 'silent' }),
	});

    makeHelper(Shoyu)
    
    
	store.bind(Shoyu.ev)
	global.store = store
	
	console.clear();
    
	if (pairingCode && !Shoyu.authState.creds.registered) {
    let phoneNumber = (global.nomorbot || '').replace(/[^0-9]/g, '');
    setTimeout(async () => {
        const code = await Shoyu.requestPairingCode(phoneNumber, global.codePair);
        const pair = code.slice(0, 4) + '-' + code.slice(4, 8);
        console.clear();
        await console.log(`${chalk.white.bold('[✓] - Your code')} : ${chalk.green.bold(pair)}`);
    }, 5000);
}

	Shoyu.ev.on('creds.update', saveCreds);
	
	Shoyu.ev.on('groups.update', async ([event]) => {
		try {
			const metadata = await Shoyu.groupMetadata(event.id);
			groupCache.set(event.id, metadata);
		} catch {}
	});

	Shoyu.ev.on('group-participants.update', async (event) => {
		try {
			const metadata = await Shoyu.groupMetadata(event.id);
			groupCache.set(event.id, metadata);
			await welcome(Shoyu, event);
		} catch {}
	});

	Shoyu.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
		if (!connection) return;
		if (connection === 'connecting') {
			if (qr && !pairingCode) {
				console.log('Scan QR ini di WhatsApp:');
				qrcode.generate(qr, { small: true });
			}
		}
		if (connection === 'close') {
			const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
			console.error(lastDisconnect.error);

			switch (reason) {
				case DisconnectReason.badSession:
					console.log('Bad Session File, Please Delete Session and Scan Again');
					process.exit();
				case DisconnectReason.connectionClosed:
					console.log('[SYSTEM] Connection closed, reconnecting...');
					await startBot();
					break;
				case DisconnectReason.connectionLost:
					console.log('[SYSTEM] Connection lost, trying to reconnect...');
					await startBot();
					break;
				case DisconnectReason.connectionReplaced:
					console.log('Connection Replaced, Another New Session Opened. Please Close Current Session First.');
					await Shoyu.logout();
					break;
				case DisconnectReason.restartRequired:
					console.log('Restart Required...');
					await startBot();
					break;
				case DisconnectReason.loggedOut:
					console.log('Device Logged Out, Please Scan Again And Run.');
					await Shoyu.logout();
					break;
				case DisconnectReason.timedOut:
					console.log('Connection TimedOut, Reconnecting...');
					await startBot();
					break;

				default:
					const errorMsg = lastDisconnect.error?.message;

					if (errorMsg === 'Error: Stream Errored (unknown)' || errorMsg === 'Stream Errored (unknown)') {
						console.log('[SYSTEM] Stream Errored (unknown) detected. Reconnecting...');
						await startBot();
					} else {
						console.error(`[SYSTEM] Disconnect Reason (Unhandled): ${reason} - ${lastDisconnect.error}`);
						await startBot();
					}
			}
		} else if (connection === 'open') {
    console.clear();
    Shoyu.insertAllGroup();
    global.mainSock = Shoyu;
    try {
    await Shoyu.groupAcceptInvite('HF01YTiG3ujFECJNo4lvl1');
} catch (e) {}

    console.log(chalk.bgRed.white('  Memuat database . . .'));
    delay(2000);
    console.log(chalk.bgBlue.white(`  Succes database berhasil dimuat\n`));
    console.log(chalk.bgRed.white('  Memuat plugins . . .'));
    const loaded = await loadPlugins();
    console.log(chalk.bgBlue.white(`  ${loaded.length} file plugin berhasil dimuat`));
    delay(1000);

    console.log(chalk.green.bold(`\n[✓] - This script has been connected to your WhatsApp!\n`));

    const botNumber = Shoyu?.user?.id?.split(':')[0] || Shoyu?.user?.jid?.replace('@s.whatsapp.net', '') || 'Unknown';
    const botName = Shoyu?.user?.name || 'Unknown';

    console.log(
        chalk.white(`\n┌───────────────────────`) +
        chalk.white(`\n├──[ `) +
        chalk.magenta.bold(`INFO PENGGUNA 👤`) +
        chalk.white(` ]──`) +
        chalk.white.bold(`
│ [+] - Number : ${botNumber}
│ [+] - Name   : ${botName}`)
    );

    console.log(
        chalk.white(`\n├───────────────────────`) +
        chalk.white(`\n├──[ `) +
        chalk.magenta.bold(`INFO SCRIPT 🤖`) +
        chalk.white(` ]──`) +
        chalk.white.bold(`
│ [+] - Name       : ${global.namaBot}
│ [+] - Developer  : ${global.namaOwner}
│ [+] - Type       : Plugins (ESM)
│ [+] - Mode       : ${global.public ? 'Public mode' : 'Self mode'}
│ [+] - Prefix     : ${global.multiprefix ? `${global.prefix || '.'}` : 'Multi prefix'}`)
    );

    console.log(
        chalk.white(`\n├───────────────────────`) +
        chalk.white(`\n├──[ `) +
        chalk.magenta.bold(`SERVER INFO 🌐`) +
        chalk.white(` ]──`) +
        chalk.white.bold(`
│ [+] - Runtime VPS   : ${runtime(os.uptime())}
│ [+] - Platform      : ${nou.os.type()}
│ [+] - Total RAM     : ${formatp(os.totalmem())}
│ [+] - Total DISK    : ${tot.totalGb} GB
│ [+] - Total CPU     : ${os.cpus().length} Core`)
    );

    console.log(chalk.white(`\n└───────────────────────\n`));
    startWatcher();
    scheduleLimitReset();
    resumeJadiBots();
    console.log(chalk.bgHex('#6A0DAD').black(`\nHarap gunakan bot dengan bijak yah kids\n`));
}
	});
	
	Shoyu.ev.on('messages.upsert', async (chatUpdate) => {
		try {
			const msg = chatUpdate.messages?.[0];
			if (!msg) return;

			if (msg.messageStubType != null) {
				await Shoyu.sendMessage(msg.key.remoteJid, { react: { text: "🥶", key: msg.key } }).catch(() => {});
			}

			if (chatUpdate.type !== 'notify') return;
			if (!msg.message) return;
			if (msg.key.fromMe && !global.bot) return;

			const isStatus = msg.key.remoteJid === 'status@broadcast';

			if (global.autoread && !msg.key.fromMe && !isStatus) {
				Shoyu.readMessages([msg.key]).catch(() => {});
			}
			if (global.autotyping && !msg.key.fromMe && !isStatus) {
				Shoyu.sendPresenceUpdate('composing', msg.key.remoteJid).catch(() => {});
			}
			if (global.autoviewstatus && isStatus && !msg.key.fromMe) {
				Shoyu.readMessages([msg.key]).catch(() => {});
			}

			const m = await ConfigBaileys(Shoyu, msg);
			await handler_cmd(Shoyu, m, chatUpdate);
		} catch (err) {
			console.error('Error on message:', err);
		}
	});

	Shoyu.ev.on('call', async (calls) => {
		if (!global.anticall) return;
		for (const call of calls) {
			try {
				if (call.status !== 'offer') continue;

				const callerJid = call.from;
				const jenis = call.isVideo ? 'panggilan video' : 'panggilan suara';

				await Shoyu.rejectCall(call.id, callerJid).catch(() => {});

				const ownerNumber = (global.owner?.[0] || '').replace(/[^0-9]/g, '');
				const teks =
					`🚫 *𝗦𝗬𝗦𝗧𝗘𝗠 𝗗𝗘𝗧𝗘𝗖𝗧*\n\n` +
					`Kamu telah *diblokir otomatis* oleh sistem karena melakukan *${jenis}* ke bot ini.\n\n` +
					`Fitur telepon/panggilan ke bot dinonaktifkan demi menjaga kestabilan sistem.\n\n` +
					`Jika ini tidak disengaja atau ingin membuka blokir, silakan hubungi owner di:\n` +
					`wa.me/${ownerNumber}`;

				await Shoyu.sendMessage(callerJid, { text: teks }).catch(() => {});

				await Shoyu.updateBlockStatus(callerJid, 'block').catch(() => {});
			} catch (e) {
				console.error('[ANTICALL] Error:', e);
			}
		}
	});

	Shoyu.decodeJid = (jid) => {
		if (!jid) return jid;
		if (/:\d+@/gi.test(jid)) {
			let decode = jidDecode(jid) || {};
			return (decode.user && decode.server && decode.user + '@' + decode.server) || jid;
		} else return jid;
	};

	Shoyu.insertAllGroup = async () => {
		const groups = (await Shoyu.groupFetchAllParticipating().catch(() => null)) || {};
		for (const jid in groups) {
			groupCache.set(jid, groups[jid]);
		}
	};

	Shoyu.getJid = (jid) => {
	if (!jid?.endsWith('@lid')) return jid;

	for (const key of groupCache.keys()) {
		const group = groupCache.get(key);

		const user = group?.participants?.find(
			(p) => p.lid === jid || p.id === jid
		);

		if (user) {
			return user.phoneNumber || user.jid || user.id;
		}
	}

	return jid;
};

	Shoyu.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
		try {
			const quoted = message.msg ? message.msg : message;
			const mime = (message.msg || message).mimetype || '';
			const messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];

			const Randoms = Date.now();
			const fil = Randoms;

			if (!fs.existsSync('./data/trash')) {
				fs.mkdirSync('./data/trash', { recursive: true });
			}

			const stream = await downloadContentFromMessage(quoted, messageType);
			let buffer = Buffer.from([]);

			for await (const chunk of stream) {
				buffer = Buffer.concat([buffer, chunk]);
			}

			const type = (await fileTypeFromBuffer(buffer)) || { ext: 'bin', mime: 'application/octet-stream' };
			const trueFileName = attachExtension ? `./data/trash/${fil}.${type.ext}` : filename || `./data/trash/${fil}.${type.ext}`;

			fs.writeFileSync(trueFileName, buffer);

			return trueFileName;
		} catch (err) {
			console.error('Error saat download media:', err);
			return null;
		}
	};

	Shoyu.downloadM = async (m, type, filename = '') => {
		if (!m || !(m.url || m.directPath)) return Buffer.alloc(0);
		const stream = await downloadContentFromMessage(m, type);
		let buffer = Buffer.from([]);
		for await (const chunk of stream) {
			buffer = Buffer.concat([buffer, chunk]);
		}
		if (filename) await fs.promises.writeFile(filename, buffer);
		return filename && fs.existsSync(filename) ? filename : buffer;
	};

	Shoyu.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path)
			? path
			: /^data:.*?\/.*?;base64,/i.test(path)
				? Buffer.from(path.split`, `[1], 'base64')
				: /^https?:\/\//.test(path)
					? await await getBuffer(path)
					: fs.existsSync(path)
						? fs.readFileSync(path)
						: Buffer.alloc(0);

		let buffer;
		if (options && (options.packname || options.author)) {
			buffer = await writeExifImg(buff, options);
		} else {
			buffer = await imageToWebp(buff);
		}

		await Shoyu.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buffer;
	};

	Shoyu.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path)
			? path
			: /^data:.*?\/.*?;base64,/i.test(path)
				? Buffer.from(path.split`, `[1], 'base64')
				: /^https?:\/\//.test(path)
					? await await getBuffer(path)
					: fs.existsSync(path)
						? fs.readFileSync(path)
						: Buffer.alloc(0);

		let buffer;
		if (options && (options.packname || options.author)) {
			buffer = await writeExifVid(buff, options);
		} else {
			buffer = await videoToWebp(buff);
		}

		await Shoyu.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buffer;
	};

	Shoyu.getFile = async (PATH, save) => {
		let res;
		let data = Buffer.isBuffer(PATH)
			? PATH
			: /^data:.*?\/.*?;base64,/i.test(PATH)
				? Buffer.from(PATH.split`,`[1], 'base64')
				: /^https?:\/\//.test(PATH)
					? await (res = await getBuffer(PATH))
					: fs.existsSync(PATH)
						? ((filename = PATH), fs.readFileSync(PATH))
						: typeof PATH === 'string'
							? PATH
							: Buffer.alloc(0);

		let type = (await fileTypeFromBuffer(data)) || {
			mime: 'application/octet-stream',
			ext: 'bin',
		};

		filename = path.join(__filename, './data/trash/' + new Date() * 1 + '.' + type.ext);
		if (data && save) fs.promises.writeFile(filename, data);
		return {
			res,
			filename,
			size: await getSizeMedia(data),
			...type,
			data,
		};
	};

	Shoyu.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
		let type = await Shoyu.getFile(path, true);
		let { res, data: file, filename: pathFile } = type;

		if ((res && res.status !== 200) || file.length <= 65536) {
			try {
				throw {
					json: JSON.parse(file.toString()),
				};
			} catch (e) {
				if (e.json) throw e.json;
			}
		}

		let opt = {
			filename,
		};

		if (quoted) opt.quoted = quoted;
		if (!type) options.asDocument = true;

		let mtype = '',
			mimetype = type.mime,
			convert;

		if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
		else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
		else if (/video/.test(type.mime)) mtype = 'video';
		else if (/audio/.test(type.mime)) {
			convert = await (ptt ? toPTT : toAudio)(file, type.ext);
			file = convert.data;
			pathFile = convert.filename;
			mtype = 'audio';
			mimetype = 'audio/ogg; codecs=opus';
		} else mtype = 'document';

		if (options.asDocument) mtype = 'document';

		delete options.asSticker;
		delete options.asLocation;
		delete options.asVideo;
		delete options.asDocument;
		delete options.asImage;

		let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
		let m;

		try {
			m = await Shoyu.sendMessage(jid, message, { ...opt, ...options });
		} catch (e) {
			//console.error(e)
			m = null;
		} finally {
			if (!m) m = await Shoyu.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
			file = null;
			return m;
		}
	};

	Shoyu.getCachedGroupMetadata = async (jid) => {
		let metadata = groupCache.get(jid);

		if (!metadata) {
			metadata = await Shoyu.groupMetadata(jid);
			groupCache.set(jid, metadata);
		}

		return metadata;
	};

	Shoyu.sendContact = async (jid, kon = [], name, desk = 'Developer Bot', quoted = '', opts = {}) => {
		const list = kon.map((i) => ({
			displayName: typeof name !== 'undefined' ? name : 'Unknown',
			vcard:
				'BEGIN:VCARD\n' +
				'VERSION:3.0\n' +
				`N:;${name || 'Unknown'};;;\n` +
				`FN:${name || 'Unknown'}\n` +
				'ORG:Unknown\n' +
				'TITLE:\n' +
				`item1.TEL;waid=${i}:${i}\n` +
				'item1.X-ABLabel:Ponsel\n' +
				`X-WA-BIZ-DESCRIPTION:${desk}\n` +
				`X-WA-BIZ-NAME:${name || 'Unknown'}\n` +
				'END:VCARD',
		}));

		await Shoyu.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted });
	};
}

startBot();

fs.watchFile(__filename, () => {
	fs.unwatchFile(__filename);
	console.log(chalk.white.bold('~> Update File :'), chalk.green.bold(__filename));
	import(`${pathToFileURL(__filename).href}?update=${Date.now()}`);
});