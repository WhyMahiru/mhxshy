## Shoyu base 

# INFO 📢
  * Creator: Shoyu
  * Contact: t.me/ShoyuuAvailable90 
  * Bot name: Mahiru
  * Version: 1.0.0
  * Library: Original baileys 
  * Type: plugins 
  * Modules: ECMAScript Module (ESM)
  * database: Structured Query Language (SQL)
  * bot menggunakan mata uang menengah 
  
# FEATURES 🤖
  * Support buttons, Carousel, Produc, Catalog, richAi, dll
  * Auto convert @lid > @whatsapp.net
  * Auto reload plugin & auto add cmd baru ke menu 
  * Terdapat beberapa fitur bawaan 
  * No bad sesions 
  * Free dokumentasi penggunaan helper 
  * Tanpa newsletter follow 
  
# PENGGUNAAN 👤
  * Jika tidak muncul notif pairing dari WhatsApp nya langsung tautkan aja
  * User wajib ubah nomor owner di file settings.js > cari global.owner = ["62xx"]
  * Ubah juga di file ./data/owner.json ["62xxx@s.whatsapp.net","62xxx@s.whatsapp.net"]
  * Note, format wajib sama seperti di atas agar tidak eror
  * Jika nomor bukan dari Indonesia tulis saja full format nya tanpa spasi, strip (-), kurung buka (), & tambah (+)
  * Contoh +1 (548) 457-xxxx, maka cara penulisan nya adalah 1548457xxxx
  * jika ingin menampilkan command yg ada di case untuk di terapkan ke tampilan menu gunakan ini // @namacategory--namacmdnya
  * contoh // @owner--addprem
		case 'addprem': {
			await reply(`kontl!`);
			break;
		}
/*maka akan muncul di tampilan menu command nya*/

# HANDLER PLUGINS 📂
group: false,
    group: false, //khusus group
	limit: false, //sytem limit 
	premium: false, //khusus premium 
	admin: false, //hanya admin
	owner: false, //hanya owner 
	botAdmin: false, //bot harus admin
	privates: false, //khusus private 
	noJadiBot: false, //block command pengguna jadibot
    
    true = aktif 
    false = nonaktif 

# CONTOH KODE PLUGINS 📂
const handler = async (m, { Shoyu }) => {
   m.reply("contoh!!")
}
han dler.command = ["tes"]
    group: false,
	limit: false,
	premium: false,
	admin: false,
	owner: false,
	botAdmin: false,
	privates: false,
	noJadiBot: false,

export default handler;

# RUNNING 🖥️
** PANEL PETERODACTYL **
1. masuk ke panel kalian 
2. masuk ke file
3. upload script 
4. pencet ( ⋮ ) titik tiga di sebelah kanan file yang telah di upload 
5. pilih unzip
6. terus masuk ke console > klik start > tuggu sampai di suruh masuk in nomor > masuk in nomor 62xxx enter > tauin ke wa > done!!

** VPS (VIRTUAL PRIVATE SERVER) **
1. siapin vps nya login vps nya di apk termius
2. masuk terus setting dulu vps nya (kalo belum di setting)
    apt update &&  apt install wget && wget https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh && bash install.sh && source ~/.bashrc && nvm install v22 && npm i pm2 -g && pm2 install ffmpeg && apt install git &&  apt install ffmpeg -y &&   apt install webp -y &&  apt install ffmpeg -y &&  apt install imagemagick -y && apt install unzip && apt install zip && apt install neofetch && apt-get install g++ && npm i gyp -g && apt-get install make && apt install python3-pip && apt install speedtest-cli && neofetch
   salin aja kode di atas tempel di vps kalian terus tuggu sampai selesai, kalo udah 
3. pencet tanda ( + ) tanda tambah di atas > pilih SFTP
4. kalo udah pilih ( ⋮ ) titik tiga, kanan atas samping tulisan upload 
5. pilih New Folder > namain folder nya, bebas untuk namanya 
6. masuk ke folder yang udah di buat tadi > upload file script nya > pastikan nama script nya sama nama folder nya ingat yah
7. masuk ke terminal, ketik 
    › cd nama folder yang udah di buat tadi 
    › unzip nama-sc-yang-udah-di-upload.zip
    › npm install
    › npm node index.js (bagian index.js sesuaikan sama SC kalian)
    › tuggu info suruh masuk in nomor > masuk in nomor 62xxx > takutkan ke WhatsApp > balik ke apk termius lagi 
    › pencet Ctrl + c
    › pm2 start index.js --name (bagian index.js sesuaikan sama SC kalian, bagian name itu buat nama bebas apa aja)
    › pm2 save > done script terpasang 

# WARNING/ PERINGATAN ⚠️
  * Dilarang membagikan script secara gratis 
  * Silahkan kembangkan, kalo bisa creator, credits sama contributor jangan di hapus 🙏

** _Copyright (©) Shoyu 2026_ **
** _All rights reserved_ **

** 🇮🇩 Jangan hapus creator/credit maupun contributor **
** 🇬🇧 Do not delete creator/credit or contributor **

#whatsApp-bot #baileys #wabot #Shoyu #readme.md