/*
   * WhatsApp bot base using baileys (@wishkeysocket/baileys)
   * Type plugins | Modules ESM
   * Buy Script? t.me/ShoyuuAvailable90 

*⚠️ Baca file README.md di situ semua sudah lengkap 
   
   ** Copyright © Shoyu 2026 **
*/

import fs from 'fs';
import chalk from 'chalk';
import { fileURLToPath, pathToFileURL } from 'url';

const __filename = fileURLToPath(import.meta.url);

// Setting di sini
global.owner = ['6282163981775']; //nomor owner
global.nomorbot = "6282163981775"; //nomor bot+pairing nih
global.codePair = 'MAHIRUSH'; //bebas asal 8huruf 
global.namaOwner = '𝗦𝗵𝗼𝘆𝘂'; //nama owner 
global.namaBot = '𝑴𝒂𝒉𝒊𝒓𝒖 𝑺𝒉𝒊𝒏𝒂'; //nama bot 
global.footer = '© Shoyu 2026' //footernya
global.versi = '1.1.1'; //versi botnya
global.newsletter = '120363306172218802@newsletter' // ganti jadi newsletter Chanel mu jika ingin mendapatkan pake .idch di botnya

//setting foto bot 
global.thumbnail = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/mahirushina.jpg';
global.fotoreply = 'https://raw.githubusercontent.com/WhyMahiru/MahiruShina/refs/heads/main/fotoreply.jpeg'


//=================== TRUE = ON FALSE = OFF =================\\
global.bot = true //jangan di sentuh yah><
global.mainSock = null //jangan di sentuh yah><

global.autokeyword = false 
global.autoviewstatus = false
global.autotyping = false
global.autoread = false
global.gconly = false 
global.pconly = false
global.anticall = false
/* =================[ LIMIT ]================== */
//atur sesuka hati tetapi saran biarkan seperti ini
global.limitawal = {
	premium: 555,
	free: 15
}
/* =================[ MONEY ]================== */
// boleh di atur tapi saran gw g ush di otak-atik karena emng udh di set segini 
global.startingMoney = {
	premium: 55555,
	free: 5000
}

fs.watchFile(__filename, () => {
	fs.unwatchFile(__filename);
	console.log(chalk.white.bold('~> Update File :'), chalk.green.bold(__filename));
	import(`${pathToFileURL(__filename).href}?update=${Date.now()}`);
});
