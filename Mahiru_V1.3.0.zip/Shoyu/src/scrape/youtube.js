// ─────────────────────────────────────────────
// Konstanta & Utilitas
// ─────────────────────────────────────────────

const USER_AGENTS = [
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
	'Mozilla/5.0 (Linux; Android 13; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
];

function pickUserAgent() {
	return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

function jitter(base, spread = 250) {
	return base + Math.floor(Math.random() * spread);
}

function buildHeaders() {
	return {
		'User-Agent': pickUserAgent(),
		Accept: '*/*',
		'Accept-Language': 'en-US,en;q=0.9',
		Origin: 'https://id.ytmp3.mobi',
		Referer: 'https://id.ytmp3.mobi/',
		'Sec-Fetch-Dest': 'empty',
		'Sec-Fetch-Mode': 'cors',
		'Sec-Fetch-Site': 'cross-site',
	};
}

async function robustFetch(url, { retries = 3, timeoutMs = 15000 } = {}) {
	let lastError;

	for (let attempt = 0; attempt <= retries; attempt++) {
		const controller = new AbortController();
		const timer = setTimeout(() => controller.abort(), timeoutMs);

		try {
			const res = await fetch(url, {
				headers: buildHeaders(),
				signal: controller.signal,
			});
			clearTimeout(timer);

			if (res.status === 429 || res.status >= 500) {
				throw new Error(`Server returned status ${res.status}`);
			}
			if (!res.ok) {
				throw new Error(`Request failed with status code ${res.status}`);
			}

			return res;
		} catch (err) {
			clearTimeout(timer);
			lastError = err.name === 'AbortError' ? new Error('Request timed out') : err;

			if (attempt < retries) {
				const backoff = jitter(500 * 2 ** attempt, 400);
				await sleep(backoff);
				continue;
			}
		}
	}

	throw lastError;
}

function extractVideoId(url) {
	if (!url) return null;
	let match = null;
	if (url.includes('youtube.com/shorts/') || url.includes('youtu.be/')) {
		match = /\/([a-zA-Z0-9\-_]{11})/.exec(url);
	} else if (url.includes('youtube.com')) {
		match = /v=([a-zA-Z0-9\-_]{11})/.exec(url);
	} else {
		match = /[a-zA-Z0-9\-_]{11}/.exec(url);
	}
	return match ? match[1] : null;
}

async function scrapeYtmp3(youtubeUrl, format = 'mp3') {
	const videoId = extractVideoId(youtubeUrl);
	if (!videoId) {
		throw new Error('Invalid YouTube URL: Could not extract video ID.');
	}

	const lowerFormat = format.toLowerCase();
	if (lowerFormat !== 'mp3' && lowerFormat !== 'mp4') {
		throw new Error('Invalid format: Must be either "mp3" or "mp4".');
	}

	try {
		const initUrl = `https://a.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`;
		const initRes = await robustFetch(initUrl);
		const initJson = await initRes.json();
		if (initJson.error > 0) {
			throw new Error(`Init API returned error: ${initJson.error}`);
		}

		let convertUrl = initJson.convertURL;
		let convertRequestUrl = `${convertUrl}&v=${videoId}&f=${lowerFormat}&_=${Math.random()}`;
		let convertJson;
		let redirectHops = 0;
		const maxRedirectHops = 5;

		while (true) {
			const convertRes = await robustFetch(convertRequestUrl);
			convertJson = await convertRes.json();
			if (convertJson.error > 0) {
				throw new Error(`Convert API returned error: ${convertJson.error}`);
			}

			if (convertJson.redirect > 0 && convertJson.redirectURL) {
				redirectHops++;
				if (redirectHops > maxRedirectHops) {
					throw new Error('Too many redirects while requesting conversion.');
				}
				convertRequestUrl = `${convertJson.redirectURL}&v=${videoId}&f=${lowerFormat}&_=${Math.random()}`;
				await sleep(jitter(300, 200));
				continue;
			}
			break;
		}

		const progressUrl = convertJson.progressURL;
		const downloadUrl = convertJson.downloadURL;
		let title = convertJson.title || '';

		if (!progressUrl) {
			throw new Error('API conversion response is missing progress URL.');
		}

		let progress = 0;
		let pollCount = 0;
		const maxPolls = 60; 

		while (progress < 3 && pollCount < maxPolls) {
			await sleep(jitter(1000, 400));
			pollCount++;

			const progressRes = await robustFetch(progressUrl, { retries: 2, timeoutMs: 10000 });
			const progressJson = await progressRes.json();
			if (progressJson.error > 0) {
				throw new Error(`Progress API returned error: ${progressJson.error}`);
			}

			progress = progressJson.progress;
			if (progressJson.title) {
				title = progressJson.title;
			}
		}

		if (progress < 3) {
			throw new Error('Conversion process timed out (exceeded polling limit).');
		}

		return {
			status: 'success',
			videoId,
			title,
			format: lowerFormat,
			downloadUrl,
		};
	} catch (error) {
		return {
			status: 'error',
			message: error.message,
		};
	}
}

export { scrapeYtmp3, extractVideoId };