import axios from "axios";
import * as cheerio from "cheerio";

export const artinama = (query) => {
  return new Promise((resolve, reject) => {
    axios
      .get(
        "https://www.primbon.com/arti_nama.php?nama1=" +
          encodeURIComponent(query) +
          "&proses=+Submit%21+",
      )
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const result = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");
        const result2 = result.split("\n      \n        \n        \n")[0];
        const result4 = result2.split("ARTI NAMA")[1];
        const result5 = result4?.split(".\n\n") || [];
        resolve(`${result5[0] || ""}\n\n${result5[1] || ""}`.trim());
      })
      .catch(reject);
  });
};

export const petungHariBaik = (tgl, bln, thn) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.primbon.com/petung_hari_baik.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        tgl: String(tgl),
        bln: String(bln),
        thn: String(thn),
        submit: " Submit! ",
      }),
    })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const result = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const result2 = result.split("Watak Hari Menurut Kamarokam")[1];
        if (!result2) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali input tanggal/bulan/tahun kamu",
          });
        }

        const result3 = result2.split(/<\s*Hitung Kembali/i)[0];

        const spaced = result3.replace(
          /([a-z0-9.,)])([A-Z][A-Za-z ]{2,}:)/g,
          "$1\n$2",
        );

        const lines = spaced
          .split("\n")
          .map((l) => l.trim())
          .filter(Boolean);

        const first = lines[0] || "";
        const [hariPasaranRaw, tanggalRaw] = first.split(/,\s*Tgl\.\s*/);
        const hari_pasaran = (hariPasaranRaw || "").trim();
        const tanggal = tanggalRaw ? `Tgl. ${tanggalRaw.trim()}` : "";

        const info = {};
        for (const line of lines.slice(1)) {
          const m = line.match(/^([A-Za-z ]+):\s*(.+)$/);
          if (m) info[m[1].trim()] = m[2].trim();
        }

        if (!hari_pasaran && Object.keys(info).length === 0) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali input tanggal/bulan/tahun kamu",
          });
        }

        resolve({
          creator: "Shoyu",
          data: {
            hari_pasaran,
            tanggal,
            nuju_pati: info["Nuju Pati"] || "",
            kala_tinantang: info["Kala Tinantang"] || "",
          },
        });
      })
      .catch(reject);
  });
};

export const tafsirMimpi = (mimpi) => {
  return new Promise((resolve, reject) => {
    axios
      .get(
        "https://www.primbon.com/tafsir_mimpi.php?mimpi=" +
          encodeURIComponent(mimpi) +
          "&submit=+Submit+",
      )
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const result = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const result2 = result.split(`Hasil pencarian untuk kata kunci: ${mimpi}`)[1];
        if (!result2) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: `Tafsir mimpi "${mimpi}" tidak ditemukan, coba kata kunci lain.`,
          });
        }

        const result3 = result2
          .split(/<\s*Hitung Kembali|<\s*Kembali/i)[0]
          .split("Solusi -")[0];

        const rawText = result3.replace(/\s+/g, " ").trim();
        const artiList = rawText
          .split(/(?<=\.)\s*(?=Mimpi)/g)
          .map((s) => s.trim())
          .filter(Boolean);

        if (artiList.length === 0) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: `Tafsir mimpi "${mimpi}" tidak ditemukan, coba kata kunci lain.`,
          });
        }

        resolve({
          creator: "Shoyu",
          data: {
            mimpi,
            arti: artiList,
          },
        });
      })
      .catch(reject);
  });
};

export const zodiak = (nama) => {
  return new Promise((resolve, reject) => {
    axios
      .get(`https://www.primbon.com/zodiak/${encodeURIComponent(nama.toLowerCase())}.htm`)
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const labels = [
          "Nomor Keberuntungan",
          "Aroma Keberuntungan",
          "Planet Yang Mengitari",
          "Bunga Keberuntungan",
          "Warna Keberuntungan",
          "Batu Keberuntungan",
          "Elemen Keberuntungan",
          "Pasangan Serasi",
        ];

        const positions = labels
          .map((label) => ({ label, index: fetchText.indexOf(label + ":") }))
          .filter((p) => p.index !== -1)
          .sort((a, b) => a.index - b.index);

        if (positions.length === 0) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: `Zodiak "${nama}" tidak ditemukan, cek kembali penulisannya.`,
          });
        }

        const fields = {};
        let descStart = fetchText.length;
        positions.forEach(({ label, index }, i) => {
          const start = index + label.length + 1;
          let end;
          if (i + 1 < positions.length) {
            end = positions[i + 1].index;
          } else {
            const nl = fetchText.indexOf("\n", start);
            end = nl !== -1 ? nl : start + 60;
          }
          fields[label] = fetchText.slice(start, end).trim();
          if (i + 1 === positions.length) descStart = end;
        });


        const deskripsi = fetchText
          .slice(descStart)
          .split("\n")
          .map((l) => l.trim())
          .filter(Boolean)
          .slice(0, 3)
          .join(" ")
          .replace(/<+\s*Kembali.*$/i, "")
          .trim();

        resolve({
          creator: "Shoyu",
          data: {
            zodiak: nama,
            nomor_keberuntungan: fields["Nomor Keberuntungan"] || "",
            aroma_keberuntungan: fields["Aroma Keberuntungan"] || "",
            planet_yang_mengitari: fields["Planet Yang Mengitari"] || "",
            bunga_keberuntungan: fields["Bunga Keberuntungan"] || "",
            warna_keberuntungan: fields["Warna Keberuntungan"] || "",
            batu_keberuntungan: fields["Batu Keberuntungan"] || "",
            elemen_keberuntungan: fields["Elemen Keberuntungan"] || "",
            pasangan_serasi: fields["Pasangan Serasi"] || "",
            deskripsi,
          },
        });
      })
      .catch(reject);
  });
};

export const nomorHokiBaguaShuzi = (nomor) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.primbon.com/no_hoki_bagua_shuzi.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        nomer: String(nomor),
        submit: " Submit! ",
      }),
    })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const labels = [
          "No. HP :",
          "Angka Bagua Shuzi :",
          "Kekayaan =",
          "Kesehatan =",
          "Cinta/Relasi =",
          "Kestabilan =",
          "Perselisihan =",
          "Kehilangan =",
          "Malapetaka =",
          "Kehancuran =",
        ];

        const positions = labels
          .map((label) => ({ label, index: fetchText.indexOf(label) }))
          .filter((p) => p.index !== -1)
          .sort((a, b) => a.index - b.index);

        if (positions.length === 0) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "No. HP tidak valid atau format berubah, cek kembali nomornya.",
          });
        }

        const fields = {};
        positions.forEach(({ label, index }, i) => {
          const start = index + label.length;
          const labelEnd = i + 1 < positions.length ? positions[i + 1].index : start + 200;
          const nlIndex = fetchText.indexOf("\n", start);
          const end = nlIndex !== -1 && nlIndex < labelEnd ? nlIndex : labelEnd;
          fields[label] = fetchText.slice(start, end).trim();
        });

        const persenPositif = (fetchText.match(/(\d+)%\s*ENERGI\s*NEGATIF/i) || [])[1];
        const persenNegatif = (fetchText.match(/Kehancuran\s*=\s*[^=]+=\s*(\d+)%/i) || [])[1];

        resolve({
          creator: "Shoyu",
          data: {
            nomer_hp: fields["No. HP :"] || String(nomor),
            angka_shuzi: fields["Angka Bagua Shuzi :"] || "",
            energi_positif: {
              kekayaan: fields["Kekayaan ="] || "",
              kesehatan: fields["Kesehatan ="] || "",
              cinta: fields["Cinta/Relasi ="] || "",
              kestabilan: fields["Kestabilan ="] || "",
              persentase: persenPositif ? `${persenPositif}%` : "",
            },
            energi_negatif: {
              perselisihan: fields["Perselisihan ="] || "",
              kehilangan: fields["Kehilangan ="] || "",
              malapetaka: fields["Malapetaka ="] || "",
              kehancuran: fields["Kehancuran ="] || "",
              persentase: persenNegatif ? `${persenNegatif}%` : "",
            },
          },
        });
      })
      .catch(reject);
  });
};

export const tanggalJadianPernikahan = (tgl, bln, thn) => {
  return new Promise((resolve, reject) => {
    axios
      .get(
        `https://www.primbon.com/tanggal_jadian_pernikahan.php?tgl=${tgl}&bln=${bln}&thn=${thn}&proses=+Submit%21+`,
      )
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const labels = ["Tanggal:", "Karakteristik:"];

        const positions = labels
          .map((label) => ({ label, index: fetchText.indexOf(label) }))
          .filter((p) => p.index !== -1)
          .sort((a, b) => a.index - b.index);

        if (positions.length === 0) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali input tanggal/bulan/tahun kamu",
          });
        }

        const fields = {};
        positions.forEach(({ label, index }, i) => {
          const start = index + label.length;
          if (label === "Karakteristik:") {
            const stopMatch = fetchText.slice(start).search(/<\s*Hitung Kembali/i);
            const end = stopMatch !== -1 ? start + stopMatch : start + 500;
            fields[label] = fetchText
              .slice(start, end)
              .replace(/([a-z])([A-Z][a-z])/g, "$1 $2")
              .trim();
          } else {
            const labelEnd = i + 1 < positions.length ? positions[i + 1].index : start + 200;
            const nlIndex = fetchText.indexOf("\n", start);
            const end = nlIndex !== -1 && nlIndex < labelEnd ? nlIndex : labelEnd;
            fields[label] = fetchText.slice(start, end).trim();
          }
        });

        resolve({
          creator: "Shoyu",
          data: {
            tanggal: fields["Tanggal:"] || "",
            karakteristik: fields["Karakteristik:"] || "",
            catatan:
              "Untuk kecocokan jodoh dengan pasangan, bisa dikombinasikan dengan Ramalan Jodoh, Kecocokan Cinta, dan Kecocokan Nama Pasangan.",
          },
        });
      })
      .catch(reject);
  });
};

export const wetonJawa = (tgl, bln, thn) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.primbon.com/weton_jawa.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        tgl: String(tgl),
        bln: String(bln),
        thn: String(thn),
        submit: "  WETON JAWA »  ",
      }),
    })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const labels = [
          "Tanggal:",
          "Jumlah Neptu",
          "Watak Hari (Kamarokam)",
          "Naga Hari",
          "Jam Baik (Saptawara & Pancawara)",
          "Watak Kelahiran",
        ];

        const positions = labels
          .map((label) => ({ label, index: fetchText.indexOf(label) }))
          .filter((p) => p.index !== -1)
          .sort((a, b) => a.index - b.index);

        if (positions.length === 0) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali input tanggal/bulan/tahun kamu",
          });
        }

        const fields = {};
        positions.forEach(({ label, index }, i) => {
          const start = index + label.length;
          const isLast = i + 1 >= positions.length;
          const labelEnd = isLast ? fetchText.length : positions[i + 1].index;

          let end;
          if (isLast) {
            const stopMatch = fetchText.slice(start).search(/<\s*Hitung Kembali/i);
            end = stopMatch !== -1 ? start + stopMatch : Math.min(fetchText.length, start + 4000);
          } else if (label === "Watak Hari (Kamarokam)" || label === "Watak Kelahiran") {
            end = labelEnd;
          } else {
            const nlIndex = fetchText.indexOf("\n", start);
            end = nlIndex !== -1 && nlIndex < labelEnd ? nlIndex : labelEnd;
          }

          fields[label] = fetchText
            .slice(start, end)
            .replace(/([a-z0-9])([A-Z][a-z])/g, "$1 $2")
            .replace(/^[.:]\s*/, "")
            .trim();
        });

        resolve({
          creator: "Shoyu",
          data: {
            tanggal: fields["Tanggal:"] || "",
            jumlah_neptu: fields["Jumlah Neptu"] || "",
            watak_hari: fields["Watak Hari (Kamarokam)"] || "",
            naga_hari: fields["Naga Hari"] || "",
            jam_baik: fields["Jam Baik (Saptawara & Pancawara)"] || "",
            watak_kelahiran: fields["Watak Kelahiran"] || "",
          },
        });
      })
      .catch(reject);
  });
};

export const kecocokanNamaPasangan = (nama1, nama2) => {
  return new Promise((resolve, reject) => {
    axios
      .get(
        "https://www.primbon.com/kecocokan_nama_pasangan.php?nama1=" +
          encodeURIComponent(nama1) +
          "&nama2=" +
          encodeURIComponent(nama2) +
          "&proses=+Submit%21+",
      )
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();

        const skorImgSrc = $("#body img[src*='ramalan_kecocokan_cinta']").attr('src') || '';
        const skorMatch = skorImgSrc.match(/ramalan_kecocokan_cinta(\d+)\.png/i);
        const skor = skorMatch ? parseInt(skorMatch[1], 10) : null;

        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const labels = [
          "Nama Anda:",
          "Nama Pasangan:",
          "Sisi Positif Anda:",
          "Sisi Negatif Anda:",
        ];

        const positions = labels
          .map((label) => ({ label, index: fetchText.indexOf(label) }))
          .filter((p) => p.index !== -1)
          .sort((a, b) => a.index - b.index);

        if (positions.length === 0) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali kedua nama yang dimasukkan",
          });
        }

        const fields = {};
        let lastFieldEnd = 0;

        positions.forEach(({ label, index }, i) => {
          const start = index + label.length;
          const labelEnd = i + 1 < positions.length ? positions[i + 1].index : fetchText.length;

          const nlIndex = fetchText.indexOf("\n", start);
          const camelMatch = fetchText.slice(start, labelEnd).search(/[a-z0-9][A-Z][a-z]/);
          const camelIndex = camelMatch !== -1 ? start + camelMatch + 1 : -1;

          const candidates = [labelEnd];
          if (nlIndex !== -1 && nlIndex < labelEnd) candidates.push(nlIndex);
          if (camelIndex !== -1 && camelIndex < labelEnd) candidates.push(camelIndex);
          const end = Math.min(...candidates);

          fields[label] = fetchText.slice(start, end).trim();
          lastFieldEnd = end;
        });

        const searchArea = fetchText.slice(lastFieldEnd);
        const stopMatch = searchArea.search(/<+\s*Hitung\s*Kembali/i);
        const analisis = (stopMatch !== -1 ? searchArea.slice(0, stopMatch) : searchArea.slice(0, 2000))
          .replace(/([a-z0-9])([A-Z][a-z])/g, "$1 $2")
          .trim();

        resolve({
          creator: "Shoyu",
          data: {
            nama_anda: fields["Nama Anda:"] || nama1,
            nama_pasangan: fields["Nama Pasangan:"] || nama2,
            sisi_positif: fields["Sisi Positif Anda:"] || "",
            sisi_negatif: fields["Sisi Negatif Anda:"] || "",
            skor,
            skor_url: skorImgSrc,
            analisis,
          },
        });
      })
      .catch(reject);
  });
};

export const hariSangarTaliwangke = (tgl, bln, thn) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.primbon.com/hari_sangar_taliwangke.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        tgl: String(tgl),
        bln: String(bln),
        thn: String(thn),
        kirim: " Submit! ",
      }),
    })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "")
          .replace(/([a-z0-9])([A-Z][a-z])/g, "$1 $2");

        const tanggalMatch = fetchText.match(
          /\d{1,2}\s+\w+\s+\d{4}\s*=\s*[^.\n]+\(\w+\)/,
        );
        const tanggalLengkap = tanggalMatch ? tanggalMatch[0].trim() : "";

        const statusMatch = fetchText.match(/Termasuk[^!]+!/i);
        const isSangar = !!statusMatch;
        const status = statusMatch
          ? statusMatch[0].trim()
          : "Bukan Tanggal Sangar, Bangas Padewan, atau Taliwangke. Hari yang cukup aman untuk beraktivitas.";

        let keterangan = "";
        if (statusMatch) {
          const afterStatus = fetchText.slice(statusMatch.index + statusMatch[0].length);
          const stop = afterStatus.search(/Untuk mengetahui watak hari/i);
          keterangan = (stop !== -1 ? afterStatus.slice(0, stop) : afterStatus.slice(0, 300)).trim();
        }

        if (!tanggalLengkap) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali input tanggal/bulan/tahun kamu",
          });
        }

        resolve({
          creator: "Shoyu",
          data: { tanggal_lengkap: tanggalLengkap, is_sangar: isSangar, status, keterangan },
        });
      })
      .catch(reject);
  });
};

export const primbonArahRejeki = (tgl, bln, thn) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.primbon.com/primbon_arah_rejeki.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        tgl: String(tgl),
        bln: String(bln),
        thn: String(thn),
        submit: " Submit! ",
      }),
    })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "");

        const marker = "GAYATRI:";
        const idx = fetchText.indexOf(marker);

        if (idx === -1) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali input tanggal/bulan/tahun kamu",
          });
        }

        const start = idx + marker.length;
        const stopMatch = fetchText.slice(start).search(/<\s*Hitung Kembali/i);
        const kalimat = (
          stopMatch !== -1 ? fetchText.slice(start, start + stopMatch) : fetchText.slice(start, start + 300)
        ).trim();

        const arahMatch = kalimat.match(/Rejeki berada di\s+([^.\n]+)\./i);
        const arah_rejeki = arahMatch ? arahMatch[1].trim() : "";
        const tanggal_lengkap = arahMatch
          ? kalimat.slice(0, arahMatch.index).replace(/,\s*$/, "").trim()
          : kalimat;

        resolve({
          creator: "Shoyu",
          data: {
            tanggal_lengkap,
            arah_rejeki,
          },
        });
      })
      .catch(reject);
  });
};

export const cekPotensiPenyakit = (tanggal, bulan, tahun) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.primbon.com/cek_potensi_penyakit.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        tanggal: String(tanggal).padStart(2, "0"),
        bulan: String(bulan).padStart(2, "0"),
        tahun: String(tahun),
        hitung: " Submit! ",
      }),
    })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "")
          .replace(/\.([A-Z])/g, ". $1")
          .replace(/([a-z0-9])([A-Z][a-z])/g, "$1 $2");

        const tanggalMatch = fetchText.match(
          /tgl\.\s*lahir\s*(\d{1,2}\s+\w+\s+\d{4})/i,
        );
        const tanggal_lengkap = tanggalMatch ? tanggalMatch[1].trim() : "";

        const analisisMatch = fetchText.match(
          /Anda\s+(?:tidak\s+)?memiliki[\s\S]*?(?=\*Potensi penyakit|<\s*Cek Kembali)/i,
        );
        const analisis = analisisMatch
          ? analisisMatch[0]
              .trim()
              .replace(/\s+(LOGAM|KAYU|AIR|API|TANAH):/g, "\n\n$1:")
          : "";

        if (!tanggal_lengkap || !analisis) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali input tanggal/bulan/tahun kamu",
          });
        }

        resolve({
          creator: "Shoyu",
          data: {
            tanggal_lengkap,
            analisis,
          },
        });
      })
      .catch(reject);
  });
};

export const sifatKarakterTanggalLahir = (nama, tanggal, bulan, tahun) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.primbon.com/sifat_karakter_tanggal_lahir.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        nama: String(nama),
        tanggal: String(tanggal),
        bulan: String(bulan),
        tahun: String(tahun),
        submit: " Submit! ",
      }),
    })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        $("#body script, #body style, #body ins").remove();
        const fetchText = $("#body")
          .text()
          .replace(/\(adsbygoogle[^)]*\)\.push\(\{\}\);?/g, "")
          .replace(/\.([A-Z])/g, ". $1")
          .replace(/(\d{4})(GARIS)/, "$1 $2") 
          .replace(/([a-z0-9])([A-Z][a-z])/g, "$1 $2");

        const namaMatch = fetchText.match(/Nama\s*:\s*(.+?)\s*Tgl\.\s*Lahir\s*:/i);
        const tglMatch = fetchText.match(
          /Tgl\.\s*Lahir\s*:\s*(\d{1,2}\s+\w+\s+\d{4})/i,
        );
        const garisMatch = fetchText.match(/GARIS HIDUP\s*(\d+)/i);

        const nama_hasil = namaMatch ? namaMatch[1].trim() : nama;
        const tanggal_lengkap = tglMatch ? tglMatch[1].trim() : "";
        const angka_garis_hidup = garisMatch ? garisMatch[1].trim() : "";

        let karakter = "";
        if (garisMatch) {
          const start = garisMatch.index + garisMatch[0].length;
          const rest = fetchText.slice(start);
          const stop = rest.search(/<\s*Hitung Kembali/i);
          karakter = (stop !== -1 ? rest.slice(0, stop) : rest.slice(0, 3000)).trim();
        }

        if (!tanggal_lengkap || !karakter) {
          return reject({
            status: 404,
            statuses: "Data Tidak Ditemukan",
            message: "Cek kembali nama dan tanggal lahir kamu",
          });
        }

        resolve({
          creator: "Shoyu",
          data: {
            nama: nama_hasil,
            tanggal_lengkap,
            angka_garis_hidup,
            karakter,
          },
        });
      })
      .catch(reject);
  });
};