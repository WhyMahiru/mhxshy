import axios from 'axios';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

export async function scrapePixiv(query, page = 1) {
  if (!query) {
    throw new Error('Query pencarian diperlukan');
  }

  const searchUrl = `https://www.pixiv.net/ajax/search/artworks/${encodeURIComponent(query)}?word=${encodeURIComponent(query)}&order=date_d&mode=all&p=${page}&s_mode=s_tag&type=all&lang=en`;

  let response;
  try {
    response = await axios.get(searchUrl, {
      headers: {
        'User-Agent': UA,
        Referer: 'https://www.pixiv.net/',
        Accept: 'application/json, text/plain, */*',
      },
      timeout: 15000,
    });
  } catch (err) {
    throw new Error(err.response?.data?.message || err.message || 'Pixiv: gagal menghubungi server');
  }

  if (response.data && response.data.error) {
    throw new Error('Pixiv: gagal mengambil data pencarian');
  }

  const rawItems = response.data?.body?.illustManga?.data || [];
  const validItems = rawItems.filter((item) => item && item.id);
  const slicedItems = validItems.slice(0, 10);

  const results = slicedItems.map((item) => ({
    id: item.id,
    title: item.title,
    author: item.userName,
    url: `https://www.pixiv.net/en/artworks/${item.id}`,
    thumbnail: item.url,
    isAi: Boolean(item.aiType && item.aiType === 2),
    tags: item.tags || [],
    pageCount: item.pageCount || 1,
  }));

  if (!results.length) throw new Error(`Pixiv: hasil untuk "${query}" tidak ditemukan`);

  return {
    status: true,
    creator: 'Shoyu',
    total: results.length,
    page,
    results,
  };
}
