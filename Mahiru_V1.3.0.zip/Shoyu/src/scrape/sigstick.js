import axios from 'axios';

const API = 'https://api.sigstick.com';
const BASE_URL = 'https://www.sigstick.com';
const REGION = 'id';

// ─────────────────────────────────────────────
// Stealth Config
// ─────────────────────────────────────────────

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
];

function getRandomUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function getStealthHeaders() {
  const ua = getRandomUA();
  const isChrome = ua.includes('Chrome');
  const isFirefox = ua.includes('Firefox');
  const isSafari = ua.includes('Safari') && !ua.includes('Chrome');

  const headers = {
    'User-Agent': ua,
    Accept: 'application/json, text/plain, */*',
    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'Accept-Encoding': 'gzip, deflate, br',
    Referer: 'https://www.sigstick.com/',
    Origin: 'https://www.sigstick.com',
    Connection: 'keep-alive',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-site',
    DNT: '1',
    'Cache-Control': 'no-cache',
    Pragma: 'no-cache',
  };

  if (isChrome) {
    headers['sec-ch-ua'] = '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"';
    headers['sec-ch-ua-mobile'] = '?0';
    headers['sec-ch-ua-platform'] = '"Windows"';
  }

  if (isFirefox) headers.TE = 'trailers';

  if (isSafari) {
    delete headers['sec-ch-ua'];
    delete headers['sec-ch-ua-mobile'];
    delete headers['sec-ch-ua-platform'];
  }

  return headers;
}

const client = axios.create({
  timeout: 15000,
  decompress: true,
  headers: getStealthHeaders(),
});

// ─────────────────────────────────────────────
// Utils
// ─────────────────────────────────────────────

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function humanDelay(min = 600, max = 1800) {
  const delay = Math.floor(Math.random() * (max - min + 1)) + min;
  await sleep(delay);
}

// ─────────────────────────────────────────────
// Rate limiter
// ─────────────────────────────────────────────

class RateLimiter {
  constructor(maxRequests = 10, windowMs = 60_000) {
    this.requests = [];
    this.max = maxRequests;
    this.window = windowMs;
  }

  async acquire() {
    const now = Date.now();
    this.requests = this.requests.filter(
      (timestamp) => now - timestamp < this.window
    );

    if (this.requests.length >= this.max) {
      const wait = this.window - (now - this.requests[0]) + 100;
      await sleep(wait);
      return this.acquire();
    }

    this.requests.push(Date.now());
  }
}

const rateLimiter = new RateLimiter(10, 60_000);

// ─────────────────────────────────────────────
// Retry
// ─────────────────────────────────────────────

async function fetchWithRetry(fn, maxRetries = 3) {
  let lastError;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      await rateLimiter.acquire();
      return await fn();
    } catch (error) {
      lastError = error;
      const status = error.response?.status;
      const retryable =
        status === 429 ||
        status === 502 ||
        status === 503 ||
        status === 504 ||
        !error.response;

      if (!retryable || attempt === maxRetries) {
        throw error;
      }

      const delay = Math.min(8000, 1000 * 2 ** attempt);
      console.log(
        `[Sigstick] Retry ${attempt + 1}/${maxRetries} — status ${status ?? 'network'} — wait ${delay}ms`
      );
      await sleep(delay);
    }
  }

  throw lastError;
}

// ─────────────────────────────────────────────
// Build ID — Multi Source + __NEXT_DATA__ parser
// ─────────────────────────────────────────────

let cachedBuildId = null;
let buildIdFetchedAt = 0;
const BUILD_ID_TTL = 30 * 60 * 1000; // 30 menit

function extractBuildId(html) {
  if (!html || typeof html !== 'string') return null;

  const nextDataMatch = html.match(
    /<script[^>]+id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i
  );

  if (nextDataMatch?.[1]) {
    try {
      const nextData = JSON.parse(nextDataMatch[1]);
      if (nextData?.buildId) return nextData.buildId;
    } catch {
    }
  }

  const buildIdMatch = html.match(
    /["']buildId["']\s*:\s*["']([^"']+)["']/
  );

  return buildIdMatch?.[1] || null;
}

async function fetchBuildIdFrom(path) {
  await humanDelay(300, 800);

  const { data: html } = await client.get(`${BASE_URL}${path}`, {
    responseType: 'text',
    headers: {
      ...getStealthHeaders(),
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    },
  });

  return extractBuildId(html);
}

async function getBuildId(forceRefresh = false) {
  const now = Date.now();

  if (!forceRefresh && cachedBuildId && now - buildIdFetchedAt < BUILD_ID_TTL) {
    return cachedBuildId;
  }

  const sources = ['/stickers', '/explore', '/'];

  for (const path of sources) {
    try {
      const buildId = await fetchBuildIdFrom(path);
      if (buildId) {
        cachedBuildId = buildId;
        buildIdFetchedAt = Date.now();
        return buildId;
      }
    } catch (err) {
      console.warn(`[Sigstick] Failed fetch buildId from ${path}: ${err.message}`);
    }
  }

  if (cachedBuildId) {
    console.warn(`[Sigstick] Using stale buildId: ${cachedBuildId}`);
    return cachedBuildId;
  }

  throw new Error('BuildId tidak ditemukan dari semua sumber.');
}

// ─────────────────────────────────────────────
// Search
// ─────────────────────────────────────────────

async function requestSearch(keyword, buildId) {
  const url = `${BASE_URL}/_next/data/${buildId}/stickers.json`;

  const { data } = await client.get(url, {
    params: { keyword: keyword.trim() },
    headers: {
      ...getStealthHeaders(),
      'x-nextjs-data': '1',
      Referer: `${BASE_URL}/search?q=${encodeURIComponent(keyword)}`,
    },
  });

  return data?.pageProps?.packs || [];
}

export async function searchPacks(keyword) {
  if (!keyword || !keyword.trim()) {
    throw new Error('Keyword tidak boleh kosong.');
  }

  let buildId = await getBuildId();

  try {
    return await fetchWithRetry(() => requestSearch(keyword, buildId));
  } catch (error) {
    if (error.response?.status !== 404) {
      throw error;
    }

    console.log('[Sigstick] Got 404 — refreshing buildId...');
    cachedBuildId = null;
    buildIdFetchedAt = 0;
    buildId = await getBuildId(true);

    return await fetchWithRetry(() => requestSearch(keyword, buildId));
  }
}

// ─────────────────────────────────────────────
// Trending
// ─────────────────────────────────────────────

export async function getTrending() {
  const { data } = await fetchWithRetry(() =>
    client.get(`${API}/v1/stickerPack/trending`, {
      params: { region: REGION },
    })
  );

  return data?.data?.packs || [];
}

// ─────────────────────────────────────────────
// Semua Pack
// ─────────────────────────────────────────────

export async function getPacks() {
  const { data } = await fetchWithRetry(() =>
    client.get(`${API}/v1/stickerPack`, {
      params: { region: REGION },
    })
  );

  return data?.data?.packs || [];
}

// ─────────────────────────────────────────────
// Random Pack
// ─────────────────────────────────────────────

export async function getRandomPack() {
  const packs = await getPacks();

  if (!packs.length) {
    throw new Error('Tidak ada sticker pack yang ditemukan.');
  }

  return packs[Math.floor(Math.random() * packs.length)];
}

// ─────────────────────────────────────────────
// Formatter
// ─────────────────────────────────────────────

export function formatPackList(packs) {
  if (!packs.length) {
    return '❌ Tidak ada sticker pack ditemukan.';
  }

  return packs
    .map((pack, index) => {
      const stickerCount = pack.stickers?.length || 0;
      return (
        `${index + 1}. ${pack.title || 'Tanpa judul'}\n` +
        `   👤 ${pack.author || 'Unknown'}\n` +
        `   🧩 ${stickerCount} sticker` +
        `${pack.isNsfw ? ' • 🔞 NSFW' : ''}\n` +
        `   ⬇️ ${pack.download || 0} download`
      );
    })
    .join('\n\n');
}

export function formatPackDetail(pack) {
  const lines = [
    '==============================',
    '📦 STICKER PACK',
    '==============================',
    `Title   : ${pack.title || '-'}`,
    `Author  : ${pack.author || '-'}`,
    `ID      : ${pack.id || '-'}`,
    `Download: ${pack.download || 0}`,
    `NSFW    : ${pack.isNsfw ? 'YES 🔞' : 'NO'}`,
    `Stickers: ${pack.stickers?.length || 0}`,
  ];

  if (pack.tags?.length) {
    lines.push(`Tags    : ${pack.tags.join(', ')}`);
  }

  if (pack.cover?.url) {
    lines.push(`Cover   : ${pack.cover.url}`);
  }

  if (pack.telegramUrl) {
    lines.push(`Telegram: ${pack.telegramUrl}`);
  }

  lines.push('==============================');

  return lines.join('\n');
}

// ─────────────────────────────────────────────
// Debug helper
// ─────────────────────────────────────────────

export async function getCurrentBuildId() {
  return getBuildId();
}