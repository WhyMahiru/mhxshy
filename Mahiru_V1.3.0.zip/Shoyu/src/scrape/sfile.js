import axios from 'axios';
import { load } from 'cheerio';

const SFILE_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
  Accept: '*/*',
  'Accept-Language': 'en-US,en;q=0.9',
  Connection: 'keep-alive',
};

// ─────────────────────────────────────────────
// SEARCH
// ─────────────────────────────────────────────

export async function sfileSearch(query, page = 1) {
  const { data } = await axios.get('https://sfile.co/search.php', {
    params: { q: query, page },
    headers: SFILE_HEADERS,
    timeout: 30000,
  });

  const $ = load(data);
  const results = [];

  $('.group.px-2').each((_, el) => {
    const title = $(el).find('.min-w-0 a').text().trim();
    const rawLink = $(el).find('a').attr('href');
    const info = $(el).find('.mt-1').text().split('•');

    if (!rawLink) return;
    const link = rawLink.startsWith('http') ? rawLink : `https://sfile.co${rawLink}`;

    results.push({
      title: title || '-',
      size: info[0]?.trim() || null,
      upload: info[1]?.trim() || null,
      link,
    });
  });

  return results;
}

// ─────────────────────────────────────────────
// DOWNLOAD
// ─────────────────────────────────────────────

export async function sfileDownload(url) {
  const { data: html } = await axios.get(url, {
    headers: SFILE_HEADERS,
    timeout: 30000,
  });

  const $ = load(html);

  const metadata = {
    filename: $('.overflow-hidden img').attr('alt')?.trim() || 'file',
    mimetype: $('.divide-y span').first().text().trim() || null,
    download_count: $('.divide-y .font-semibold').eq(1).text().trim() || null,
    author_name: $('.divide-y a').first().text().trim() || null,
  };

  const dl = $('#download').attr('data-dw-url') || $('a#download').attr('href');
  if (!dl) throw new Error('sfile: link download tidak ditemukan di halaman');

  const cdnRes = await axios.get(dl, {
    headers: SFILE_HEADERS,
    responseType: 'arraybuffer',
    maxRedirects: 5,
    timeout: 60000,
  });

  const finalUrl = cdnRes.request?.res?.responseUrl || dl;
  const buffer = Buffer.from(cdnRes.data);
  if (!buffer.length) throw new Error('sfile: buffer file kosong');

  return { metadata, buffer, finalUrl };
}
