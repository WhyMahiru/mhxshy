import axios from "axios";
import * as cheerio from "cheerio";
import fs from "fs";
import path from "path";

// scarper ssweb 
export const ssweb = (url, device = "desktop") => {
  return new Promise((resolve, reject) => {
    const base = "https://www.screenshotmachine.com";
    const param = {
      url,
      device,
      cacheLimit: 0,
    };

    axios({
      url: base + "/capture.php",
      method: "POST",
      data: new URLSearchParams(Object.entries(param)),
      headers: {
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
      },
    })
      .then((res) => {
        const cookies = res.headers["set-cookie"];

        if (res.data.status !== "success") {
          return reject({
            status: 404,
            statuses: "Link Error",
            message: res.data,
          });
        }

        axios
          .get(base + "/" + res.data.link, {
            headers: {
              cookie: cookies ? cookies.join("") : "",
            },
            responseType: "arraybuffer",
          })
          .then(({ data }) => {
            resolve({
              status: 200,
              result: data,
            });
          })
          .catch(reject);
      })
      .catch(reject);
  });
};

//scarper soundcloud
export const soundcloud = (link) => {
  return new Promise((resolve, reject) => {
    axios({
      method: "POST",
      url: "https://www.klickaud.co/download.php",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      data: new URLSearchParams({
        value: link,
        "2311a6d881b099dc3820600739d52e64a1e6dcfe55097b5c7c649088c4e50c37":
          "710c08f2ba36bd969d1cbc68f59797421fcf90ca7cd398f78d67dfd8c3e554e3",
      }),
    })
      .then(({ data: body }) => {
        const $ = cheerio.load(body);
        const row =
          "#header > div > div > div.col-lg-8 > div > table > tbody > tr";
        resolve({
          judul: $(`${row} > td:nth-child(2)`).text(),
          download_count: $(`${row} > td:nth-child(3)`).text(),
          thumb: $(`${row} > td:nth-child(1) > img`).attr("src"),
          link: $("#dlMP3")
            .attr("onclick")
            ?.split("downloadFile('")[1]
            ?.split("',")[0],
        });
      })
      .catch(reject);
  });
};

//scarper facebook
export const facebook = (url) => {
  return new Promise((resolve, reject) => {
    axios
      .get("https://downvideo.net/")
      .then((gdata) => {
        const $init = cheerio.load(gdata.data);
        const token = $init(
          "body > div > center > div.col-md-10 > form > div > input[type=hidden]:nth-child(2)",
        ).attr("value");

        axios({
          method: "POST",
          url: "https://downvideo.net/download.php",
          headers: {
            "content-type": "application/x-www-form-urlencoded",
            cookie: gdata.headers["set-cookie"],
            "user-agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
          },
          data: new URLSearchParams({ URL: url, token }),
        })
          .then(({ data: body }) => {
            const $ = cheerio.load(body);
            resolve({
              status: 200,
              title: $("body").find("div:nth-child(1) > h4").text(),
              sd: $("#sd > a").attr("href"),
              hd: $("body").find("div:nth-child(7) > a").attr("href"),
            });
          })
          .catch(reject);
      })
      .catch(reject);
  });
};
//scarper gempa
export const gempa = () => {
  return new Promise((resolve, reject) => {
    axios
      .get("https://www.bmkg.go.id/gempabumi/gempabumi-dirasakan.bmkg")
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const row = "table > tbody > tr:nth-child(1)";

        const drasa = [];
        $(`${row} > td:nth-child(6) > span`)
          .get()
          .forEach((el) => {
            drasa.push($(el).text().replace("\t", " "));
          });

        resolve({
          creator: "Shoyu",
          data: {
            imagemap: $(
              "div.modal-body > div > div:nth-child(1) > img",
            ).attr("src"),
            magnitude: $(`${row} > td:nth-child(4)`).text(),
            kedalaman: $(`${row} > td:nth-child(5)`).text(),
            wilayah: $(`${row} > td:nth-child(6) > a`).text(),
            waktu: $(`${row} > td:nth-child(2)`).text(),
            lintang_bujur: $(`${row} > td:nth-child(3)`).text(),
            dirasakan: drasa.join("\n"),
          },
        });
      })
      .catch(reject);
  });
};

//scarper cariresep
export const cariresep = (query) => {
  return new Promise((resolve, reject) => {
    axios
      .get("https://resepkoki.id/?s=" + encodeURIComponent(query))
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const base =
          "body > div.all-wrapper.with-animations > div:nth-child(5) > div > div.archive-posts.masonry-grid-w.per-row-2 > div.masonry-grid > div > article > div";

        const link = [];
        const judul = [];
        const thumb = [];

        $(`${base} > div.archive-item-media > a`).each((_, el) => {
          link.push($(el).attr("href"));
          const img = $(el).find("img").first();
          const src =
            img.attr("data-src") ||
            img.attr("data-lazy-src") ||
            img.attr("src") ||
            null;
          thumb.push(src);
        });
        $(`${base} > div.archive-item-content > header > h3 > a`).each(
          (_, el) => judul.push($(el).text()),
        );

        const format = link.map((l, i) => ({
          judul: judul[i],
          link: l,
          thumb: thumb[i] || null,
        }));
        resolve({ creator: "Shoyu", data: format });
      })
      .catch(reject);
  });
};

//scarper bacaresep
export const bacaresep = (query) => {
  return new Promise((resolve, reject) => {
    axios
      .get(query)
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const panel =
          "body > div.all-wrapper.with-animations > div.single-panel.os-container";

        const abahan = [];
        const atakaran = [];
        const atahap = [];

        $(
          `${panel} > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-name`,
        ).each((_, el) => abahan.push($(el).text()));
        $(
          `${panel} > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-amount`,
        ).each((_, el) => atakaran.push($(el).text()));
        $(
          `${panel} > div.single-panel-main > div.single-content > div.single-steps > table > tbody > tr > td.single-step-description > div > p`,
        ).each((_, el) => atahap.push($(el).text()));

        const judul = $(
          `${panel} > div.single-title.title-hide-in-desktop > h1`,
        ).text();
        const waktu = $(
          `${panel} > div.single-panel-main > div.single-meta > ul > li.single-meta-cooking-time > span`,
        ).text();
        const hasil = $(
          `${panel} > div.single-panel-main > div.single-meta > ul > li.single-meta-serves > span`,
        )
          .text()
          .split(": ")[1];
        const level = $(
          `${panel} > div.single-panel-main > div.single-meta > ul > li.single-meta-difficulty > span`,
        )
          .text()
          .split(": ")[1];
        const thumb = $(
          `${panel} > div.single-panel-details > div > div.single-main-media > img`,
        ).attr("src");

        const bahan = abahan
          .map((b, i) => `${b} ${atakaran[i]}`)
          .join("\n");
        const tahap = atahap.join("\n\n");

        resolve({
          creator: "Shoyu",
          judul_nya: judul,
          waktu_nya: waktu,
          hasil_nya: hasil,
          tingkat_kesulitan: level,
          thumb_nya: thumb,
          bahan_nya: bahan,
          langkah_langkah: tahap,
        });
      })
      .catch(reject);
  });
};

export const bacaresepMulti = (url) => {
  return new Promise((resolve, reject) => {
    axios
      .get(url)
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const items = [];

        $("h3").each((_, el) => {
          const headerText = $(el).text().trim();
          const match = headerText.match(/^(\d+)\.\s*(.+)$/);
          if (!match) return;

          const index = parseInt(match[1], 10);
          const judul = match[2].trim();

          const section = $(el).nextUntil("h3");
          let mode = null; // 'bahan' | 'langkah' | null
          const bahanLines = [];
          const langkahLines = [];

          section.each((__, sib) => {
            const $sib = $(sib);
            const text = $sib.text().trim();
            if (!text) return;

            if (/^bahan/i.test(text)) {
              mode = "bahan";
              return;
            }
            if (/^cara\s*membuat/i.test(text)) {
              mode = "langkah";
              return;
            }
            if (/^tips/i.test(text)) {
              mode = null;
              return;
            }

            if ($sib.is("ol")) {
              $sib.find("li").each((___, li) => langkahLines.push($(li).text().trim()));
              return;
            }

            if (mode === "bahan" && $sib.is("p")) {
              bahanLines.push(text);
            }
          });

          items.push({
            index,
            judul,
            bahan: bahanLines.join("\n"),
            langkah: langkahLines
              .map((s, i) => `${i + 1}. ${s}`)
              .join("\n\n"),
          });
        });

        if (!items.length) {
          return reject({
            status: 404,
            statuses: "Bukan Halaman Kumpulan Resep",
            message: "Format halaman tidak dikenali sebagai kumpulan resep",
          });
        }

        resolve({
          creator: "Shoyu",
          judul_artikel: $("h1").first().text().trim(),
          data: items,
        });
      })
      .catch(reject);
  });
};

//scarper wallpapercave
const WALLPAPERCAVE_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

function extractWallpapercaveImages($, limit = 20) {
  const result = [];
  const seen = new Set();

  $('a[href*="/w/"]').each((_, el) => {
    const src = $(el).find("img").attr("src");
    if (!src || src.includes(".gif") || seen.has(src)) return;
    if (src.includes("fuwp")) return;
    seen.add(src);
    result.push(src.startsWith("http") ? src : "https://wallpapercave.com" + src);
  });

  return Number.isFinite(limit) ? result.slice(0, limit) : result;
}

function extractWallpapercaveCategories($) {
  const seen = new Set();
  const categories = [];

  $('a[href*="-wallpapers"]').each((_, el) => {
    const href = $(el).attr("href");
    if (!href || seen.has(href)) return;

    const fullText = $(el).text().replace(/\s+/g, " ").trim();
    const countMatch = fullText.match(/([\d,]+)\s*wallpapers?/i);
    if (!countMatch) return; 

    const title = fullText.replace(countMatch[0], "").trim();
    if (!title) return;

    seen.add(href);
    const thumb = $(el).find("img").attr("src");

    categories.push({
      title,
      count: parseInt(countMatch[1].replace(/,/g, ""), 10) || 0,
      thumbnail: thumb ? (thumb.startsWith("http") ? thumb : "https://wallpapercave.com" + thumb) : null,
      url: href.startsWith("http") ? href : "https://wallpapercave.com" + href,
    });
  });

  return categories;
}

export const wallpapercaveSearch = (query) => {
  return new Promise((resolve, reject) => {
    axios
      .get("https://wallpapercave.com/search?q=" + encodeURIComponent(query), {
        headers: { "user-agent": WALLPAPERCAVE_UA },
      })
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const images = extractWallpapercaveImages($);
        if (images.length) return resolve({ type: "images", items: images });

        const categories = extractWallpapercaveCategories($);
        resolve({ type: "categories", items: categories });
      })
      .catch(reject);
  });
};

export const wallpapercaveCategory = (url) => {
  return new Promise((resolve, reject) => {
    axios
      .get(url, { headers: { "user-agent": WALLPAPERCAVE_UA } })
      .then(({ data }) => {
        resolve(extractWallpapercaveImages(cheerio.load(data), Infinity));
      })
      .catch(reject);
  });
};

// pdf to jpg
const BASE = 'https://api.ilovepdf.com';
const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36';

async function getPublicToken() {
  const res = await axios.get('https://www.ilovepdf.com/pdf_to_jpg', {
    headers: { 'User-Agent': UA },
    timeout: 15000,
  });
  const match = String(res.data).match(/"token":"([^"]+)"/);
  if (!match) throw new Error('iLovePDF: token tidak ditemukan');
  return match[1];
}

async function startTask(token) {
  const res = await axios.get(`${BASE}/v1/start/pdfjpg`, {
    headers: { Authorization: `Bearer ${token}` },
    timeout: 15000,
  });
  if (!res.data?.server || !res.data?.task) {
    throw new Error('iLovePDF: gagal memulai task (server/task kosong)');
  }
  return { server: `https://${res.data.server}`, task: res.data.task };
}

async function uploadFile(server, task, token, filePath) {
  if (!fs.existsSync(filePath)) throw new Error(`File tidak ditemukan: ${filePath}`);

  const fileBuffer = fs.readFileSync(filePath);

  const form = new FormData();
  form.append('task', task);
  form.append('file', new Blob([fileBuffer]), path.basename(filePath));

  const res = await fetch(`${server}/v1/upload`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: form,
  });

  const data = await res.json();
  if (!data?.server_filename) throw new Error('iLovePDF: upload gagal (server_filename kosong)');
  return data.server_filename;
}

async function processTask(server, task, token, serverFilename, originalName, mode = 'pages', dpi = '150') {
  const form = new FormData();
  form.append('task', task);
  form.append('tool', 'pdfjpg');
  form.append('pdfjpg_mode', mode);
  form.append('dpi', dpi);
  form.append('output_filename', '{filename}_page');
  form.append('packaged_filename', 'ilovepdf_pages-to-jpg');
  form.append('files[0][server_filename]', serverFilename);
  form.append('files[0][filename]', originalName);

  const res = await fetch(`${server}/v1/process`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: form,
  });

  const data = await res.json();
  if (data?.status && data.status !== 'TaskSuccess') {
    throw new Error(`iLovePDF: proses gagal (status: ${data.status})`);
  }
}

async function downloadResult(server, task, token) {
  const res = await fetch(`${server}/v1/download/${task}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  const arrayBuffer = await res.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  if (!buffer.length) throw new Error('iLovePDF: hasil download kosong');
  return buffer;
}

export async function pdfToJpg(filePath, { mode = 'pages', dpi = '150', outputPath = null } = {}) {
  const token = await getPublicToken();
  const { server, task } = await startTask(token);
  const serverFilename = await uploadFile(server, task, token, filePath);
  await processTask(server, task, token, serverFilename, path.basename(filePath), mode, dpi);
  const buffer = await downloadResult(server, task, token);

  if (outputPath) fs.writeFileSync(outputPath, buffer);

  return { buffer, outputPath };
}

//scarper jpgtopdf 
async function getPublicTokenImg() {
  const res = await axios.get('https://www.ilovepdf.com/jpg_to_pdf', {
    headers: { 'User-Agent': UA },
    timeout: 15000,
  });
  const match = String(res.data).match(/"token":"([^"]+)"/);
  if (!match) throw new Error('iLovePDF: token tidak ditemukan');
  return match[1];
}

async function startTaskImg(token) {
  const res = await axios.get(`${BASE}/v1/start/imagepdf`, {
    headers: { Authorization: `Bearer ${token}` },
    timeout: 15000,
  });
  if (!res.data?.server || !res.data?.task) {
    throw new Error('iLovePDF: gagal memulai task (server/task kosong)');
  }
  return { server: `https://${res.data.server}`, task: res.data.task };
}

async function processTaskImg(server, task, token, files, { orientation = 'portrait', margin = '0', pagesize = 'fit' } = {}) {
  const form = new FormData();
  form.append('task', task);
  form.append('tool', 'imagepdf');
  form.append('orientation', orientation);
  form.append('margin', margin);
  form.append('pagesize', pagesize);
  form.append('packaged_filename', 'ilovepdf_merged');

  files.forEach((f, i) => {
    form.append(`files[${i}][server_filename]`, f.serverFilename);
    form.append(`files[${i}][filename]`, f.originalName);
  });

  const res = await fetch(`${server}/v1/process`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: form,
  });

  const data = await res.json();
  if (data?.status && data.status !== 'TaskSuccess') {
    throw new Error(`iLovePDF: proses gagal (status: ${data.status})`);
  }
}

export async function jpgToPdf(filePaths, { orientation = 'portrait', margin = '0', pagesize = 'fit', outputPath = null } = {}) {
  const paths = Array.isArray(filePaths) ? filePaths : [filePaths];
  if (!paths.length) throw new Error('jpgToPdf: butuh minimal 1 file gambar.');

  const token = await getPublicTokenImg();
  const { server, task } = await startTaskImg(token);

  const files = [];
  for (const p of paths) {
    const serverFilename = await uploadFile(server, task, token, p);
    files.push({ serverFilename, originalName: path.basename(p) });
  }

  await processTaskImg(server, task, token, files, { orientation, margin, pagesize });
  const buffer = await downloadResult(server, task, token);

  if (outputPath) fs.writeFileSync(outputPath, buffer);

  return { buffer, outputPath };
}


//scarper lirik
export async function lirik(title) {
  if (!title) throw new Error("Judul lagu diperlukan");

  try {
    const { data } = await axios.get(
      `https://lrclib.net/api/search?q=${encodeURIComponent(title)}`, // Thanks To Nekolabs
      {
        headers: {
          referer: `https://lrclib.net/search/${encodeURIComponent(title)}`,
          "user-agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
        },
      },
    );

    return data;
  } catch (error) {
    throw new Error(error.message);
  }
}

// ─────────────────────────────────────────────
// scarper jadwaltv
// ─────────────────────────────────────────────
export async function jadwalTv(channel) {
  if (!channel) throw new Error("Nama channel diperlukan");

  const slug = channel.toLowerCase().trim().replace(/\s+/g, "-");
  const url = `https://www.jadwaltv.net/channel/${encodeURIComponent(slug)}`;

  let html;
  try {
    ({ data: html } = await axios.get(url, {
      timeout: 15000,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/137.0.0.0 Mobile Safari/537.36",
        Accept: "text/html,application/xhtml+xml",
      },
    }));
  } catch (err) {
    if (err.response?.status === 404) {
      throw new Error(`Channel "${channel}" tidak ditemukan`);
    }
    throw new Error(
      err.response ? `Gagal mengambil data (HTTP ${err.response.status}).` : err.message,
    );
  }

  const $ = cheerio.load(html);
  const jadwal = [];

  $("tr.jklIv").each((_, el) => {
    const td = $(el).find("td");
    if (td.length < 2) return;

    const jam = $(td[0]).text().replace(/\s+/g, "").trim();
    const acara = $(td[1]).text().replace(/\s+/g, " ").trim();
    if (!jam || !acara) return;

    jadwal.push({ jam, acara });
  });

  if (!jadwal.length) {
    throw new Error(`Channel "${channel}" tidak ditemukan di JadwalTV.net.`);
  }

  return {
    channel: channel.toUpperCase(),
    url,
    total: jadwal.length,
    jadwal,
  };
}