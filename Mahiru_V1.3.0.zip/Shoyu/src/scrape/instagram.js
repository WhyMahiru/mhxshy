import axios from 'axios';

// ─────────────────────────────────────────────
// PROVIDER: clipssaver.com
// ─────────────────────────────────────────────

const CS_UA_POOL = [
  'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
];
const CS_API_URL = 'https://clipssaver.com/api/instagram/instagramDownloader/download-post';

const randomUA = () => CS_UA_POOL[Math.floor(Math.random() * CS_UA_POOL.length)];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function fromClipssaver(url) {
  await sleep(300 + Math.floor(Math.random() * 500));

  let data;
  try {
    ({ data } = await axios.post(
      CS_API_URL,
      { url },
      {
        timeout: 30000,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'user-agent': randomUA(),
          Origin: 'https://clipssaver.com',
          Referer: 'https://clipssaver.com/',
          'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
        },
      },
    ));
  } catch (err) {
    throw new Error(`clipssaver: ${err.response?.data?.message || err.message || 'gagal menghubungi server'}`);
  }

  if (data?.status !== 'success') throw new Error('clipssaver: gagal mengambil data postingan');

  const result = data.data?.post;
  if (!result) throw new Error('clipssaver: data postingan tidak ditemukan');

  const title = result.edge_media_to_caption?.edges?.[0]?.node?.text || null;
  const author = result.owner?.username || null;
  const thumbnail = result.thumbnail_src || null;

  // ── CAROUSEL ──
  const sidecarEdges = result.edge_sidecar_to_children?.edges;
  if (Array.isArray(sidecarEdges) && sidecarEdges.length) {
    const slideItems = sidecarEdges
      .map((edge) => {
        const node = edge.node || {};
        const isVideo = Boolean(node.is_video) || Boolean(node.video_url);
        const itemUrl = isVideo ? node.video_url : node.display_url;
        if (!itemUrl) return null;
        return { type: isVideo ? 'video' : 'image', url: itemUrl };
      })
      .filter(Boolean);

    if (!slideItems.length) throw new Error('clipssaver: tidak ada media valid di carousel ini');

    return {
      provider: 'clipssaver',
      type: 'slide',
      title,
      author,
      thumbnail,
      musicUrl: null,
      images: slideItems.filter((it) => it.type === 'image').map((it) => it.url),
      slideItems,
      links: slideItems.map((it, i) => ({
        text: it.type === 'video' ? `Video ${i + 1}` : `Foto ${i + 1}`,
        url: it.url,
      })),
    };
  }

  // ── POST TUNGGAL ──
  const isVideo = Boolean(result.video_url) || result.type === 'video';
  const videoUrl = result.video_url || result.download_url || null;
  const imageUrl = result.display_url || null;

  if (isVideo) {
    if (!videoUrl) throw new Error('clipssaver: tidak ada link video');
    return {
      provider: 'clipssaver',
      type: 'video',
      title,
      author,
      thumbnail,
      musicUrl: null,
      images: [],
      links: [{ text: 'Video', url: videoUrl }],
    };
  }

  if (!imageUrl) throw new Error('clipssaver: tidak ada link foto');
  return {
    provider: 'clipssaver',
    type: 'image',
    title,
    author,
    thumbnail,
    musicUrl: null,
    images: [imageUrl],
    links: [{ text: 'Foto', url: imageUrl }],
  };
}

export async function downloadInstagram(url) {
  if (!url || !/instagram\.com/i.test(url)) {
    throw new Error('URL Instagram tidak valid');
  }

  const result = await fromClipssaver(url);
  if (!result?.links?.length) throw new Error('clipssaver: tidak ada link download');

  return result;
}