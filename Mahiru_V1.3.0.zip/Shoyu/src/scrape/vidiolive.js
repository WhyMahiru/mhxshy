const LIVE_URL = 'https://www.vidio.com/live';
const API_URL = 'https://api.vidio.com/livestreamings';

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  Accept: 'application/json, text/plain, */*',
  Origin: 'https://www.vidio.com',
  Referer: 'https://www.vidio.com/',
};

const CACHE_TTL_MS = 3 * 60 * 1000; 
let channelsCache = null;
let channelsCacheAt = 0;

function extractValue(str, key) {
  const regex = new RegExp(`"${key}":\\s*(?:"([^"]*)"|(null|true|false|[0-9]+))`);
  const match = str.match(regex);
  if (match) return match[1] !== undefined ? match[1] : match[2];
  return null;
}

function fallbackStreamUrl(contentId) {
  return `https://geo-id-etslive-v3-vidio-com-tokenized.akamaized.net/stream/${contentId}/file/drm/hls/master.m3u8`;
}

async function getDetailStream(contentId) {
  try {
    const response = await fetch(`${API_URL}/${contentId}`, { headers: HEADERS });
    const data = await response.json();

    const streamUrl = data?.data?.attributes?.stream_url;
    if (!streamUrl || streamUrl.trim() === '') return fallbackStreamUrl(contentId);

    return streamUrl;
  } catch {
    return fallbackStreamUrl(contentId);
  }
}

async function scrapeAllChannels() {
  const response = await fetch(LIVE_URL, { headers: HEADERS });
  if (!response.ok) throw new Error('Gagal mengakses Vidio Live');

  const html = await response.text();
  const chunks = [...html.matchAll(/self\.__next_f\.push\(\[\d+,\s*"((?:[^"\\]|\\.)*)"\]\)/g)];
  const rawPayload = chunks.map((m) => m[1]).join('').replace(/\\"/g, '"').replace(/\\\\/g, '\\');

  const blockPattern = /"content_id":(\d+),"content_type":"(livestreaming|livestreaming_schedule)",(.*?)(?=,"links":)/g;
  let match;
  const channelsData = {};

  while ((match = blockPattern.exec(rawPayload)) !== null) {
    const contentId = match[1];
    const type = match[2];
    const block = match[3];

    const title = extractValue(block, 'title');
    const altTitle = extractValue(block, 'alt_title');
    let streamUrl = extractValue(block, 'stream_url');
    const startTime = extractValue(block, 'start_time');
    const endTime = extractValue(block, 'end_time');
    const liveTitle = extractValue(block, 'livestreaming_title');

    let channelName = type === 'livestreaming' ? altTitle : liveTitle || altTitle;
    if (!channelName) continue;
    if (channelName.includes('·')) channelName = channelName.split('·').pop().trim();

    const channelKey = channelName.toLowerCase();

    if (!channelsData[channelKey]) {
      channelsData[channelKey] = {
        channel_id: parseInt(contentId),
        channel_name: channelName,
        now_playing: 'Tidak ada informasi',
        stream_url: streamUrl === 'null' || !streamUrl ? '' : streamUrl,
        schedules: [],
      };
    }

    if (streamUrl && streamUrl !== 'null' && streamUrl.trim() !== '') {
      channelsData[channelKey].stream_url = streamUrl;
    }

    if (type === 'livestreaming') {
      channelsData[channelKey].now_playing = title;
    } else if (type === 'livestreaming_schedule') {
      channelsData[channelKey].schedules.push({
        title,
        start_time: new Date(startTime).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' }),
        end_time: new Date(endTime).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' }),
      });
    }
  }

  return channelsData;
}

async function fetchAllChannels(force = false) {
  const now = Date.now();
  if (!force && channelsCache && now - channelsCacheAt < CACHE_TTL_MS) {
    return channelsCache;
  }

  const data = await scrapeAllChannels();
  channelsCache = data;
  channelsCacheAt = now;
  return data;
}

export async function getLiveChannels(queries) {
  const list = Array.isArray(queries) ? queries : [queries];
  const allChannels = await fetchAllChannels();
  const results = [];

  await Promise.all(
    list.map(async (query) => {
      const matchedKey = Object.keys(allChannels).find((k) => k.includes(query.toLowerCase()));

      if (!matchedKey) {
        results.push({ query, status: 'not_found', data: null });
        return;
      }

      const channel = allChannels[matchedKey];

      if (!channel.stream_url || channel.stream_url.trim() === '') {
        channel.stream_url = await getDetailStream(channel.channel_id);
      }

      results.push({
        query,
        status: 'success',
        data: {
          channel_id: channel.channel_id,
          channel_name: channel.channel_name,
          now_playing: channel.now_playing,
          stream_url: channel.stream_url,
          total_schedules: channel.schedules.length,
          schedules: channel.schedules,
        },
      });
    })
  );

  return results;
}

export { fetchAllChannels };