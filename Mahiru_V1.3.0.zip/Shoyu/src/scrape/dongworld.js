import https from 'node:https';
import http from 'node:http';
import { URL } from 'node:url';

const BASE_URL = 'https://www.dongworld.top';
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9',
};

function fetchUrl(url) {
  return new Promise((resolve) => {
    try {
      const parsedUrl = new URL(url);
      const client = parsedUrl.protocol === 'https:' ? https : http;

      const req = client.get(url, { headers: HEADERS, timeout: 15000 }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          const redirectUrl = new URL(res.headers.location, url).href;
          return resolve(fetchUrl(redirectUrl));
        }

        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => resolve(data));
      });

      req.on('error', () => resolve(null));
      req.on('timeout', () => {
        req.destroy();
        resolve(null);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

function formatTitle(slug) {
  if (!slug) return '';
  return slug
    .replace(/,/g, '')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function parseSeriesCards(html) {
  const results = [];
  if (!html) return results;

  const seriesMatches = [...html.matchAll(/{"id":(\d+),"name":"([^"]+)",(?:.*?"slug":"([^"]+)")?/g)];
  const seenSlugs = new Set();

  seriesMatches.forEach((m) => {
    const id = m[1];
    const name = m[2];
    const slug = (m[3] || name.toLowerCase().replace(/[^a-z0-9]+/g, '-')).replace(/,/g, '').replace(/(^-|-$)/g, '');

    if (!seenSlugs.has(slug) && slug.length > 1 && slug !== 'series' && slug !== 'watch') {
      seenSlugs.add(slug);

      const imgMatch = html.match(new RegExp(`storage\\\\?/series\\\\?/([^"'\\s]+\\.webp)`));
      const thumbnail = imgMatch ? `${BASE_URL}/api/image?path=storage/series/${imgMatch[1]}` : null;

      results.push({
        id: parseInt(id, 10),
        title: name,
        slug: slug,
        url: `${BASE_URL}/series/${slug}`,
        thumbnail: thumbnail,
      });
    }
  });

  if (results.length === 0) {
    const htmlCardMatches = [...html.matchAll(/href="\/series\/([a-zA-Z0-9\-_]+)"/g)];
    htmlCardMatches.forEach((m) => {
      const slug = m[1].replace(/,/g, '');
      if (!seenSlugs.has(slug) && !slug.includes('?')) {
        seenSlugs.add(slug);
        results.push({
          title: formatTitle(slug),
          slug: slug,
          url: `${BASE_URL}/series/${slug}`,
          thumbnail: null,
        });
      }
    });
  }

  return results;
}

function extractAllStreamUrls(html) {
  const streams = [];
  const seen = new Set();

  if (!html) return { direct_bot_link: null, streams: [] };

  const gdriveMatches = [...html.matchAll(/https?:\/\/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/gi)];
  gdriveMatches.forEach((m) => {
    const fileId = m[1];
    const directBotUrl = `https://drive.usercontent.google.com/download?id=${fileId}&export=download`;
    const embedUrl = `https://drive.google.com/file/d/${fileId}/view`;

    if (!seen.has(directBotUrl)) {
      seen.add(directBotUrl);
      streams.push({
        provider: 'Google Drive (Direct Bot Link)',
        type: 'direct_bot_stream',
        url: directBotUrl,
      });
    }

    if (!seen.has(embedUrl)) {
      seen.add(embedUrl);
      streams.push({
        provider: 'Google Drive (Embed)',
        type: 'embed_player',
        url: embedUrl,
      });
    }
  });

  const okRuEmbeds = [...html.matchAll(/https?:\/\/(?:www\.)?ok\.ru\/videoembed\/[0-9]+/gi)];
  okRuEmbeds.forEach((m) => {
    const url = m[0];
    if (!seen.has(url)) {
      seen.add(url);
      streams.push({
        provider: 'OK.ru',
        type: 'embed_player',
        url: url,
      });
    }
  });

  const okM3u8Matches = [...html.matchAll(/https?:\\\/\\\/[^\s"'\\]+\.m3u8[^\s"'\\]*/gi)];
  okM3u8Matches.forEach((m) => {
    const url = m[0].replace(/\\/g, '');
    if (!seen.has(url)) {
      seen.add(url);
      streams.push({
        provider: 'OK.ru (Direct HLS Stream)',
        type: 'direct_hls',
        url: url,
      });
    }
  });

  const vkMatches = [...html.matchAll(/https?:\/\/(?:www\.)?vkvideo\.ru\/video_ext\.php[^\s"'\\]*/gi)];
  vkMatches.forEach((m) => {
    let url = m[0].replace(/\\u0026/g, '&').replace(/\\/g, '');
    if (!seen.has(url)) {
      seen.add(url);
      streams.push({
        provider: 'VK Video',
        type: 'embed_player',
        url: url,
      });
    }
  });

  const genericMatches = [...html.matchAll(/https?:\/\/[^"'\s\\]+\.(?:m3u8|mp4|webm)[^\s"'\\]*/gi)];
  genericMatches.forEach((m) => {
    const url = m[0].replace(/\\/g, '');
    if (!seen.has(url) && !url.includes('okcdn.ru')) {
      seen.add(url);
      streams.push({
        provider: getProviderName(url),
        type: 'direct_video',
        url: url,
      });
    }
  });

  const directBotLink =
    streams.find((s) => s.type === 'direct_bot_stream' || s.type === 'direct_hls' || s.type === 'direct_video')?.url ||
    streams[0]?.url ||
    null;

  return {
    direct_bot_link: directBotLink,
    streams: streams,
  };
}

function getProviderName(url) {
  if (url.includes('ok.ru') || url.includes('okcdn.ru')) return 'OK.ru';
  if (url.includes('vkvideo.ru') || url.includes('vk.com')) return 'VK Video';
  if (url.includes('drive.google.com') || url.includes('google.usercontent.com')) return 'Google Drive';
  if (url.includes('blogger.com') || url.includes('blogspot.com')) return 'Blogger';
  if (url.includes('dood')) return 'DoodStream';
  if (url.includes('streamtape')) return 'Streamtape';
  if (url.includes('filemoon')) return 'Filemoon';
  return 'Direct Video Stream';
}

export async function searchDongworld(query, page = 1) {
  const searchUrl = `${BASE_URL}/series?search=${encodeURIComponent(query)}&page=${page}`;
  const html = await fetchUrl(searchUrl);
  const items = parseSeriesCards(html);

  return {
    status: 'success',
    query: query,
    page: page,
    total_results: items.length,
    items: items,
  };
}

export async function getTopDongworld() {
  const html = await fetchUrl(BASE_URL);
  const items = parseSeriesCards(html);

  return {
    status: 'success',
    category: 'Top / Popular Donghua',
    total: items.length,
    items: items,
  };
}

export async function filterDongworld(filter = {}) {
  const params = new URLSearchParams();
  if (filter.type) params.append('type', filter.type);
  if (filter.status) params.append('status', filter.status);
  if (filter.genre) params.append('genre', filter.genre);
  if (filter.page) params.append('page', filter.page);

  const filterUrl = `${BASE_URL}/series?${params.toString()}`;
  const html = await fetchUrl(filterUrl);
  const items = parseSeriesCards(html);

  return {
    status: 'success',
    filters: filter,
    total_results: items.length,
    items: items,
  };
}

export async function getDetailDongworld(slugInput) {
  const slug = slugInput.replace(/,/g, '').trim();
  const seriesUrl = `${BASE_URL}/series/${slug}`;
  const html = await fetchUrl(seriesUrl);
  if (!html) return { status: 'error', message: 'Series not found' };

  const item = {
    title: formatTitle(slug),
    slug: slug,
    url: seriesUrl,
    thumbnail: null,
    description: null,
    status: html.toLowerCase().includes('completed') ? 'Completed' : 'Ongoing',
    total_episodes: 0,
    episodes: [],
  };

  const descMatch = html.match(/<meta\s+name="description"\s+content="([^"]+)"/i);
  if (descMatch) item.description = descMatch[1];

  const imgMatch = html.match(/\/api\/image\?path=([^\s\"\'&]+)/);
  if (imgMatch) item.thumbnail = `${BASE_URL}/api/image?path=${imgMatch[1]}`;

  const seenEpSlugs = new Set();

  const epMatches = [...html.matchAll(/{"id":\d+,"series_id":\d+,"episode_number":(\d+),"slug":"([^"]+)"/g)];
  epMatches.forEach((m) => {
    const epNum = parseInt(m[1], 10);
    const epSlug = m[2];
    if (!seenEpSlugs.has(epSlug)) {
      seenEpSlugs.add(epSlug);
      item.episodes.push({
        episode_number: epNum,
        title: `Episode ${epNum}`,
        slug: epSlug,
        url: `${BASE_URL}/watch/${epSlug}`,
      });
    }
  });

  const htmlEpMatches = [...html.matchAll(/href="\/watch\/([a-zA-Z0-9\-_]+)"/g)];
  htmlEpMatches.forEach((m) => {
    const epSlug = m[1];
    if (!seenEpSlugs.has(epSlug)) {
      seenEpSlugs.add(epSlug);
      const epNumMatch = epSlug.match(/-(\d+)$/);
      const epNum = epNumMatch ? parseInt(epNumMatch[1], 10) : item.episodes.length + 1;

      item.episodes.push({
        episode_number: epNum,
        title: `Episode ${epNum}`,
        slug: epSlug,
        url: `${BASE_URL}/watch/${epSlug}`,
      });
    }
  });

  item.total_episodes = item.episodes.length;
  return { status: 'success', data: item };
}

export async function getStreamDongworld(slugInput, options = {}) {
  const slug = slugInput.replace(/,/g, '').trim();

  if (options.allEpisodes || (!slug.includes('-1') && !slug.match(/^[a-z0-9]{5}-/i))) {
    const detail = await getDetailDongworld(slug);
    if (detail.status === 'success' && detail.data.episodes.length > 0) {
      const episodesStreamData = [];
      for (const ep of detail.data.episodes) {
        const watchUrl = `${BASE_URL}/watch/${ep.slug}`;
        const html = await fetchUrl(watchUrl);
        const streamResult = extractAllStreamUrls(html);

        episodesStreamData.push({
          episode_number: ep.episode_number,
          episode_slug: ep.slug,
          direct_bot_link: streamResult.direct_bot_link,
          streams: streamResult.streams,
        });
      }

      return {
        status: 'success',
        series_title: detail.data.title,
        series_slug: slug,
        total_episodes: detail.data.episodes.length,
        episodes: episodesStreamData,
      };
    }
  }

  const watchUrl = `${BASE_URL}/watch/${slug}`;
  const html = await fetchUrl(watchUrl);
  if (!html) return { status: 'error', message: 'Episode page not found' };

  const streamResult = extractAllStreamUrls(html);

  return {
    status: 'success',
    episode_slug: slug,
    direct_bot_link: streamResult.direct_bot_link,
    streams: streamResult.streams,
  };
}

export async function scrapeDongworld(options = {}) {
  const maxSeries = options.maxSeries || 3;

  const resData = {
    status: 'success',
    source: BASE_URL,
    scraped_at: new Date().toISOString(),
    data: {
      items: [],
      stats: {},
    },
  };

  const homeHtml = await fetchUrl(BASE_URL);
  const seriesList = parseSeriesCards(homeHtml).slice(0, maxSeries);

  for (const s of seriesList) {
    const streamData = await getStreamDongworld(s.slug, { allEpisodes: true });
    if (streamData.status === 'success') {
      resData.data.items.push(streamData);
    }
  }

  resData.data.stats = {
    total_series: resData.data.items.length,
  };

  return resData;
}
