import axios from 'axios';

const USER_AGENTS = [
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
	'Mozilla/5.0 (Linux; Android 13; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
];

function pickUserAgent() {
	return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

function jitter(base, spread = 250) {
	return base + Math.floor(Math.random() * spread);
}

async function robustGet(url, { retries = 3, timeoutMs = 15000, responseType } = {}) {
	let lastError;

	for (let attempt = 0; attempt <= retries; attempt++) {
		try {
			const res = await axios.get(url, {
				timeout: timeoutMs,
				responseType,
				headers: {
					'User-Agent': pickUserAgent(),
					Accept: responseType === 'arraybuffer' ? 'image/*,*/*;q=0.8' : 'application/json,text/plain,*/*',
					'Accept-Language': 'en-US,en;q=0.9',
					Referer: 'https://emojikitchen.dev/',
				},
				validateStatus: (status) => status < 500 && status !== 429,
			});
			return res;
		} catch (err) {
			lastError = err;
			const status = err.response?.status;

			if (attempt < retries) {
				const backoff = jitter(500 * 2 ** attempt, 400);
				await sleep(backoff);
				continue;
			}
			if (status) lastError = new Error(`Request failed with status code ${status}`);
		}
	}

	throw lastError;
}

let metadataCache = null;
let metadataExpiry = 0;
const CACHE_TTL = 3600000; 

async function getMetadata() {
	if (metadataCache && Date.now() < metadataExpiry) return metadataCache;

	const res = await robustGet(
		'https://raw.githubusercontent.com/xsalazar/emoji-kitchen-backend/main/app/metadata.json'
	);
	metadataCache = res.data;
	metadataExpiry = Date.now() + CACHE_TTL;
	return metadataCache;
}

function toCodepoint(emoji) {
	const codes = [];
	for (const char of emoji) {
		const cp = char.codePointAt(0).toString(16);
		if (cp !== 'fe0f') codes.push(cp);
	}
	return codes.join('-');
}

async function emojiKitchen(emoji1, emoji2) {
	if (!emoji1 || !emoji2) {
		return { success: false, error: 'Parameter emoji1 dan emoji2 diperlukan' };
	}

	try {
		const metadata = await getMetadata();
		const data = metadata.data || {};
		const cp1 = toCodepoint(emoji1);
		const cp2 = toCodepoint(emoji2);

		let result = null;
		const leftData = data[cp1];
		if (leftData && leftData.combinations && leftData.combinations[cp2]) {
			const combos = leftData.combinations[cp2];
			result = combos[combos.length - 1];
		}

		if (!result) {
			const leftData2 = data[cp2];
			if (leftData2 && leftData2.combinations && leftData2.combinations[cp1]) {
				const combos = leftData2.combinations[cp1];
				result = combos[combos.length - 1];
			}
		}

		if (!result) {
			return { success: false, error: `Kombinasi ${emoji1} + ${emoji2} tidak ditemukan` };
		}

		return {
			success: true,
			emoji1: result.leftEmoji,
			emoji2: result.rightEmoji,
			name: result.alt,
			image: result.gStaticUrl,
		};
	} catch (error) {
		return { success: false, error: error.message };
	}
}

async function fetchEmojiImage(imageUrl) {
	const res = await robustGet(imageUrl, { responseType: 'arraybuffer', timeoutMs: 15000 });
	return Buffer.from(res.data);
}

export { emojiKitchen, fetchEmojiImage };