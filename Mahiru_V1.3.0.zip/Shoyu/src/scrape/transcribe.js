import axios from 'axios';
import dns from 'node:dns';

dns.setServers(['8.8.8.8', '1.1.1.1', '8.8.4.4']);

const USER_AGENTS = [
  'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
];

function randomUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function fetchRetry(config, retries = 3) {
  let lastErr;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await axios.request({
        ...config,
        headers: {
          'User-Agent': randomUA(),
          Accept: 'application/json',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate, br',
          DNT: '1',
          Connection: 'keep-alive',
          'Cache-Control': 'no-cache',
          Pragma: 'no-cache',
          ...config.headers,
        },
        validateStatus: () => true,
        decompress: true,
      });
      if (res.status === 429) {
        await sleep((i + 1) * 2000 + Math.random() * 1000);
        continue;
      }
      if (res.status >= 500) {
        await sleep(1500);
        continue;
      }
      return res;
    } catch (err) {
      lastErr = err;
      await sleep((i + 1) * 1500 + Math.random() * 1000);
    }
  }
  throw lastErr || new Error('Max retries exceeded');
}

class AudioTranscriber {
  constructor() {
    this.cookies = {};
    this.cookieHeader = '';
    this.transcriptionId = null;
    this.audioInfo = null;
    this.fileName = null;
    this.fileBuffer = null;
  }

  async initSession() {
    const res = await fetchRetry({
      method: 'GET',
      url: 'https://audio.com/transcription',
      headers: {
        authority: 'audio.com',
        accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'upgrade-insecure-requests': '1',
      },
    });

    const rawCookies = res.headers['set-cookie'] || [];
    this.cookieHeader = rawCookies.map((c) => c.split(';')[0]).join('; ');
    this.cookies = Object.fromEntries(
      this.cookieHeader.split('; ').map((c) => {
        const [name, value] = c.split('=');
        return [name, decodeURIComponent(value || '')];
      })
    );
  }

  getAnalyticsHeader() {
    return JSON.stringify({
      device_id: this.cookies['device-id'] || '',
      session_id: this.cookies['session-id'] || '',
      member_experiment_id: this.cookies['experiment_member_id'] || '',
    });
  }

  async requestUpload() {
    const res = await fetchRetry({
      method: 'POST',
      url: 'https://api.audio.com/audio',
      data: {
        mime: 'audio/mpeg',
        name: this.fileName,
        size: this.fileBuffer.length,
        category: 7,
        downloadable: false,
        options: { transcribe: true },
        method: 'PUT',
      },
      headers: {
        authority: 'api.audio.com',
        origin: 'https://audio.com',
        referer: 'https://audio.com/',
        'content-type': 'application/json',
        'x-analytics-context': this.getAnalyticsHeader(),
      },
    });

    this.audioInfo = res.data;
    this.transcriptionId = res.data?.extra?.audio?.id;
    if (!this.transcriptionId) throw new Error('Gagal mendapatkan transcription ID');
    return res.data;
  }

  async uploadFile() {
    await fetchRetry({
      method: 'PUT',
      url: this.audioInfo.url,
      data: this.fileBuffer,
      headers: {
        'Content-Type': 'audio/mpeg',
        'Content-Length': this.fileBuffer.length,
      },
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });
  }

  async notifyUploadSuccess() {
    await fetchRetry({
      method: 'POST',
      url: this.audioInfo.success,
      data: {},
      headers: {
        origin: 'https://audio.com',
        referer: 'https://audio.com/',
      },
    });
  }

  async checkTranscriptionStatus() {
    const res = await fetchRetry({
      method: 'GET',
      url: 'https://api.audio.com/audio',
      params: { id: this.transcriptionId },
      headers: {
        authority: 'api.audio.com',
        origin: 'https://audio.com',
        referer: 'https://audio.com/',
        'x-analytics-context': this.getAnalyticsHeader(),
      },
    });
    return res.data?.[0]?.transcribed || false;
  }

  async getTranscriptionText() {
    const res = await fetchRetry({
      method: 'GET',
      url: `https://api.audio.com/audio/${this.transcriptionId}/transcription`,
      headers: {
        authority: 'api.audio.com',
        origin: 'https://audio.com',
        referer: 'https://audio.com/',
        'x-analytics-context': this.getAnalyticsHeader(),
      },
    });
    return res.data;
  }

  async transcribeWithPolling(intervalMs = 5000, timeoutMs = 120000) {
    await this.initSession();
    await this.requestUpload();
    await this.uploadFile();
    await this.notifyUploadSuccess();

    const startTime = Date.now();

    return new Promise((resolve, reject) => {
      const poll = setInterval(async () => {
        try {
          if (Date.now() - startTime > timeoutMs) {
            clearInterval(poll);
            return reject(new Error('Timeout: Transcription took too long'));
          }

          const done = await this.checkTranscriptionStatus();
          if (done) {
            const result = await this.getTranscriptionText();
            const { text, language, error } = result;
            if (error && error.trim() !== '') {
              clearInterval(poll);
              return reject(new Error(`Transcription error: ${error}`));
            }
            if (text && text.trim() !== '' && language && language.trim() !== '') {
              clearInterval(poll);
              return resolve(result);
            }
          }
        } catch (err) {
          clearInterval(poll);
          reject(err);
        }
      }, intervalMs);
    });
  }

  async transcribeBuffer(buffer, fileName = `audio_${Date.now()}.mp3`) {
    this.fileName = fileName;
    this.fileBuffer = buffer;
    return this.transcribeWithPolling();
  }
}

export async function transcribeAudio(buffer, fileName) {
  const transcriber = new AudioTranscriber();
  return transcriber.transcribeBuffer(buffer, fileName);
}