import axios from 'axios';
import FormData from 'form-data';
import * as cheerio from 'cheerio';
import crypto from 'node:crypto';
import dns from 'node:dns';

// ─────────────────────────────────────────────
// Utilitas
// ─────────────────────────────────────────────

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36';

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function createJar() { return { store: {} }; }

function jarSave(jar, headers) {
  for (const item of headers['set-cookie'] || []) {
    const part = item.split(';')[0];
    const i = part.indexOf('=');
    if (i > -1) jar.store[part.slice(0, i).trim()] = part.slice(i + 1);
  }
}

function jarGet(jar) {
  return Object.entries(jar.store)
    .filter(([, v]) => v != null && String(v).length)
    .map(([k, v]) => `${k}=${v}`)
    .join('; ');
}

function commonHeaders(extra = {}) {
  return {
    'user-agent': UA,
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'x-request-id': crypto.randomUUID(),
    ...extra,
  };
}

function resolveUrl(path) {
  if (!path) return null;
  if (/^https?:\/\//i.test(path)) return path;
  return `https://www.tikwm.com${path}`;
}

// ─────────────────────────────────────────────
// Mobile API device spoof
// (adapted from tiktok.js 
// ─────────────────────────────────────────────

const MOBILE_DEVICE = {
  device_id:              '7318517321748022790',
  iid:                    '7318518857994389254',
  device_type:            'Pixel 7',
  device_brand:           'Google',
  os_version:             '13',
  os_api:                 '33',
  resolution:             '1080*2400',
  dpi:                    '420',
  version_code:           '350103',
  version_name:           '35.1.3',
  manifest_version_code:  '2023501030',
  update_version_code:    '2023501030',
  ab_version:             '35.1.3',
  channel:                'googleplay',
  build:                  'TQ3A.230901.001',
};

const MOBILE_UA = `com.zhiliaoapp.musically/${MOBILE_DEVICE.manifest_version_code} (Linux; U; Android ${MOBILE_DEVICE.os_version}; en_ID; ${MOBILE_DEVICE.device_type}; Build/${MOBILE_DEVICE.build}; Cronet/TTNetVersion:d0a7e9ec 2024-11-05 QuicVersion:ac6fdc24 2024-10-14)`;

const MOBILE_ENDPOINTS = [
  'https://api16-normal-c-useast1a.tiktokv.com/aweme/v1/feed/',
  'https://api19-normal-c-useast1a.tiktokv.com/aweme/v1/feed/',
  'https://api-h2.tiktokv.com/aweme/v1/feed/',
  'https://api.tiktokv.com/aweme/v1/feed/',
  'https://api16-normal-useast5.us.tiktokv.com/aweme/v1/feed/',
];

function extractAwemeId(url) {
  const m = url.match(/\/(?:video|photo|v)\/(\d+)/);
  return m ? m[1] : null;
}

async function resolveShortUrl(url) {
  const res = await axios.get(url, {
    headers: { 'user-agent': MOBILE_UA },
    maxRedirects: 10,
    timeout: 15000,
    validateStatus: () => true,
  });
  return res.request?.res?.responseUrl || res.config?.url || url;
}

function buildMobileParams(videoId) {
  return new URLSearchParams({
    aweme_id:               videoId,
    aid:                    '1233',
    app_name:               'musical_ly',
    device_platform:        'android',
    os:                     'android',
    ssmix:                  'a',
    device_type:            MOBILE_DEVICE.device_type,
    device_brand:           MOBILE_DEVICE.device_brand,
    os_version:             MOBILE_DEVICE.os_version,
    os_api:                 MOBILE_DEVICE.os_api,
    channel:                MOBILE_DEVICE.channel,
    version_code:           MOBILE_DEVICE.version_code,
    version_name:           MOBILE_DEVICE.version_name,
    manifest_version_code:  MOBILE_DEVICE.manifest_version_code,
    update_version_code:    MOBILE_DEVICE.update_version_code,
    ab_version:             MOBILE_DEVICE.ab_version,
    resolution:              MOBILE_DEVICE.resolution,
    dpi:                    MOBILE_DEVICE.dpi,
    device_id:              MOBILE_DEVICE.device_id,
    iid:                    MOBILE_DEVICE.iid,
    language:               'en',
    app_language:           'en',
    region:                 'SG',
    sys_region:              'SG',
    timezone_name:          'Asia/Jakarta',
    timezone_offset:        '25200',
    ac:                     'wifi',
    ac2:                    'wifi5g',
    is_pad:                 '0',
    app_type:               'normal',
    build_number:           MOBILE_DEVICE.version_name,
    last_install_time:      '1706000000',
    ts:                     Math.floor(Date.now() / 1000).toString(),
  });
}

async function fetchViaMobileApi(videoId) {
  const params = buildMobileParams(videoId);
  const headers = {
    'user-agent':     MOBILE_UA,
    accept:           'application/json',
    'accept-language':'en-US,en;q=0.9',
    connection:       'keep-alive',
    'x-gorgon':       '0404b0d30000',
    'x-khronos':      Math.floor(Date.now() / 1000).toString(),
    'x-argus':        '',
    'x-ladon':        '',
    'sdk-version':    '2',
    'passport-sdk-version': '19',
  };

  let lastErr = null;

  for (const endpoint of MOBILE_ENDPOINTS) {
    try {
      const res = await axios.get(`${endpoint}?${params}`, {
        headers, timeout: 15000, validateStatus: (s) => s < 500,
      });

      const data = res.data;
      if (typeof data !== 'object') { lastErr = new Error('MobileAPI: respons bukan JSON'); continue; }
      if (data.status_code !== 0) { lastErr = new Error(`MobileAPI: status_code ${data.status_code}`); continue; }

      const aweme = data.aweme_list?.[0];
      if (!aweme) { lastErr = new Error('MobileAPI: aweme_list kosong'); continue; }
      return aweme;
    } catch (err) {
      lastErr = err;
    }
  }

  throw lastErr ?? new Error('MobileAPI: semua endpoint gagal');
}

function pickBestVideoUrl(bitRates, fallbackVideo) {
  const sorted = [...(bitRates || [])].sort((a, b) => (b.bit_rate || 0) - (a.bit_rate || 0));
  let urls = [];
  for (const b of sorted) urls.push(...(b.play_addr?.url_list || []));
  if (!urls.length) {
    urls.push(...(fallbackVideo?.play_addr?.url_list || []));
    urls.push(...(fallbackVideo?.download_addr?.url_list || []));
  }
  urls = [...new Set(urls.filter((s) => typeof s === 'string' && s.startsWith('http')))];
  const getBt = (u) => { const m = u.match(/[&?]bt=(\d+)/); return m ? parseInt(m[1], 10) : 0; };
  return urls.sort((a, b) => getBt(b) - getBt(a));
}

function normalizeMobileItem(item) {
  const author = item.author || {};
  const music  = item.music || {};
  const stats  = item.statistics || {};
  const video  = item.video || {};
  const imagePost = item.image_post_info || null;

  const author_ = author.nickname || author.unique_id || null;
  const thumbnail = video.cover?.url_list?.[0] || video.origin_cover?.url_list?.[0] || null;
  const musicUrl = music.play_url?.url_list?.[0] || null;

  if (imagePost) {
    const images = (imagePost.images || [])
      .map((img) => img.display_image?.url_list?.at(-1) || img.display_image?.url_list?.[0])
      .filter(Boolean);
    if (!images.length) throw new Error('MobileAPI: tidak ada foto di slideshow');

    const links = images.map((u, i) => ({ text: `Foto ${i + 1}`, url: u }));
    if (musicUrl) links.push({ text: 'Music / Audio (MP3)', url: musicUrl });

    return {
      provider: 'mobileapi',
      type: 'slide',
      title: item.desc || null,
      author: author_,
      thumbnail,
      musicUrl,
      images,
      links,
    };
  }

  const videoUrls = pickBestVideoUrl(video.bit_rate, video);
  if (!videoUrls.length) throw new Error('MobileAPI: tidak ada URL video');

  const links = [{ text: 'No Watermark (HD)', url: videoUrls[0] }];
  if (videoUrls[1]) links.push({ text: 'No Watermark', url: videoUrls[1] });
  if (musicUrl) links.push({ text: 'Music / Audio (MP3)', url: musicUrl });

  return {
    provider: 'mobileapi',
    type: 'video',
    title: item.desc || null,
    author: author_,
    thumbnail,
    musicUrl,
    images: [],
    links,
  };
}

async function fromMobileApi(url) {
  let resolved = url;
  if (/vt\.|vm\.|\/\/t\.tiktok/.test(url)) resolved = await resolveShortUrl(url);

  const videoId = extractAwemeId(resolved);
  if (!videoId) throw new Error('MobileAPI: tidak bisa ekstrak video ID dari URL');

  const aweme = await fetchViaMobileApi(videoId);
  return normalizeMobileItem(aweme);
}

// ─────────────────────────────────────────────
// PROVIDER 1: TikWM
// ─────────────────────────────────────────────

async function fromTikwm(url) {
  const res = await axios.post('https://www.tikwm.com/api/',
    new URLSearchParams({ url, count: '12', cursor: '0', web: '1', hd: '1' }), {
      timeout: 30000, validateStatus: () => true,
      headers: commonHeaders({ 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json' }),
    }
  );

  const d = res.data?.data;
  if (!d) throw new Error('TikWM: tidak ada data');

  const musicUrl = resolveUrl(d.music_info?.play || d.music);

  if (Array.isArray(d.images) && d.images.length > 0) {
    const imageUrls = d.images.map((img) =>
      resolveUrl(typeof img === 'string' ? img : img?.url || img?.no_watermark || null)
    ).filter(Boolean);

    if (!imageUrls.length) throw new Error('TikWM: tidak ada foto di post slide');

    const slideVideoUrl = resolveUrl(d.hdplay || d.play);
    const liveImages = Array.isArray(d.live_images) ? d.live_images : [];

    const slideItems = imageUrls.map((imgUrl, i) => {
      const liveUrl = resolveUrl(liveImages[i] || null);
      return liveUrl ? { type: 'video', url: liveUrl } : { type: 'image', url: imgUrl };
    });

    const links = slideItems.map((it, i) => ({
      text: it.type === 'video' ? `Foto Live ${i + 1}` : `Foto ${i + 1}`,
      url: it.url,
    }));
    if (slideVideoUrl) links.push({ text: 'Video Slide (gabungan)', url: slideVideoUrl });
    if (musicUrl) links.push({ text: 'Music / Audio (MP3)', url: musicUrl });

    return {
      provider: 'tikwm',
      type: 'slide',
      title: d.title || null,
      author: d.author?.nickname || d.author?.unique_id || null,
      thumbnail: d.cover || d.origin_cover || null,
      musicUrl,
      slideVideoUrl,
      slideItems,
      images: imageUrls,
      links,
    };
  }

  if (!d.play) throw new Error('TikWM: tidak ada link download');

  const links = [
    { text: 'No Watermark (HD)', url: resolveUrl(d.hdplay || d.play) },
    { text: 'No Watermark', url: resolveUrl(d.play) },
  ];
  if (d.wmplay) links.push({ text: 'With Watermark', url: resolveUrl(d.wmplay) });
  if (musicUrl) links.push({ text: 'Music / Audio (MP3)', url: musicUrl });

  return {
    provider: 'tikwm',
    type: 'video',
    title: d.title || null,
    author: d.author?.nickname || d.author?.unique_id || null,
    thumbnail: d.cover || d.origin_cover || null,
    musicUrl,
    images: [],
    links,
  };
}

// ─────────────────────────────────────────────
// PROVIDER 2: SSSTik (fallback)
// ─────────────────────────────────────────────

async function fromSsstik(url) {
  const BASE = 'https://ssstik.io';
  const jar = createJar();

  const home = await axios.get(`${BASE}/en`, {
    timeout: 20000, validateStatus: () => true,
    headers: commonHeaders({ accept: 'text/html,*/*', 'sec-fetch-mode': 'navigate' }),
  });
  jarSave(jar, home.headers);

  const $ = cheerio.load(String(home.data || ''));
  const token = $('input[name="token"]').attr('value') || '';

  const form = new FormData();
  form.append('id', url);
  form.append('locale', 'en');
  form.append('tt', token);

  const res = await axios.post(`${BASE}/abc?url=dl`, form, {
    timeout: 60000, validateStatus: () => true,
    headers: { ...commonHeaders({ accept: '*/*', origin: BASE, referer: `${BASE}/en`, cookie: jarGet(jar) }), ...form.getHeaders() },
  });
  if (res.status !== 200) throw new Error(`SSSTik: submit gagal (code: ${res.status})`);

  const $r = cheerio.load(String(res.data || ''));
  const links = [];
  $r('a[href]').each((_, el) => {
    const href = $r(el).attr('href');
    const text = $r(el).text().trim().replace(/\s+/g, ' ');
    if (!href || href === '#' || href === '/') return;
    links.push({ text: text || 'Download', url: href });
  });
  if (!links.length) throw new Error('SSSTik: tidak ada link download');

  const isImageLink = (l) =>
    /photo|image|picture|slide/i.test(l.text) ||
    /\.(jpe?g|png|webp)(\?|$)/i.test(l.url);
  const isMusicLink = (l) => /mp3|music|audio|sound/i.test(l.text);

  const imageLinks = links.filter(isImageLink);
  const musicLink = links.find(isMusicLink);
  const isSlide = imageLinks.length > 0;

  return {
    provider: 'ssstik',
    type: isSlide ? 'slide' : 'video',
    title: $r('.mainWrap h2').first().text().trim() || null,
    author: $r('.mainWrap .author').first().text().trim() || null,
    thumbnail: $r('.mainWrap img').first().attr('src') || null,
    musicUrl: musicLink?.url || null,
    images: imageLinks.map((l) => l.url),
    links,
  };
}

// ─────────────────────────────────────────────
// PROVIDER 3: tiktokdl.web.id (fallback tambahan)
// ─────────────────────────────────────────────

function b64ToUrl(b64) {
  if (!b64 || typeof b64 !== 'string') return null;
  try {
    const decoded = Buffer.from(b64, 'base64').toString('utf-8');
    return /^https?:\/\//i.test(decoded) ? decoded : null;
  } catch {
    return null;
  }
}

async function fromTiktokdlWebId(url) {
  let res;
  try {
    res = await axios.get('https://www.tiktokdl.web.id/api/tiktok', {
      params: { url },
      timeout: 30000, validateStatus: () => true,
      headers: commonHeaders({ accept: 'application/json' }),
    });
  } catch (err) {
    throw new Error(`tiktokdl.web.id: request gagal (${err.code || err.message})`);
  }

  const d = res.data;
  if (!d || typeof d !== 'object') throw new Error(`tiktokdl.web.id: response bukan JSON (status ${res.status})`);
  if (d.status !== true) throw new Error(`tiktokdl.web.id: status false — ${d.message || d.error || 'tidak ada keterangan'}`);

  const author = typeof d.author === 'string' ? d.author : (d.author?.nickname || d.author?.unique_id || null);
  const musicUrl = b64ToUrl(d.audioId);

  // ── SLIDE / FOTO ──
  if (d.isSlide) {
    const imageUrls = Array.isArray(d.imageUrls) ? d.imageUrls.filter(Boolean) : [];
    if (!imageUrls.length) throw new Error('tiktokdl.web.id: isSlide true tapi imageUrls kosong');

    const links = imageUrls.map((u, i) => ({ text: `Foto ${i + 1}`, url: u }));
    if (musicUrl) links.push({ text: 'Music / Audio (MP3)', url: musicUrl });

    return {
      provider: 'tiktokdlwebid',
      type: 'slide',
      title: d.description || null,
      author,
      thumbnail: null,
      musicUrl,
      images: imageUrls,
      links,
    };
  }

  // ── VIDEO BIASA ──
  const videoUrl = b64ToUrl(d.videoId);
  if (!videoUrl) throw new Error('tiktokdl.web.id: videoId kosong/gagal di-decode');

  const links = [{ text: 'No Watermark', url: videoUrl }];
  if (musicUrl) links.push({ text: 'Music / Audio (MP3)', url: musicUrl });

  return {
    provider: 'tiktokdlwebid',
    type: 'video',
    title: d.description || null,
    author,
    thumbnail: null,
    musicUrl,
    images: [],
    links,
  };
}

// ─────────────────────────────────────────────
// PROVIDER 4: tiktokdownloaderr.id
// ─────────────────────────────────────────────

dns.setServers(['8.8.8.8', '1.1.1.1', '8.8.4.4']);

const TDL_UAS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
];

function randTdlUA() {
  return TDL_UAS[Math.floor(Math.random() * TDL_UAS.length)];
}

class TdlCookieJar {
  constructor() { this.store = new Map(); }
  set(h) {
    if (!h) return;
    for (const c of (Array.isArray(h) ? h : [h])) {
      const [kv] = c.split(';');
      const [k, v] = kv.trim().split('=');
      if (k) this.store.set(k.trim(), v || '');
    }
  }
  get() {
    return Array.from(this.store.entries()).map(([k, v]) => `${k}=${v}`).join('; ');
  }
}

function buildTdlAxios(jar) {
  return axios.create({
    timeout: 30000,
    maxRedirects: 10,
    headers: {
      'User-Agent': randTdlUA(),
      Accept: 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      Origin: 'https://tiktokdownloaderr.id',
      Referer: 'https://tiktokdownloaderr.id/',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
      DNT: '1',
      Connection: 'keep-alive',
      'Cache-Control': 'no-cache',
      Pragma: 'no-cache',
      'X-Requested-With': 'XMLHttpRequest',
      ...(jar.get() ? { Cookie: jar.get() } : {}),
    },
    validateStatus: () => true,
    decompress: true,
  });
}

async function fetchTdlWithRetry(instance, cfg, retries = 3) {
  let last;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await instance.request(cfg);
      if (res.status === 429) {
        await sleep((i + 1) * 2000 + Math.random() * 1000);
        continue;
      }
      if (res.status >= 500) {
        await sleep(1500);
        continue;
      }
      return res;
    } catch (e) {
      last = e;
      await sleep((i + 1) * 1500 + Math.random() * 1000);
    }
  }
  throw last || new Error('Max retries exceeded');
}

async function fromTiktokdownloaderr(url) {
  let checkUrl = url;
  if (/vt\.|vm\.|\/\/t\.tiktok/.test(url)) {
    try {
      checkUrl = await resolveShortUrl(url);
    } catch {
    }
  }
  if (/\/photo\//i.test(checkUrl)) {
    throw new Error('tiktokdownloaderr: tidak mendukung slide foto, dialihkan ke provider lain');
  }

  const jar = new TdlCookieJar();
  const instance = buildTdlAxios(jar);

  try {
    const land = await fetchTdlWithRetry(instance, { method: 'GET', url: 'https://tiktokdownloaderr.id/' });
    jar.set(land.headers['set-cookie']);
  } catch {
  }

  const res = await fetchTdlWithRetry(instance, {
    method: 'POST',
    url: 'https://tiktokdownloaderr.id/api/downloader.php',
    data: new URLSearchParams({ url: url.trim() }),
  });

  if (res.status !== 200) throw new Error(`tiktokdownloaderr: API HTTP ${res.status}`);

  const d = res.data;
  if (!d || typeof d !== 'object') throw new Error('tiktokdownloaderr: response bukan JSON');
  if (!d.success) throw new Error(`tiktokdownloaderr: ${d.message || 'gagal ambil data video'}`);

  const looksLikeSlide =
    (Array.isArray(d.images) && d.images.length > 0) ||
    (Array.isArray(d.photos) && d.photos.length > 0);
  if (looksLikeSlide) {
    throw new Error('tiktokdownloaderr: post ini slide foto, dialihkan ke provider lain');
  }

  const noWatermark = d.video_nowm || d.video || d.download_url || null;
  const watermark = d.video_wm || null;
  if (!noWatermark && !watermark) {
    throw new Error('tiktokdownloaderr: tidak ada link video di response (kemungkinan post foto/slide)');
  }

  const links = [];
  if (noWatermark) links.push({ text: 'No Watermark', url: noWatermark });
  if (watermark) links.push({ text: 'With Watermark', url: watermark });
  if (d.audio || d.music) links.push({ text: 'Music / Audio (MP3)', url: d.audio || d.music });

  return {
    provider: 'tiktokdownloaderr',
    type: 'video',
    title: d.title || null,
    author: d.author || null,
    thumbnail: d.cover || d.thumbnail || null,
    musicUrl: d.audio || d.music || null,
    images: [],
    links,
  };
}

// ─────────────────────────────────────────────
// PROVIDER 5: viesnap.com 
// ─────────────────────────────────────────────

const VSN_UAS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
];

function randVsnUA() {
  return VSN_UAS[Math.floor(Math.random() * VSN_UAS.length)];
}

class VsnCookieJar {
  constructor() { this.store = new Map(); }
  set(header) {
    if (!header) return;
    for (const c of (Array.isArray(header) ? header : [header])) {
      const [kv] = c.split(';');
      const [name, val] = kv.trim().split('=');
      if (name) this.store.set(name.trim(), val || '');
    }
  }
  get() {
    return Array.from(this.store.entries()).map(([k, v]) => `${k}=${v}`).join('; ');
  }
}

function buildVsnAxios(jar) {
  return axios.create({
    timeout: 30000,
    maxRedirects: 10,
    headers: {
      'User-Agent': randVsnUA(),
      Accept: 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Content-Type': 'application/json',
      Origin: 'https://viesnap.com',
      Referer: 'https://viesnap.com/',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-site',
      DNT: '1',
      Connection: 'keep-alive',
      'Cache-Control': 'no-cache',
      Pragma: 'no-cache',
      'X-Requested-With': 'XMLHttpRequest',
      ...(jar.get() ? { Cookie: jar.get() } : {}),
    },
    validateStatus: () => true,
    decompress: true,
  });
}

async function fetchVsnWithRetry(instance, config, retries = 3) {
  let lastErr;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await instance.request(config);
      if (res.status === 429) {
        await sleep((i + 1) * 2000 + Math.random() * 1000);
        continue;
      }
      if (res.status >= 500) {
        await sleep(1500);
        continue;
      }
      return res;
    } catch (err) {
      lastErr = err;
      await sleep((i + 1) * 1500 + Math.random() * 1000);
    }
  }
  throw lastErr || new Error('Max retries exceeded');
}

function pickBestVsnVideo(q) {
  if (!q || typeof q !== 'object') return null;
  for (const p of ['best', 'hd', 'sd', 'watermark']) {
    if (q[p]?.cdn_url) return { ...q[p], qualityLabel: p };
  }
  for (const [k, v] of Object.entries(q)) {
    if (k === 'audio') continue;
    if (v?.cdn_url) return { ...v, qualityLabel: k };
  }
  return null;
}

async function fromViesnap(url) {
  if (!url || !/tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(url)) {
    throw new Error('viesnap: link TikTok tidak valid');
  }

  const jar = new VsnCookieJar();
  const instance = buildVsnAxios(jar);

  try {
    const landing = await fetchVsnWithRetry(instance, { method: 'GET', url: 'https://viesnap.com/' });
    jar.set(landing.headers['set-cookie']);
  } catch {
  }

  const infoRes = await fetchVsnWithRetry(instance, {
    method: 'POST',
    url: 'https://api.viesnap.com/info',
    data: { url: url.trim() },
  });

  if (infoRes.status !== 200) throw new Error(`viesnap: Info API HTTP ${infoRes.status}`);
  const info = infoRes.data;
  if (!info || info.error) throw new Error(`viesnap: ${info?.message || 'gagal ambil data video'}`);

  const audioUrl = info.qualities?.audio?.cdn_url || null;
  const author = info.author || null;
  const title = info.title || info.description || null;
  const thumbnail = info.thumbnail || null;

  const isSlide = Array.isArray(info.images) && info.images.length > 0;

  if (isSlide) {
    const images = info.images
      .map((img) => (typeof img === 'string' ? img : img?.cdn_url || img?.url || img?.display_url))
      .filter(Boolean);
    if (!images.length) throw new Error('viesnap: tidak ada foto di slideshow');

    const links = images.map((u, i) => ({ text: `Foto ${i + 1}`, url: u }));
    if (audioUrl) links.push({ text: 'Music / Audio (MP3)', url: audioUrl });

    fetchVsnWithRetry(instance, {
      method: 'POST',
      url: 'https://api.viesnap.com/stats/download',
      data: { platform: 'tiktok', source: 'hybrid', outcome: 'finished', kind: 'slide', bytes_sent: 0, duration_ms: 0 },
    }).catch(() => {});

    return {
      provider: 'viesnap',
      type: 'slide',
      title,
      author,
      thumbnail,
      musicUrl: audioUrl,
      images,
      links,
    };
  }

  const best = pickBestVsnVideo(info.qualities);
  if (!best?.cdn_url) throw new Error('viesnap: tidak ada link download video');

  fetchVsnWithRetry(instance, {
    method: 'POST',
    url: 'https://api.viesnap.com/stats/download',
    data: {
      platform: 'tiktok',
      source: 'hybrid',
      outcome: 'finished',
      kind: info.type || 'video',
      bytes_sent: best.filesize || 0,
      duration_ms: Math.floor((info.duration || 0) * 1000) || 2500,
    },
  }).catch(() => {});

  const watermarkUrl = info.qualities?.watermark?.cdn_url || null;
  const links = [{ text: 'No Watermark', url: best.cdn_url }];
  if (watermarkUrl && watermarkUrl !== best.cdn_url) links.push({ text: 'With Watermark', url: watermarkUrl });
  if (audioUrl) links.push({ text: 'Music / Audio (MP3)', url: audioUrl });

  return {
    provider: 'viesnap',
    type: 'video',
    title,
    author,
    thumbnail,
    musicUrl: audioUrl,
    images: [],
    links,
  };
}

// ─────────────────────────────────────────────
// Fallback chain
// ─────────────────────────────────────────────

const PROVIDERS = [
  { name: 'tiktokdownloaderr',  run: fromTiktokdownloaderr  },
  { name: 'mobileapi',          run: fromMobileApi          },
  { name: 'viesnap',            run: fromViesnap            },
  { name: 'tiktokdlwebid',      run: fromTiktokdlWebId      },
  { name: 'tikwm',              run: fromTikwm              },
  { name: 'ssstik',             run: fromSsstik             },
];

export async function downloadTiktok(url) {
  if (!url || !/tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(url)) {
    throw new Error('Link TikTok tidak valid');
  }

  let tikwmResult = null;
  let tikwmError = null;
  try {
    tikwmResult = await fromTikwm(url);
  } catch (err) {
    tikwmError = err;
  }

  const isSlideWithLivePhoto =
    tikwmResult?.type === 'slide' && tikwmResult.slideItems?.some((it) => it.type === 'video');

  if (isSlideWithLivePhoto) {
    tikwmResult.provider = 'tikwm';
    console.log('[TIKTOK DL] Provider dipakai: tikwm');
    return tikwmResult;
  }

  const errors = [];
  for (const provider of PROVIDERS) {
    try {
    
      const result =
        provider.name === 'tikwm'
          ? (tikwmError ? (() => { throw tikwmError; })() : tikwmResult)
          : await provider.run(url);

      if (!result?.links?.length) throw new Error('Tidak ada link download');
      result.provider = provider.name;
      console.log(`[TIKTOK DL] Provider dipakai: ${provider.name}`);
      return result;
    } catch (err) {
      errors.push(`${provider.name}: ${err.message}`);
      await sleep(300);
    }
  }
  throw new Error(`Semua provider gagal.\n- ${errors.join('\n- ')}`);
}