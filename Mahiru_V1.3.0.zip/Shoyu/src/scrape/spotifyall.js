import * as cheerio from 'cheerio';
import axios from 'axios';
import crypto from 'crypto';

// ─────────────────────────────────────────────
// Konstanta & Utilitas
// ─────────────────────────────────────────────

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36';

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function safeName(name) {
  return String(name || 'spotify-audio.mp3')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 180);
}

function formatBytes(bytes) {
  if (!bytes || Number.isNaN(Number(bytes))) return null;
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = Number(bytes);
  let i = 0;
  while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
  return `${value.toFixed(i === 0 ? 0 : 2)} ${units[i]}`;
}

export function formatDuration(ms) {
  if (!Number.isFinite(ms)) return null;
  const total = Math.floor(ms / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function extractTrackId(input) {
  const s = String(input || '').trim();
  if (/^[a-zA-Z0-9]{22}$/.test(s)) return s;
  const m = s.match(/track\/([a-zA-Z0-9]{22})/);
  return m ? m[1] : null;
}

export function extractTrackUrl(input) {
  const s = String(input || '').trim();
  const id = extractTrackId(s);
  if (id) return `https://open.spotify.com/track/${id}`;
  return null;
}

// ─────────────────────────────────────────────
// Session / Cookie helpers (shared)
// ─────────────────────────────────────────────

function createSession(defaults = {}) {
  return { cookieStore: { ...defaults } };
}

function cookieHeader(session) {
  return Object.entries(session.cookieStore)
    .filter(([, v]) => v !== undefined && v !== null && String(v).length)
    .map(([k, v]) => `${k}=${v}`)
    .join('; ');
}

function splitSetCookie(value) {
  if (!value) return [];
  return value.split(/,(?=\s*[^;,=\s]+=[^;,]+)/g);
}

function saveCookies(session, headers) {
  const raw = typeof headers.getSetCookie === 'function'
    ? headers.getSetCookie()
    : splitSetCookie(headers.get('set-cookie'));
  for (const item of raw) {
    const part = item.split(';')[0];
    const i = part.indexOf('=');
    if (i > -1) session.cookieStore[part.slice(0, i)] = part.slice(i + 1);
  }
}

// ─────────────────────────────────────────────
// PROVIDER 0: Spotidown 
// ─────────────────────────────────────────────

async function spotidownResolve(session, query) {
  const { dynamicName, dynamicValue } = await spotidownGetSession(session);

  const payload = new URLSearchParams({ url: query, 'g-recaptcha-response': '' });
  if (dynamicName) payload.set(dynamicName, dynamicValue);

  const res = await fetch(`${SPOTIDOWN_BASE}/action`, {
    method: 'POST',
    headers: {
      'user-agent': UA,
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      origin: SPOTIDOWN_BASE,
      referer: `${SPOTIDOWN_BASE}/en3`,
      'x-requested-with': 'XMLHttpRequest',
      cookie: cookieHeader(session),
    },
    body: payload.toString(),
    signal: AbortSignal.timeout(30000),
  });
  saveCookies(session, res.headers);

  const body = await res.json().catch(() => null);
  if (!body) throw new Error('Spotidown: response bukan JSON valid');
  if (body.error) throw new Error(`Spotidown: ${body.message || 'lookup gagal'}`);

  const $ = cheerio.load(body.data || '');
  const tracks = [];

  $('form[name="submitspurl"]').each((i, formElem) => {
    const f = $(formElem);
    const data = f.find('input[name="data"]').val();
    const base = f.find('input[name="base"]').val();
    const token = f.find('input[name="token"]').val();
    if (!data || !base || !token) return;

    let metadata = null;
    try {
      metadata = JSON.parse(Buffer.from(data, 'base64').toString('utf8'));
    } catch {
      return;
    }
    if (!metadata) return;

    tracks.push({ metadata, form: { data, base, token } });
  });

  return tracks;
}

async function spotidownGetDownloadLinks(session, form) {
  const res = await fetch(`${SPOTIDOWN_BASE}/action/track`, {
    method: 'POST',
    headers: {
      'user-agent': UA,
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      origin: SPOTIDOWN_BASE,
      referer: `${SPOTIDOWN_BASE}/en3`,
      'x-requested-with': 'XMLHttpRequest',
      cookie: cookieHeader(session),
    },
    body: new URLSearchParams(form).toString(),
    signal: AbortSignal.timeout(30000),
  });
  saveCookies(session, res.headers);

  const body = await res.json().catch(() => null);
  if (!body) throw new Error('Spotidown: response link bukan JSON valid');
  if (body.error) throw new Error(`Spotidown: ${body.message || 'gagal ambil link download'}`);

  const $ = cheerio.load(body.data || '');
  let mp3 = null;
  let cover = null;

  $('a').each((i, el) => {
    const href = $(el).attr('href');
    const text = $(el).text().trim().toLowerCase();
    if (!href) return;
    if (text.includes('download mp3')) mp3 = href;
    else if (text.includes('download cover')) cover = href;
  });

  return { mp3, cover };
}

async function fromSpotidown(trackUrl) {
  const session = createSession();
  const tracks = await spotidownResolve(session, trackUrl);
  if (!tracks.length) throw new Error('Spotidown: track tidak ditemukan');

  const { metadata, form } = tracks[0];
  const { mp3, cover } = await spotidownGetDownloadLinks(session, form);
  if (!mp3) throw new Error('Spotidown: link MP3 tidak ditemukan');

  const audioRes = await fetch(mp3, {
    headers: { 'user-agent': UA, cookie: cookieHeader(session) },
    signal: AbortSignal.timeout(60000),
  });
  if (!audioRes.ok) throw new Error(`Spotidown: gagal download audio (code: ${audioRes.status})`);

  const buffer = Buffer.from(await audioRes.arrayBuffer());
  if (!buffer.length) throw new Error('Spotidown: buffer audio kosong');

  return {
    buffer,
    filename: safeName(`${metadata.artist || 'Spotify'} - ${metadata.name || 'audio'} (SPOTIDOWN).mp3`),
    title: metadata.name || null,
    artists: metadata.artist ? [metadata.artist] : [],
    album: metadata.album || null,
    durationMs: metadata.duration || null,
    releaseDate: metadata.date || null,
    cover: metadata.cover || cover || null,
    externalUrl: metadata.tid ? `https://open.spotify.com/track/${metadata.tid}` : trackUrl,
    size: formatBytes(buffer.length),
    contentType: audioRes.headers.get('content-type') || 'audio/mpeg',
  };
}

// ─────────────────────────────────────────────
// Fallback chain
// ─────────────────────────────────────────────

const PROVIDERS = [
  { name: 'spotidown',  run: fromSpotidown  },
];

function mergeWithOfficial(result, official, trackUrl) {
  const title = official?.title || result.title || 'Spotify Audio';
  const artists = official?.artists?.length ? official.artists : (result.artists || []);
  const artistLabel = artists.length ? artists.join(', ') : 'Spotify';
  return {
    ...result, title, artists,
    album: official?.album || result.album || null,
    durationMs: official?.durationMs || result.durationMs || null,
    releaseDate: official?.releaseDate || result.releaseDate || null,
    cover: official?.cover || result.cover || null,
    externalUrl: official?.externalUrl || result.externalUrl || trackUrl,
    filename: safeName(`${artistLabel} - ${title}.mp3`),
  };
}

export async function downloadSpotifyAny(input) {
  const trackUrl = extractTrackUrl(input);
  if (!trackUrl) throw new Error('Link Spotify tidak valid (harus open.spotify.com/track/... atau ID 22 karakter)');

  const errors = [];

  for (const provider of PROVIDERS) {
    try {
      const result = await provider.run(trackUrl);
      if (!result?.buffer?.length) throw new Error('Buffer audio kosong');
      const merged = mergeWithOfficial(result, null, trackUrl);
      merged.provider = provider.name;
      console.log(`[SPOTIFY DL] Provider dipakai: ${provider.name}`);
      return merged;
    } catch (err) {
      errors.push(`${provider.name}: ${err.message}`);
      await sleep(300);
    }
  }

  throw new Error(`Semua provider gagal.\n- ${errors.join('\n- ')}`);
}

// ─────────────────────────────────────────────
// SEARCH PROVIDER 1: Spotify Official (Web Player, TOTP)
// ─────────────────────────────────────────────

const SPOTIFY_TOTP_SECRET = '376136387538459893883312310911992847112448894410210511297108';
const SPOTIFY_TOTP_VERSION = 61;
const SPOTIFY_CLIENT_VERSION = '1.2.88.61.ge172202b';

function generateSpotifyTOTP(tsms = Date.now()) {
  const counter = Math.floor((tsms / 1000) / 30);
  const buffer = Buffer.alloc(8);
  buffer.writeBigInt64BE(BigInt(counter));

  const digest = crypto
    .createHmac('sha1', Buffer.from(SPOTIFY_TOTP_SECRET, 'utf8'))
    .update(buffer)
    .digest();

  const offset = digest[digest.length - 1] & 0xf;
  const code = (digest.readUInt32BE(offset) & 0x7fffffff) % 1000000;

  return String(code).padStart(6, '0');
}

function createSpotifyOfficialClient() {
  return axios.create({
    timeout: 30000,
    headers: {
      referer: 'https://open.spotify.com/',
      origin: 'https://open.spotify.com',
      accept: 'application/json',
      'content-type': 'application/json',
      'user-agent': UA,
    },
  });
}

async function getSpotifyOfficialToken(api) {
  if (api.defaults.headers.authorization) return;

  const sts = Math.floor(Date.now() / 1000);

  const { data: token } = await api.get('https://open.spotify.com/api/token', {
    params: {
      reason: 'init',
      productType: 'web-player',
      totp: generateSpotifyTOTP(Date.now()),
      totpServer: generateSpotifyTOTP(sts * 1000),
      totpVer: String(SPOTIFY_TOTP_VERSION),
    },
  });

  const { data: client } = await api.post('https://clienttoken.spotify.com/v1/clienttoken', {
    client_data: {
      client_version: SPOTIFY_CLIENT_VERSION,
      client_id: token.clientId,
      js_sdk_data: {
        device_brand: 'unknown',
        device_model: 'unknown',
        os: 'linux',
        os_version: '24.04',
        device_id: crypto.randomUUID(),
        device_type: 'computer',
      },
    },
  });

  Object.assign(api.defaults.headers, {
    'accept-language': 'en',
    'app-platform': 'WebPlayer',
    authorization: `Bearer ${token.accessToken}`,
    'client-token': client.granted_token.token,
    'spotify-app-version': SPOTIFY_CLIENT_VERSION,
  });
}

async function spotifyOfficialQuery(api, operationName, sha256Hash, variables) {
  await getSpotifyOfficialToken(api);

  const { data } = await api.post('https://api-partner.spotify.com/pathfinder/v2/query', {
    variables,
    operationName,
    extensions: { persistedQuery: { version: 1, sha256Hash } },
  });

  return data;
}

async function searchViaSpotifyOfficial(query, limit) {
  const api = createSpotifyOfficialClient();

  const data = await spotifyOfficialQuery(
    api,
    'searchDesktop',
    '21b3fe49546912ba782db5c47e9ef5a7dbd20329520ba0c7d0fcfadee671d24e',
    {
      searchTerm: query,
      offset: 0,
      limit,
      numberOfTopResults: 5,
      includeAudiobooks: true,
      includeArtistHasConcertsField: false,
      includePreReleases: true,
      includeAuthors: false,
      includeEpisodeContentRatingsV2: false,
    }
  );

  const search = data?.data?.searchV2;
  const tracks =
    search?.tracksV2?.items ||
    search?.topResultsV2?.itemsV2?.filter((v) => v.item?.__typename === 'TrackResponseWrapper') ||
    [];

  const items = tracks
    .map((node) => node.item?.data || node.data)
    .filter(Boolean)
    .map((t) => {
      const id = t.uri?.split(':')?.[2];
      const artists = (t.artists?.items || []).map((v) => v.profile?.name).filter(Boolean);
      const images = t.albumOfTrack?.coverArt?.sources || [];
      return {
        title: t.name || null,
        artists: artists.length ? artists.join(', ') : '-',
        link: id ? `https://open.spotify.com/track/${id}` : null,
        cover: images[0]?.url || images[images.length - 1]?.url || null,
        duration: formatDuration(t.duration?.totalMilliseconds || 0),
      };
    })
    .filter((t) => t.title && t.link);

  if (!items.length) throw new Error('Spotify Official: hasil kosong');
  return items.slice(0, limit);
}

// ─────────────────────────────────────────────
// SEARCH PROVIDER 2: Spotidown 
// ─────────────────────────────────────────────

const SPOTIDOWN_BASE = 'https://spotidown.app';

async function spotidownGetSession(session) {
  const res = await fetch(`${SPOTIDOWN_BASE}/en3`, {
    headers: {
      'user-agent': UA,
      accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
      'accept-language': 'en-US,en;q=0.9',
    },
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`Spotidown: gagal buka halaman (code: ${res.status})`);
  saveCookies(session, res.headers);

  const $ = cheerio.load(await res.text());
  const form = $('form[name="spotifyurl"]');
  if (!form.length) throw new Error('Spotidown: form pencarian tidak ditemukan');

  let dynamicName = '';
  let dynamicValue = '';
  form.find('input[type="hidden"]').each((i, elem) => {
    const name = $(elem).attr('name');
    const val = $(elem).attr('value');
    if (name && name !== 'g-recaptcha-response') {
      dynamicName = name;
      dynamicValue = val;
    }
  });

  return { dynamicName, dynamicValue };
}

async function searchViaSpotidown(query, limit) {
  const session = createSession();
  const { dynamicName, dynamicValue } = await spotidownGetSession(session);

  const payload = new URLSearchParams({ url: query, 'g-recaptcha-response': '' });
  if (dynamicName) payload.set(dynamicName, dynamicValue);

  const res = await fetch(`${SPOTIDOWN_BASE}/action`, {
    method: 'POST',
    headers: {
      'user-agent': UA,
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      origin: SPOTIDOWN_BASE,
      referer: `${SPOTIDOWN_BASE}/en3`,
      'x-requested-with': 'XMLHttpRequest',
      cookie: cookieHeader(session),
    },
    body: payload.toString(),
    signal: AbortSignal.timeout(30000),
  });
  saveCookies(session, res.headers);

  const body = await res.json().catch(() => null);
  if (!body) throw new Error('Spotidown: response bukan JSON valid');
  if (body.error) throw new Error(`Spotidown: ${body.message || 'lookup gagal'}`);

  const $ = cheerio.load(body.data || '');
  const items = [];

  $('form[name="submitspurl"]').each((i, formElem) => {
    if (items.length >= limit) return;
    const f = $(formElem);
    const data = f.find('input[name="data"]').val();
    if (!data) return;

    let metadata = null;
    try {
      metadata = JSON.parse(Buffer.from(data, 'base64').toString('utf8'));
    } catch {
      return;
    }
    if (!metadata) return;

    items.push({
      title: metadata.name || null,
      artists: metadata.artist || '-',
      link: metadata.tid ? `https://open.spotify.com/track/${metadata.tid}` : null,
      cover: metadata.cover || null,
      duration: metadata.duration || null,
    });
  });

  const filtered = items.filter((t) => t.title && t.link);
  if (!filtered.length) throw new Error('Spotidown: hasil kosong');
  return filtered.slice(0, limit);
}

const SEARCH_PROVIDERS = [
  { name: 'spotify-official', run: searchViaSpotifyOfficial },
  { name: 'spotidown',        run: searchViaSpotidown       },
];

export async function searchSpotify(query, limit = 10) {
  const q = String(query || '').trim();
  if (!q) throw new Error('Query pencarian kosong');

  const errors = [];

  for (const provider of SEARCH_PROVIDERS) {
    try {
      const items = await provider.run(q, limit);
      console.log(`[SPOTIFY SEARCH] Provider dipakai: ${provider.name}`);
      return items.map((it) => ({ ...it, provider: provider.name }));
    } catch (err) {
      errors.push(`${provider.name}: ${err.message}`);
    }
  }

  throw new Error(`Semua provider search gagal.\n- ${errors.join('\n- ')}`);
}