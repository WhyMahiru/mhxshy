import axios from 'axios';
import { webcrypto as crypto } from 'node:crypto';
import FormData from 'form-data';
import path from 'node:path';

const BASE_URL = 'https://imglarger.com';
const RESULT_PREFIX = 'https://access.imglarger.com/results/';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const TOOL_PROMPTS = {
  enhancer: 'preserve facial identity, preserve facial geometry, restore image clarity, enhance natural details, reduce blur and noise, preserve original colors and structure',
  enlarger: 'Upscale this image while preserving original details and texture.',
};

// ─────────────────────────────────────────────
// Enkripsi payload U2 (AES-256-GCM + PBKDF2)
// ─────────────────────────────────────────────

async function deriveU2Key() {
  const masterKey = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode('vH33r_2025_AES_GCM_S3cur3_K3y_9X7mP4qR8nT2wE5yU1oI6aS3dF7gH0jK9lZ'),
    'PBKDF2',
    false,
    ['deriveBits'],
  );
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: new TextEncoder().encode('imglarger-salt-2025'), iterations: 10000, hash: 'SHA-256' },
    masterKey,
    256,
  );
  return crypto.subtle.importKey('raw', derivedBits, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

async function encryptU2Payload(payloadObj) {
  const key = await deriveU2Key();
  const data = new TextEncoder().encode(JSON.stringify(payloadObj));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, data);
  const result = new Uint8Array(iv.length + ciphertext.byteLength);
  result.set(iv, 0);
  result.set(new Uint8Array(ciphertext), iv.length);
  return Buffer.from(result).toString('base64');
}

async function decryptU2Payload(encBase64) {
  const key = await deriveU2Key();
  const rawBytes = Buffer.from(encBase64, 'base64');
  const iv = rawBytes.subarray(0, 12);
  const ciphertext = rawBytes.subarray(12);
  const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
  return JSON.parse(new TextDecoder().decode(decrypted));
}

// ─────────────────────────────────────────────
// Enhance / Upscale
// ─────────────────────────────────────────────

/**
 * @param {Buffer} input Buffer gambar (jpg/png/webp)
 * @param {'enhancer'|'enlarger'} toolType
 * @param {string} filename
 */
export async function enhanceImage(input, toolType = 'enhancer', filename = 'image.jpg') {
  if (!input || !Buffer.isBuffer(input)) throw new Error('Input harus berupa Buffer gambar');

  const tool = ['enhancer', 'enlarger'].includes(toolType) ? toolType : 'enhancer';
  const isEnlarger = tool === 'enlarger';
  const selectedModel = isEnlarger ? 'realplksr' : 'hypir';
  const modelName = isEnlarger ? 'RealPLKSR' : 'Hypir Enhancer';
  const promptText = TOOL_PROMPTS[tool];

  const payloadObj = {
    positive_prompts: promptText,
    resolved_prompt: promptText,
    aspect_ratio: '1:1',
    selected_model: selectedModel,
    model_name: modelName,
    user_id: 'anonymous',
    type: 7,
  };
  const encParams = await encryptU2Payload(payloadObj);

  const form = new FormData();
  form.append('params', encParams);
  form.append('file', input, { filename });
  form.append('selected_model', selectedModel);

  const headers = {
    'User-Agent': USER_AGENT,
    Referer: `${BASE_URL}/image-enhancer`,
    Origin: BASE_URL,
    ...form.getHeaders(),
  };

  let uploadRes;
  try {
    uploadRes = await axios.post(`${BASE_URL}/api/u2/upload`, form, { headers, timeout: 30000 });
  } catch (err) {
    throw new Error(err.response?.data?.msg || err.message || 'Gagal upload gambar ke Imglarger');
  }

  if (!uploadRes.data?.data_enc) throw new Error(uploadRes.data?.msg || 'Upload gagal: data_enc tidak diterima');

  const decUpload = await decryptU2Payload(uploadRes.data.data_enc);
  const taskCode = decUpload.code;
  if (!taskCode) throw new Error('Task code tidak diterima dari response upload');

  let resultUrl = null;

  for (let i = 0; i < 40; i++) {
    await new Promise((r) => setTimeout(r, i === 0 ? 5000 : 3000));

    const statusPayload = { type: 7, code: taskCode, user_id: 'anonymous' };
    const encStatusParams = await encryptU2Payload(statusPayload);

    let statusRes;
    try {
      statusRes = await axios.post(
        `${BASE_URL}/api/u2/status`,
        { params: encStatusParams },
        {
          headers: {
            'User-Agent': USER_AGENT,
            Referer: `${BASE_URL}/image-enhancer`,
            Origin: BASE_URL,
            'Content-Type': 'application/json',
          },
          timeout: 15000,
        },
      );
    } catch {
      continue;
    }

    if (!statusRes.data?.data_enc) continue;

    const decStatus = await decryptU2Payload(statusRes.data.data_enc);
    const status = decStatus.status;

    if (status === 'success' || status === 'completed') {
      const rawUrl = decStatus.downloadUrls ? decStatus.downloadUrls[0] : null;
      if (rawUrl) {
        resultUrl = rawUrl.startsWith('http://') || rawUrl.startsWith('https://')
          ? rawUrl
          : `${RESULT_PREFIX}${path.basename(rawUrl)}`;
      }
      break;
    }

    if (status === 'failed' || status === 'nsfw') {
      throw new Error(decStatus.error || decStatus.message || `Proses gagal: ${status}`);
    }
  }

  if (!resultUrl) throw new Error('Proses timeout atau URL hasil tidak dibuat');

  const imageRes = await axios.get(resultUrl, { responseType: 'arraybuffer', timeout: 30000 });
  const imageBuffer = Buffer.from(imageRes.data);

  return {
    status: true,
    tool,
    model: modelName,
    taskCode,
    downloadUrl: resultUrl,
    sizeBytes: imageBuffer.length,
    sizeMB: (imageBuffer.length / (1024 * 1024)).toFixed(2),
    buffer: imageBuffer,
  };
}
