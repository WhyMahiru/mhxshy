import crypto from 'node:crypto';
import axios from 'axios';

const UA = 'Mozilla/5.0 (Android 15; Mobile; rv:150.0) Gecko/150.0 Firefox/150.0';

function randHex(n) {
  return crypto.randomBytes(n).toString('hex');
}

function appVersion() {
  return randHex(4).slice(0, 7);
}

function buildSearchUrl(query, pageSize, bookmark) {
  const sourceUrl = `/search/pins/?q=${encodeURIComponent(query)}&rs=typed`;
  const options = {
    query,
    scope: 'pins',
    page_size: pageSize,
    rs: 'typed',
    redux_normalize_feed: true,
    appliedProductFilters: '---',
    auto_correction_disabled: false,
    static_feed: false,
    ...(bookmark ? { bookmarks: [bookmark] } : {}),
  };
  const data = encodeURIComponent(JSON.stringify({ options, context: {} }));
  return (
    `https://id.pinterest.com/resource/BaseSearchResource/get/` +
    `?source_url=${encodeURIComponent(sourceUrl)}&data=${data}&_=${Date.now()}`
  );
}

function buildPinUrl(pinId) {
  const options = { id: pinId, field_set_key: 'detailed' };
  const data = encodeURIComponent(JSON.stringify({ options, context: {} }));
  return (
    `https://id.pinterest.com/resource/PinResource/get/` +
    `?source_url=${encodeURIComponent(`/pin/${pinId}/`)}&data=${data}&_=${Date.now()}`
  );
}

function apiHeaders(query, sourceUrlPath) {
  const trace = randHex(8);
  const srcPath = sourceUrlPath || `/search/pins/?rs=typed&q=${encodeURIComponent(query || '')}`;
  return {
    'user-agent': UA,
    accept: 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'accept-encoding': 'identity',
    'x-requested-with': 'XMLHttpRequest',
    'x-pinterest-appstate': 'active',
    'x-pinterest-pws-handler': 'www/search/[scope].js',
    'x-app-version': appVersion(),
    'x-b3-traceid': trace,
    'x-b3-spanid': randHex(8),
    'x-b3-parentspanid': trace,
    'x-b3-flags': '0',
    'screen-dpr': '2.857142857142857',
    'x-pinterest-source-url': srcPath,
    referer: `https://id.pinterest.com${srcPath}`,
  };
}

function parsePin(p) {
  if (!p?.id) return null;

  const images = p.images || {};
  const videos = p.videos?.video_list || null;

  let type = 'image';
  let mediaUrl = images['736x']?.url || images.orig?.url || null;

  if (videos && Object.keys(videos).length) {
    type = 'video';
    const sorted = Object.entries(videos).sort(
      (a, b) => (b[1]?.width || 0) - (a[1]?.width || 0),
    );
    mediaUrl = sorted[0]?.[1]?.url || mediaUrl;
  } else if (mediaUrl?.includes('.gif') || p.is_gif) {
    type = 'gif';
  }

  if (!mediaUrl) return null;

  return {
    id: p.id,
    type,
    title: p.title || p.grid_title || (p.description ? p.description.slice(0, 80) : '') || null,
    image: images['736x']?.url || images.orig?.url || null, 
    media: mediaUrl, 
    source: `https://www.pinterest.com/pin/${p.id}/`,
    uploader: p.pinner?.username || null,
    fullname: p.pinner?.full_name || null,
    saves: p.save_count || p.repin_count || 0,
  };
}

async function fetchSearchPage(q, pageSize, bookmark) {
  const url = buildSearchUrl(q, pageSize, bookmark);

  const res = await fetch(url, {
    headers: apiHeaders(q),
    signal: AbortSignal.timeout(20000),
  });

  if (!res.ok) throw new Error(`Pinterest: gagal search (code: ${res.status})`);

  const json = await res.json().catch(() => null);
  const rr = json?.resource_response;

  if (!rr || rr.status !== 'success') {
    throw new Error(rr?.message || 'Pinterest: response API tidak valid');
  }

  const pins = rr.data?.results || [];
  const bookmarkNext = rr.bookmark || json?.resource?.options?.bookmarks?.[0] || null;

  return { pins, bookmark: bookmarkNext };
}

export async function searchPinterest(query, limit = 10) {
  const q = String(query || '').trim();
  if (!q) throw new Error('Query pencarian kosong');

  const items = [];
  const seenIds = new Set();
  let bookmark = null;
  let pageCount = 0;
  const MAX_PAGES = 5; 

  while (items.length < limit && pageCount < MAX_PAGES) {
    const { pins, bookmark: nextBookmark } = await fetchSearchPage(q, limit, bookmark);
    pageCount++;

    for (const p of pins) {
      const parsed = parsePin(p);
      if (parsed && !seenIds.has(parsed.id)) {
        seenIds.add(parsed.id);
        items.push(parsed);
      }
    }

    if (!nextBookmark || nextBookmark === '-end-' || nextBookmark === bookmark) break;
    bookmark = nextBookmark;
  }

  if (!items.length) throw new Error('Pinterest: hasil kosong');

  return items.slice(0, limit);
}

// Ambil detail 1 pin lewat ID 
export async function getPin(pinId) {
  const id = String(pinId || '').trim();
  if (!id) throw new Error('Pin ID kosong');

  const url = buildPinUrl(id);
  const res = await fetch(url, {
    headers: apiHeaders('', `/pin/${id}/`),
    signal: AbortSignal.timeout(20000),
  });

  if (!res.ok) throw new Error(`Pinterest: gagal ambil pin (code: ${res.status})`);

  const json = await res.json().catch(() => null);
  const pin = json?.resource_response?.data;
  if (!pin) throw new Error(`Pin ${id} tidak ditemukan`);

  const parsed = parsePin(pin);
  if (!parsed) throw new Error(`Pin ${id} tidak memiliki media yang bisa diambil`);

  return parsed;
}

async function fromPinterestDownloaderIO(url) {
  const res = await axios.get(
    `https://pinterestdownloader.io/frontendService/DownloaderService?url=${encodeURIComponent(url)}`,
    { headers: { 'user-agent': UA }, timeout: 20000 },
  );

  const medias = res.data?.medias;
  if (!Array.isArray(medias) || !medias.length) {
    throw new Error('response tidak berisi media');
  }
  return medias;
}

const DOWNLOAD_PROVIDERS = [
  { name: 'pinterestdownloader.io', run: fromPinterestDownloaderIO },
];

export async function downloadPinterestMedia(url) {
  const errors = [];

  for (const provider of DOWNLOAD_PROVIDERS) {
    try {
      const medias = await provider.run(url);
      console.log(`[PINTEREST DL] Provider dipakai: ${provider.name}`);
      return { provider: provider.name, medias };
    } catch (err) {
      errors.push(`${provider.name}: ${err.message}`);
    }
  }

  throw new Error(`Semua provider download gagal.\n- ${errors.join('\n- ')}`);
}

export async function extractPinId(url) {
  let raw = String(url || '').trim();
  if (!raw) return null;

  if (/^https?:\/\/(www\.)?pin\.it\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        method: 'GET',
        redirect: 'follow',
        headers: { 'user-agent': UA },
        signal: AbortSignal.timeout(15000),
      });
      raw = res.url || raw;
    } catch {
      return null; 
    }
  }

  const match = raw.match(/\/pin\/(?:[^/]*?--)?(\d+)(?:\/|$|\?)/);
  return match ? match[1] : null;
}