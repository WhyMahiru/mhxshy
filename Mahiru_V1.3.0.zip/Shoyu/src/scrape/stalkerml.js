import axios from 'axios';

let currentProxy = null;

export function setProxy(proxyUrl) {
  currentProxy = proxyUrl;
}

export function getZoneEstimate(zoneId) {
  const zoneNum = parseInt(zoneId, 10);
  if (isNaN(zoneNum)) return 'Unknown';
  if (zoneNum < 2000) return '2016 - 2017 (Season 1 - 5)';
  if (zoneNum < 3000) return '2017 - 2018';
  if (zoneNum < 5000) return '2018 - 2019';
  if (zoneNum < 8000) return '2019 - 2020';
  if (zoneNum < 11000) return '2020 - 2021';
  if (zoneNum < 14000) return '2021 - 2022 (Q3-Q4)';
  return '2023 - Sekarang';
}

export async function getPlayerInfo(roleId, zoneId) {
  if (!roleId || !zoneId) {
    throw new Error('Role ID dan Zone ID wajib diisi.');
  }

  const url = 'https://www.smile.one/merchant/mobilelegends/checkrole';
  const params = new URLSearchParams({
    user_id: String(roleId),
    zone_id: String(zoneId),
    pid: '26',
    checkrole: '1',
  });

  const axiosConfig = {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'X-Requested-With': 'XMLHttpRequest',
      Origin: 'https://www.smile.one',
      Referer: 'https://www.smile.one/merchant/mobilelegends',
    },
    timeout: 15000,
  };

  if (currentProxy) {
    const p = new URL(currentProxy);
    axiosConfig.proxy = { host: p.hostname, port: parseInt(p.port, 10) };
  }

  const res = await axios.post(url, params.toString(), axiosConfig);

  if (res.data && res.data.code === 200) {
    const username = res.data.username || '';

    let squadTag = null;
    if (username.includes(' ')) {
      const parts = username.split(' ');
      const lastPart = parts[parts.length - 1];
      if (lastPart.length >= 2 && (lastPart.includes('.') || lastPart === lastPart.toUpperCase())) {
        squadTag = lastPart;
      }
    }

    return {
      success: true,
      roleId: String(roleId),
      zoneId: String(zoneId),
      username,
      squadTag,
      region: 'Indonesia',
      estimatedAge: getZoneEstimate(zoneId),
      accountStatus: 'Active & Normal',
      raw: res.data,
    };
  }

  return {
    success: false,
    message: res.data ? res.data.msg || 'Akun tidak ditemukan atau ID/Server salah.' : 'Gagal terhubung ke gateway.',
    raw: res.data,
  };
}

export async function verifyAccount(roleId, zoneId) {
  try {
    const info = await getPlayerInfo(roleId, zoneId);
    return info.success;
  } catch {
    return false;
  }
}

export default { getPlayerInfo, verifyAccount, getZoneEstimate, setProxy };