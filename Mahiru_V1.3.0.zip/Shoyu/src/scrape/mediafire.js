import axios from "axios";
import * as cheerio from "cheerio";

const MEDIAFIRE_MIME_MAP = {
  "7z": "application/x-7z-compressed",
  zip: "application/zip",
  rar: "application/x-rar-compressed",
  apk: "application/vnd.android.package-archive",
  exe: "application/x-msdownload",
  pdf: "application/pdf",
  doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ppt: "application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  mp3: "audio/mpeg",
  mp4: "video/mp4",
  txt: "text/plain",
  json: "application/json",
};

function mediafireMimeFromUrl(url) {
  if (!url) return "application/octet-stream";
  const fileName = url.split("/").pop()?.split("?")[0] || "";
  const ext = fileName.includes(".") ? fileName.split(".").pop().toLowerCase() : "";
  return MEDIAFIRE_MIME_MAP[ext] || "application/octet-stream";
}

export async function mediafire(url) {
  if (!url) throw new Error("Link Mediafire diperlukan");

  const { data: html } = await axios.get(url.trim(), {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
    },
    timeout: 60000,
  });

  const $ = cheerio.load(html);

  const title =
    $('meta[property="og:title"]').attr("content")?.trim() ||
    $("title").text().trim() ||
    "Mediafire File";

  const download_url =
    $("a.popsok[href^='https://download']").attr("href")?.trim() ||
    $("a.popsok:not([href^='javascript'])").attr("href")?.trim() ||
    $("#downloadButton").attr("href")?.trim() ||
    $('a[aria-label="Download file"]').attr("href")?.trim() ||
    null;

  if (!download_url) throw new Error("Mediafire: link download tidak ditemukan");

  const size =
    /Download\s*\(([\d.]+\s*[KMGT]?B)\)/i.exec(html)?.[1] ||
    $("#downloadButton").text().match(/\(([^)]+)\)/)?.[1] ||
    null;

  const filename = decodeURIComponent(download_url.split("/").pop()?.split("?")[0] || "file");

  return {
    title,
    filename,
    size,
    mimetype: mediafireMimeFromUrl(download_url),
    download_url,
    page_url: url.trim(),
  };
}