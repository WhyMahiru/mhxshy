/*
   * WhatsApp bot base using baileys (@wishkeysocket/baileys)
   * Type plugins | Modules ESM
   * Buy Script? t.me/ShoyuuAvailable90 

*⚠️ Baca file README.md di situ semua sudah lengkap 
   
   ** Copyright © Shoyu 2026 **
*/
import '../settings/setting.js';
import '../settings/mess.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { theLimit, reduceUserLimit, getUserProfile } from './lib/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ─── Plugin Cache ─────────────────────────────────────────────────────────────
let _pluginCache = null;
let _pluginMap = new Map();
const _fileCache = new Map();

const _scanDir = async (dir, category = null) => {
	const plugins = [];
	if (!fs.existsSync(dir)) return plugins;

	const files = fs.readdirSync(dir);
	for (const file of files) {
		const filePath = path.join(dir, file);
		const stat = fs.statSync(filePath);

		if (stat.isDirectory()) {
			const subCategory = category || file;
			const subPlugins = await _scanDir(filePath, subCategory);
			plugins.push(...subPlugins);
		} else if (filePath.endsWith('.js')) {
			const cached = _fileCache.get(filePath);

			if (cached && cached.mtime === stat.mtimeMs) {
				cached.plugin.__category = category;
				plugins.push(cached.plugin);
				for (const cmd of cached.plugin.command) {
					_pluginMap.set(cmd.toLowerCase(), cached.plugin);
				}
				continue;
			}

			try {
				const pluginUrl = `${pathToFileURL(filePath).href}?update=${stat.mtimeMs}`
				const pluginModule = await import(pluginUrl);
				const plugin = pluginModule.default || pluginModule;

				if (typeof plugin === 'object' && plugin !== null && Array.isArray(plugin.command)) {
					plugin.__category = category;
					plugins.push(plugin);
					_fileCache.set(filePath, { mtime: stat.mtimeMs, plugin });
					for (const cmd of plugin.command) {
						_pluginMap.set(cmd.toLowerCase(), plugin);
					}
				} else {
					console.warn(`[PLUGIN] '${file}' tidak valid — pastikan format plugin sesuai!`);
				}
			} catch (err) {
				console.error(`[PLUGIN] Gagal memuat '${filePath}':`, err.message);
			}
		}
	}
	return plugins;
};

export const loadPlugins = async (dir = path.join(process.cwd(), 'plugins'), forceReload = false) => {
	if (_pluginCache && !forceReload) return _pluginCache;

	if (!fs.existsSync(dir)) {
		console.warn(`[PLUGIN] Folder '${dir}' tidak ditemukan.`);
		_pluginCache = [];
		return _pluginCache;
	}

	const plugins = await _scanDir(dir);
	_pluginCache = plugins;
	return plugins;
};

export const reloadPlugins = async () => {
	_pluginCache = null;
	_pluginMap.clear();
	_fileCache.clear();
	return await loadPlugins(path.join(process.cwd(), 'plugins'), true);
};

// ─── Auto Watcher (polling) ───────────────────────────────────────────────────
const POLL_INTERVAL = 12000; // 12 detik — hemat CPU di Pterodactyl

const _getSnapshot = (baseDir) => {
	const snapshot = new Map();
	if (!fs.existsSync(baseDir)) return snapshot;
	const scan = (dir) => {
		const entries = fs.readdirSync(dir, { withFileTypes: true });
		for (const entry of entries) {
			const fullPath = path.join(dir, entry.name);
			if (entry.isDirectory()) {
				scan(fullPath);
			} else if (entry.name.endsWith('.js')) {
				snapshot.set(fullPath, fs.statSync(fullPath).mtimeMs);
			}
		}
	};
	scan(baseDir);
	return snapshot;
};

export const startWatcher = () => {
	const baseDir = path.join(process.cwd(), 'plugins');
	let lastSnapshot = _getSnapshot(baseDir);

	setInterval(async () => {
		const current = _getSnapshot(baseDir);
		let changed = false;

		for (const [f, mtime] of current) {
			if (!lastSnapshot.has(f) || lastSnapshot.get(f) !== mtime) {
				changed = true;
				break;
			}
		}
		if (!changed) {
			for (const f of lastSnapshot.keys()) {
				if (!current.has(f)) {
					changed = true;
					_fileCache.delete(f);
					break;
				}
			}
		}

		if (changed) {
			lastSnapshot = current;
			try {
				await reloadPlugins();
				console.log(`[Plugins reload] - file ${_pluginMap.size}\n[Information] - Status reload succes!`);
			} catch (err) {
				console.error(`[PLUGIN] ❌ Gagal reload:`, err.message);
			}
		}
	}, POLL_INTERVAL);
};

// ─── Permission Guard ─────────────────────────────────────────────────────────
const checkPermission = (plugin, m, Obj) => {
	const { isOwner, isAdmin, isBotAdmin, isPremium, Shoyu } = Obj;

	if (plugin.owner && !isOwner) {
		m.reply(mess.owner);
		return false;
	}

	if (plugin.premium && !isPremium && !isOwner) {
		m.reply(mess.vip);
		return false;
	}

	if (plugin.group && !m.isGroup) {
		m.reply(mess.group);
		return false;
	}

	if (plugin.privates && m.isGroup) {
		m.reply(mess.private);
		return false;
	}

	if (plugin.admin && m.isGroup && !isAdmin && !isOwner) {
		m.reply(mess.admin);
		return false;
	}

	if (plugin.botAdmin && !isBotAdmin) {
		m.reply(mess.botAdmin);
		return false;
	}

	// ─── Sistem Limit ────────────────────────
	if (plugin.limit && !isOwner) {
		if (theLimit(m.sender)) {
			m.reply(mess.endLimit);
			return false;
		}
	}
	
	if (plugin.noJadiBot && (m.isJadiBot || Obj?.Shoyu?.isJadiBot)) {
		m.reply('Fitur ini tidak bisa digunakan oleh *jadibot*!');
		return false;
	}

	return true;
};

// ─── Handle Message ───────────────────────────────────────────────────────────
export const handleMessage = async (m, Shoyu, commandText, Obj) => {
	if (typeof commandText !== 'string' || commandText.length === 0) return;

	if (!_pluginCache) await loadPlugins();

	const plugin = _pluginMap.get(commandText.toLowerCase());

	if (plugin) {
		try {
			const { prefix: usedPrefix, ...restOfObj } = Obj;
			const pluginData = { Shoyu, usedPrefix, ...restOfObj };

			const allowed = checkPermission(plugin, m, pluginData);
			if (!allowed) return;

			if (plugin.usePrefix === true && !usedPrefix) return;

			const result = await plugin.run(m, pluginData);

			if (plugin.limit && !Obj.isOwner && result !== false) {
				reduceUserLimit(m.sender);
				// hapus bagian /* dan */ untuk mengambilikan notif limit
				/*
				const _user = getUserProfile(m.sender);
				m.reply(`⚡ *Limit berkurang 1* | Sisa: *${_user?.limit ?? 0}* limit`);
				*/
			}
		} catch (err) {
			console.error(`[PLUGIN] Error saat menjalankan '${commandText}':`, err);
		}
	}
};

// ─── Cek apakah sebuah command terdaftar sebagai command plugin ──────────────
export const hasPluginCommand = (cmd) => {
	if (typeof cmd !== 'string' || !cmd) return false;
	return _pluginMap.has(cmd.toLowerCase());
};

// ─── Stats ────────────────────────────────────────────────────────────────────
export const getPluginStats = () => {
	const baseDir = path.join(process.cwd(), 'plugins');
	if (!fs.existsSync(baseDir)) return { totalCategory: 0, totalFiles: 0, totalCommands: 0, data: [] };

	if (!_pluginCache || _pluginCache.length === 0) {
		const folders = fs.readdirSync(baseDir).filter((f) => {
			const fullPath = path.join(baseDir, f);
			return fs.existsSync(fullPath) && fs.statSync(fullPath).isDirectory();
		});

		const result = [];
		let totalFiles = 0;

		for (const folder of folders) {
			try {
				const folderPath = path.join(baseDir, folder);
				const files = fs.readdirSync(folderPath).filter((f) => f.match(/\.(js|mjs|cjs)$/));
				totalFiles += files.length;
				result.push({ category: folder, count: files.length, commands: [] });
			} catch (e) {
				console.error(`[PLUGIN] Gagal membaca folder ${folder}:`, e.message);
			}
		}

		result.sort((a, b) => a.category.localeCompare(b.category));
		return { totalCategory: folders.length, totalFiles, totalCommands: 0, data: result };
	}

	// Kelompokkan berdasarkan kategori (nama folder), ambil semua command per plugin
	const grouped = new Map();
	let totalCommands = 0;

	for (const plugin of _pluginCache) {
		const cat = plugin.__category || 'uncategorized';
		if (!grouped.has(cat)) grouped.set(cat, { files: 0, commands: [] });
		const entry = grouped.get(cat);
		entry.files += 1;
		entry.commands.push(...plugin.command);
		totalCommands += plugin.command.length;
	}

	const result = Array.from(grouped.entries())
		.map(([category, { files, commands }]) => ({ category, count: files, commands }))
		.sort((a, b) => a.category.localeCompare(b.category));

	return { totalCategory: result.length, totalFiles: _pluginCache.length, totalCommands, data: result };
};