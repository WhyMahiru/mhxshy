/*
   * WhatsApp bot base using baileys (@wishkeysocket/baileys)
   * Type plugins | Modules ESM
   * Buy Script? t.me/ShoyuuAvailable90 

*⚠️ Baca file README.md di situ semua sudah lengkap 
   
   ** Copyright © Shoyu 2026 **
*/

process.on('uncaughtException', (err) => {
	console.error('Caught exception:', err);
});

import * as fs from 'fs/promises';
import * as fsSync from 'fs';
import chalk from 'chalk';
import { fileURLToPath, pathToFileURL } from 'url';
import { generateWAMessageFromContent, generateWAMessage } from '@whiskeysockets/baileys';

//=============================================//
import { handleMessage, getPluginStats, hasPluginCommand } from './plugins.js';
import { getGroup, updateData, getSettings, getMutedGroups, checkRegisteredUser, checkUserRegistered, getRegisteredUser, theLimit, addRegisteredUser, removeRegisteredUser, createUserDatabase, createSerial, checkName, getOwnerList, isPremiumUser } from './lib/database.js';
import { giveXP, sendLevelUpNotif, sendRankUpNotif } from './lib/level.js';
import { handleGameAnswer } from './lib/games.js';
import { getThumb } from './lib/thumb.js';
import { handleAntilink } from './lib/antilinkall.js';
import { handleAntiSwgc, handleAntiSticker, handleAntiToxic } from './lib/protection.js';
import sharp from 'sharp';

const _sharedThumb = await getThumb();
const _sharedDoc = fsSync.readFileSync(process.cwd() + '/package.json');
const _sharedThumbBuf = _sharedThumb ? await sharp(Buffer.from(_sharedThumb, 'base64')).resize(300, 300).jpeg().toBuffer() : Buffer.alloc(0);

// menampilkan icon location dan nama bot
const floc = {
  key: {
    participant: "0@s.whatsapp.net",
    remoteJid: `status@broadcast`
  },
  message: {
    locationMessage: {
      name: global.namaBot,
      jpegThumbnail: _sharedThumbBuf,
    }
  }
};

// menampilkan icon document dan nama bot
const fdoc = {
  key: {
    participant: "0@s.whatsapp.net",
    remoteJid: `status@broadcast`
  },
  message: {
    documentMessage: {
      title: global.namaBot,
      jpegThumbnail: _sharedThumbBuf,
    }
  }
};

// menampilkan icon gif dan nama owner
const fgif = {
  key: {
    participant: `0@s.whatsapp.net`,
    remoteJid: "status@broadcast"
  },
  message: {
    videoMessage: {
      seconds: 359996400,
      gifPlayback: true,
      caption: global.namaOwner,
      jpegThumbnail: _sharedThumbBuf,
    }
  }
};

// menampilkan icon usd dan US$1.000.00
const repPy = {
  key: {
    remoteJid: "0@s.whatsapp.net",
    fromMe: false,
    id: `${global.namaOwner}`,
    participant: "0@s.whatsapp.net"
  },
  message: {
    requestPaymentMessage: {
      currencyCodeIso4217: "USD",
      amount1000: 999999999,
      requestFrom: "0@s.whatsapp.net",
      noteMessage: {
        extendedTextMessage: {
          text: `${global.namaBot}`
        }
      },
      expiryTimestamp: 999999999,
      amount: {
        value: 91929291929,
        offset: 1000,
        currencyCode: "INR"
      }
    }
  }
};
// menampilkan icon troli dan angka beserta nama bot
const ftroli = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      itemCount: 6666,
      status: 200,
      thumbnail: _sharedThumbBuf,
      surface: 200,
      message: global.namaBot,
      orderTitle: global.namaOwner,
      sellerJid: "0@s.whatsapp.net",
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true
      }
    }
  }
};

export async function handler_cmd(Shoyu, m, chatUpdate) {

	// LABEL AI PRIVATE CHAT
	const _origSend = Shoyu.sendMessage.bind(Shoyu);
	Shoyu.sendMessage = async (jid, content, opts = {}) => {
		const isGroup = jid.endsWith('@g.us') || jid.endsWith('@broadcast');
		if (isGroup) return _origSend(jid, content, opts);

		const fullMsg = await generateWAMessage(jid, content, {
			userJid: Shoyu.user?.id,
			upload: Shoyu.waUploadToServer,
			quoted: opts.quoted,
		});

		await Shoyu.relayMessage(jid, fullMsg.message, {
			messageId: fullMsg.key.id,
			additionalNodes: opts.additionalNodes || [
				{ tag: 'bot', attrs: { biz_bot: '1' } },
				{ tag: 'biz', attrs: {} },
			],
		});

		return fullMsg;
	};

	const body =
		(m.mtype === 'conversation'
			? m.message.conversation
			: m.mtype === 'imageMessage'
				? m.message.imageMessage.caption
				: m.mtype === 'videoMessage'
					? m.message.videoMessage.caption
					: m.mtype === 'extendedTextMessage'
						? m.message.extendedTextMessage.text
						: m.mtype === 'buttonsResponseMessage'
							? m.message.buttonsResponseMessage.selectedButtonId
							: m.mtype === 'listResponseMessage'
								? m.message.listResponseMessage.singleSelectReply.selectedRowId
								: m.mtype === 'templateButtonReplyMessage'
									? m.message.templateButtonReplyMessage.selectedId
									: m.mtype === 'interactiveResponseMessage'
										? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id
										: '') || '';
	try {
		//=============================================//
		const botNumber = Shoyu.decodeJid(Shoyu.user.id);  
        const owners = getOwnerList();
        const globalOwners = (global.owner || []).map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
        const ownerList = [Shoyu.decodeJid(Shoyu.user.id),...globalOwners,...owners].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
        const isOwner = ownerList.includes(m.sender) || m.fromMe
        const isPremium = isPremiumUser(m.sender) || m.isDeveloper

//=============================================//
        const userRegistered = checkRegisteredUser(m.sender);
        const registeredUser = checkUserRegistered(m.sender);
        const isRegistered = userRegistered && registeredUser;
        const isLimit = !isPremium && !isOwner && theLimit(m.sender);
        const deviceinfo = /^3A/.test(m.id) ? 'ɪᴏs' : m.id.startsWith('3EB') ? 'ᴡᴇʙ' : /^.{21}/.test(m.id) ? 'ᴀɴᴅʀᴏɪᴅ' : /^.{18}/.test(m.id) ? 'ᴅᴇsᴋᴛᴏᴘ' : 'ᴜɴᴋɴᴏᴡ';

        
		//=============================================//
		const globalPrefix = global.prefix || '.';
		const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#%^&.©^]/gi;
		const isStrictMode = global.multiprefix === true;

		let prefix = '';
		let isCmd = false;

		if (isStrictMode) {
			if (body.startsWith(globalPrefix)) {
				prefix = globalPrefix;
				isCmd = true;
			}
		} else {
			const match = body.match(prefixRegex);

			if (match) {
				prefix = match[0];
				isCmd = true;
			} else {
				prefix = '';
				isCmd = true;
			}
		}

		const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
		const args = isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : [];
		const text = args.join(' ');
		const quoted = m.quoted ? m.quoted : m;
		const mime = quoted?.msg?.mimetype || quoted?.mimetype || null;
		const qmsg = m.quoted || m;
		const q = body.trim().split(/ +/).slice(1).join(' ');

		//=============================================//
		// ** fungsi untuk group chat **
        const groupMetadata = m.isGroup ? await Shoyu.getCachedGroupMetadata(m.chat).catch(() => ({})) : {}
        const participants = m.isGroup ? groupMetadata.participants?.map((p) => {
          let admin = null
          if (p.admin === 'superadmin') admin = 'superadmin'
          else if (p.admin === 'admin') admin = 'admin'
          const rawJid = p.id || p.jid || ''
          const normalJid = Shoyu.getJid
            ? Shoyu.getJid(rawJid)
            : rawJid.endsWith('@lid')
              ? rawJid.replace('@lid', '@s.whatsapp.net')
              : rawJid
          return { jid: normalJid, admin }
        }) || [] : []
        
        const groupAdmins = m.isGroup ? participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.jid) : []
        const normalizeNum = (j) => j?.split('@')[0]?.split(':')[0] || ''
        const isBotAdmin = m.isGroup ? groupAdmins.some(j => normalizeNum(j) === normalizeNum(botNumber)) : false
        const isAdmin = m.isGroup ? groupAdmins.some(j => normalizeNum(j) === normalizeNum(m.sender)) : false
		//=============================================//
		//Mute grup
		const chatDb = m.isGroup ? await getGroup(m.chat) : null;
		if (m.isGroup && isCmd && chatDb?.mute === 1 && !isOwner) return;

		//=============================================//
		if (global.gameSession && global.gameSession[m.chat]) {
			const isGroupMuted = m.isGroup && chatDb?.mute === 1 && !isOwner;
			const isNotRegistered = !isRegistered && !isOwner && !m.fromMe;

			if (!isGroupMuted && !isNotRegistered) {
				const gameHandled = await handleGameAnswer(m, Shoyu, body);
				if (gameHandled) return;
			}
		}
		//=============================================//
		//Gconly & pconly
         if (body.startsWith(prefix + command)) {
            if (global.pconly && m.isGroup) {
                return;
            }
            if (global.gconly && !m.isGroup && !isOwner) {
            return;
            }
        }
		//=============================================//
const reply = (m.reply = async (teks, opts = {}) => {
  const quoted = opts.quoted || m //ganti m nya kolo mau menggunakan fake quoted contoh /*const quoted = opts.quoted || fdoc*/ begitu juga sebaliknya 

  const sent = await Shoyu.sendMessage(m.chat, {
    document: _sharedDoc,
    mimetype: 'image/png',
    fileName: global.namaBot,
    fileLength: 99999999999999,
    caption: teks,
    jpegThumbnail: _sharedThumbBuf,
    mentions: opts.mentions || [],
    contextInfo: {
      mentionedJid: opts.mentions || [],
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.newsletter || '',
        newsletterName: global.namaBot,
        serverMessageId: Math.floor(Math.random() * 999999),
      },
      stanzaId: quoted.key.id,
      participant: quoted.key.participant || quoted.key.remoteJid,
      remoteJid: quoted.key.remoteJid,
      quotedMessage: quoted.message
    }
  }, { quoted })
  return sent?.key;
});
//=============================================//
// hmm🤔
//=============================================//
const msg = body?.trim().toLowerCase()
if (global.autokeyword) {
if (["p", "oi"].includes(msg)) {
  await Shoyu.sendMessage(m.chat, {
    text: `Hai @${m.sender.split("@")[0]}, utamakan salam dulu yahh`,
    mentions: [m.sender]
  }, { quoted: m })
  return
}
if (msg === "woi") {
  await Shoyu.sendMessage(m.chat, {
    text: `Woi-Woi @${m.sender.split("@")[0]}, apa bujang minimal salam`,
    mentions: [m.sender]
  }, { quoted: m })
  return
}
if (["assalamualaikum", "assalamu'alaikum"].includes(msg)) {
  await Shoyu.sendMessage(m.chat, {
    text: `Wa'alaikumussalam @${m.sender.split("@")[0]}, ada apa yah kak?`,
    mentions: [m.sender]
  }, { quoted: m })
  return
}
if (["bg", "bang", "bng"].includes(msg)) {
  await Shoyu.sendMessage(m.chat, {
    text: `Iya bang @${m.sender.split("@")[0]}, ada apa?`,
    mentions: [m.sender]
  }, { quoted: m })
  return
}
}
//=============================================//
const example = (teks) => {
return `Cara pengguna:\n*${prefix + command}* ${teks}`;
};
//=============================================//
//button belum register
		const replyNotRegist = () => {
			return Shoyu.sendButtons(
				m.chat,
				{
					text: `❌ Kamu belum terdaftar!\nSilakan daftar dulu untuk menggunakan bot ini.`,
					footer: global.namaBot,
					buttons: [
						{
							text: '📝 Daftar Sekarang',
							id: `${global.prefix || '.'}register`,
						},
					],
				},
				{ quoted: ftroli }
			);
		};

		//=============================================//
		// ** handle agar plugin bisa di pke **
		const handleData = {
			text,
			args,
			isCmd,
			mime,
			qmsg,
			isOwner,
			command,
			reply,
			example,
			prefix,
			isBotAdmin,
			getPluginStats,
			getGroup,
			updateData,
			getSettings,
			isAdmin,
			owners,
			isPremium,
			getMutedGroups,
			isJadiBot: !!(m.isJadiBot || Shoyu.isJadiBot),
			isRegistered,
			isLimit,
			deviceinfo,
			getRegisteredUser,
			addRegisteredUser,
			removeRegisteredUser,
			createUserDatabase,
			createSerial,
			checkName,
			replyNotRegist,
			fdoc,
			floc,
			fgif,
			repPy,
			ftroli,
		}; // tambah sesuai kebutuhan

		if (isCmd) {
			if (!global.public && !isOwner) return;

			//=============================================//
			if (!isRegistered && !['daftar', 'regis', 'register'].includes(command) && !m.fromMe && !isOwner) {
				const pluginExists = hasPluginCommand(command);

				if (pluginExists) return replyNotRegist();
			}

			await handleMessage(m, Shoyu, handleData.command.toLowerCase(), handleData);

			if (isRegistered && !m.fromMe) {
				giveXP(m.sender, 'command', async (newLevel, newRole, oldRole, reward) => {
					if (newRole !== oldRole) {
						await sendRankUpNotif(Shoyu, m, oldRole, newRole, newLevel, reward);
					} else {
						await sendLevelUpNotif(Shoyu, m, newLevel, newRole, reward);
					}
				});
			}
		}

		if (isRegistered && !m.fromMe && !isCmd) {
			giveXP(m.sender, 'passive', async (newLevel, newRole, oldRole, reward) => {
				if (newRole !== oldRole) {
					await sendRankUpNotif(Shoyu, m, oldRole, newRole, newLevel, reward);
				} else {
					await sendLevelUpNotif(Shoyu, m, newLevel, newRole, reward);
				}
			});
		}

		//=============================================//
		if (m.isGroup) {
			await handleAntilink(m, Shoyu, { isOwner, isAdmin, isBotAdmin, chatDb });
			await handleAntiSwgc(m, Shoyu, { isOwner, isAdmin, isBotAdmin, chatDb });
			await handleAntiSticker(m, Shoyu, { isOwner, isAdmin, isBotAdmin, chatDb });
			await handleAntiToxic(m, Shoyu, { isOwner, isAdmin, isBotAdmin, chatDb });
		}

		//=============================================//
		if (isCmd) {
			const from = m.key.remoteJid;
			const chatType = from.endsWith('@g.us') ? 'GROUP' : 'PRIVATE';

			const fullCommand = `${prefix}${command}`;

			const logMessage =
				chalk.green.bold(`\n Command detected 💻`) +
				chalk.white(`\n • 💬 Message:   `) +
				chalk.yellow.bold(fullCommand) +
				chalk.white(`\n • 📢 Chat In:   `) +
				chalk.magenta(chatType) +
				chalk.white(`\n • 👤 Name:      `) +
				chalk.cyan(m.pushName || 'N/A') +
				chalk.white(`\n • 📞 Sender ID: `) +
				chalk.blue(m.sender) +
				'\n';
			console.log(logMessage);
		}

		//=============================================//
	} catch (err) {
		console.log(err);
		try {
			if (Shoyu?.sendMessage && global.owner) {
				await Shoyu.sendMessage(global.owner + '@s.whatsapp.net', { text: err.toString() }, { quoted: m });
			}
		} catch (_) {}
	}
}

//=============================================//
const __filename = fileURLToPath(import.meta.url);
fsSync.watchFile(__filename, () => {
	fsSync.unwatchFile(__filename);
	console.log(chalk.white.bold('~> Update File :'), chalk.green.bold(__filename));
	import(`${pathToFileURL(__filename).href}?update=${Date.now()}`);
});